package json;

import com.fss.newfo.common.model.Message;
import com.fss.newfo.common.model.MobileInfo;
import com.fss.newfo.common.utility.FOJsonSchemaCached;

public class ConverObject2Json {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MobileInfo obj = new MobileInfo();
		obj.setCustomerName("tiendt");
		obj.setPhoneNumber("091574236");
		obj.setLegelid("145072539");
		obj.setAddress("Khoai Chau - Hung Yen");
		
		Message messageObj = obj;
		
		String rerult = FOJsonSchemaCached.convertJsonObjectToString(messageObj);
		System.out.println(rerult);
	}
}
