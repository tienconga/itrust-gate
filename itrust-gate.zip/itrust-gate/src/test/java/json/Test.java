package json;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer bf = new StringBuffer();
		bf.append("{\"");
		bf.append("CUSTOMERNAME");
		bf.append("\":\"");
		bf.append("tiendt");
		bf.append("\"");
		
		bf.append(",");
		
		bf.append("\"");
		bf.append("PHONENUMBER");
		bf.append("\":\"");
		bf.append("091574236");
		bf.append("\"");
		
		bf.append(",");
		
		bf.append("\"");
		bf.append("LEGELID");
		bf.append("\":\"");
		bf.append("145072539");
		bf.append("\"");
		
		bf.append(",");
		
		bf.append("\"");
		bf.append("ADDRESS");
		bf.append("\":\"");
		bf.append("Khoai Chau - Hung Yen");
		bf.append("\"");
		
		
		bf.append("}");
		
		System.out.println(bf.toString());
	}

}
