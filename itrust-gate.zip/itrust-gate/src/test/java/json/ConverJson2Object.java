package json;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fss.newfo.common.constant.Fields;
import com.fss.newfo.common.model.Message;
import com.fss.newfo.common.model.MobileInfo;
import com.fss.newfo.common.utility.FOJsonSchema;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.main.JsonSchemaFactory;

public class ConverJson2Object {

	//private static JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
	//private static Map<String, FOJsonSchema> JsonSchemaMap = new HashMap<String, FOJsonSchema>();
	
	public static void main(String[] args) throws IOException, ProcessingException {
		
		
		
		String msg = "{\"customername\":\"tiendt\",\"phonenumber\":\"091574236\",\"legelid\":\"145072539\",\"address\":\"Khoai Chau - Hung Yen\"}";
		
		try {
			ObjectMapper mapper = new ObjectMapper();
			MobileInfo obj = mapper.readValue(msg, MobileInfo.class);
			System.out.println(obj.getAddress());			
			//msgObj = mapper.readValue(node.traverse(), Message.class);
			//msgObj.setContent(msg);

		} catch (Exception e) {
			//node.put(Fields.ERROR_CODE, ErrorCode.ERROR_UNKNOWN);
			System.out.println(e.getMessage());
		}
	}

}
