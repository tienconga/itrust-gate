package com.fss.auto.trading.engine;



public interface ITradeSender {

	/**
	 * @param order
	 */


}
