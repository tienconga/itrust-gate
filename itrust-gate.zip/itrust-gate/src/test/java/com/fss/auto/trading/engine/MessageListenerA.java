package com.fss.auto.trading.engine;

import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

public class MessageListenerA implements MessageListener {

	// private boolean transacted = false;
	// private boolean persistent = false;

	private Properties props;
	private Context context = null;
	private QueueConnectionFactory queueConnectionFactory = null;
	private QueueConnection queueConnection = null;
	private QueueSession queueSession = null;
	private Queue queue = null;;
	private MessageConsumer consumer = null;
	private String queueName = "";

	private boolean connectStatus = true;

	MessageSender sender = null;

	public MessageListenerA(String jmsProperties) {

		try {
			props = ConfigLoader.getProperties(jmsProperties);
			connect();

		} catch (Exception e) {
		}
	}

	public void connect() {

		try {
			sender = new MessageSender("E:\\tiendt\\tele\\itrust-gate\\configs_test\\JMS_order.properties");

			queueName = props.getProperty(CommonConstants.JMS_MESSAGE_RESPONSE_NAME);

			context = new InitialContext(props);

			queueConnectionFactory = (QueueConnectionFactory) context.lookup("QueueConnectionFactory");

			queueConnection = queueConnectionFactory.createQueueConnection();

			queueSession = queueConnection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);

			queue = queueSession.createQueue(queueName);

			consumer = queueSession.createConsumer(queue);

			consumer.setMessageListener(this);

			queueConnection.start();

		} catch (Exception e) {
			connectStatus = false;
		}

	}

	public boolean connectStatus() {
		try {
			if ((connectStatus) && (queueConnection.getExceptionListener() != null))
				connectStatus = false;
		} catch (JMSException e) {
			connectStatus = false;
		}
		return connectStatus;
	}

	public void disconnect() {
		try {
			if (queueConnection != null) {
				queueConnection.stop();
				queueSession.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			queueConnection = null;
			queueSession = null;
		}
	}

	@Override
	public void onMessage(Message msg) {
		System.out.println("Receied22. " + msg);
		if (msg instanceof TextMessage) {
			TextMessage objMsg = (TextMessage) msg;
			try {
				String obj = objMsg.getText();
				System.out.println(obj);
				String correlationId = objMsg.getJMSCorrelationID();
				System.out.println(correlationId);
				sender.send(obj,correlationId);

			} catch (JMSException e) {
			}
		}
	}
}
