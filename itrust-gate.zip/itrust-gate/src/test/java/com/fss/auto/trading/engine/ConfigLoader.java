package com.fss.auto.trading.engine;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * 
 * @author tiendt
 *
 */
public class ConfigLoader {

	/**
	 *
	 * @param propertyFileName
	 * @return
	 * @throws java.io.FileNotFoundException
	 */
	@SuppressWarnings("unused")
	public static Properties getProperties(String propertyFileName)
		throws java.io.FileNotFoundException {


		InputStream is = null;
		try {
			//String configPath = System.getProperty("configPath");

			//File file = new File( configPath + "/" + propertyFileName );
			File file = new File(propertyFileName);
			is = new FileInputStream( file );

			if (is == null) {
				throw new FileNotFoundException(propertyFileName + " not found");
			}

			// load properties
			Properties props = new Properties();
			props.load(is);
			return props;

		} catch (Exception ignore) {
			ignore.printStackTrace();
			throw new java.io.FileNotFoundException(
				propertyFileName + " not found");
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		Properties pros = getProperties("");

	}
}
