package com.fss.auto.trading.engine;

public class CommonConstants {

	public static final String JMS_MESSAGE_NAME = "topic.JMS_MESSAGE";

	public static final String JMS_MESSAGE_REQUEST_NAME = "queue.JMS_MESSAGE_REQUEST";

	public static final String JMS_MESSAGE_RESPONSE_NAME = "queue.JMS_MESSAGE_RESPONSE";
	
	public static final String JMS_MESSAGE_ENGINE_REQUEST = "queue.JMS_MESSAGE_ENGINE_REQUEST";

}
