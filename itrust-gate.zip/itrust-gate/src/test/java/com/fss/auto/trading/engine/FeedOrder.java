package com.fss.auto.trading.engine;

import java.io.IOException;
import java.util.Date;
import java.util.Random;
import java.util.UUID;

public class FeedOrder {

	private static Random random;

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		MessageSender sender = new MessageSender("hft-request-jms.properties");

		//for (int i = 0; i < 100000; i++) {
			String strQuote = "{\"objectype\":\"Quote\",\"msgtype\":\"tx0001\",\"errorCode\":\"0\",\"quoteid\":\"223564\"," +
					"\"userid\":\"0002\",\"classcd\":\"TSO\",\"via\":\"F\",\"typecd\":\"LO\",\"subtypecd\":\"LO\",\"side\":\"B\"," +
					"\"symbol\":\"ACB\",\"qtty\":100,\"acctno\":\"0001000099\",\"price\":24500,\"sessionex\":\"CNT\"," +
					"\"createddt\":\"2016-05-25\",\"expireddt\":\"2016-05-26\",\"pricedelta\":100,\"scopeprice\":200}";
			
			String uId = UUID.randomUUID().toString();
			strQuote = strQuote.replaceAll("QUOTEUID", uId);
		//	sender.send(strQuote);
		//}

		System.exit(0);

	}
}
