package com.fss.auto.trading.engine;

public class MessagePublisher {

}
