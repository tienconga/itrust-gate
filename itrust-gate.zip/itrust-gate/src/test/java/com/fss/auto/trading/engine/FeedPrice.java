package com.fss.auto.trading.engine;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.Random;

import com.noname.itrust.gate.model.Market;

public class FeedPrice {

	private static Random random;

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		MessageSender sender = new MessageSender("JMS.properties");

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		String s;
		while ((s = in.readLine()) != null) {

			try {
				String symbol = s.substring(0, 3);
				BigDecimal price = new BigDecimal(s.substring(3));
				Market ins = new Market();
				ins.setSymbol(symbol);
				ins.setLatestPrice(price);
				sender.send3(ins);
				System.out.println("sent.");
			} catch (Exception ex) {
				System.out.println("Format is incorrect. Please retype...(Format example: SSI30000)");
			}

		}

		// QuotesBean bean = new QuotesBean();
		//sender.send("{type=1I, order_number=201412080000059283, firm=006, board=M, port_client_flag=C, price=30, trader_id=111, side=B, volume=1000, security_symbol=SSI, client_id=002C100024, filler_2=     , published_volume=1000, filler_1=     }");

		/*StringBuffer xmlContent = new StringBuffer();
		xmlContent.append("<hose-messages xmlns=\"http://hosemsg.schemas.fss.ipa.com\">")
				.append("<hose-message>")
				//.append("<group>CTCI</group>")
				.append("<group>OOD</group>")
				.append("<type>1I</type>")
				.append("<items>")
				.append("<item name=\"order_number\">00011898</item>")
				.append("<item name=\"firm\">21</item>")
				.append("<item name=\"board\">M</item>")
				.append("<item name=\"port_client_flag\">C</item>")
				.append("<item name=\"price\">30</item>")
				.append("<item name=\"trader_id\">111</item>")
				.append("<item name=\"side\">B</item>")
				.append("<item name=\"volume\">1000</item>")
				.append("<item name=\"security_symbol\">SSI</item>")
				.append("<item name=\"client_id\">002C100021</item>")
				.append("<item name=\"filler_2\"></item>")
				.append("<item name=\"published_volume\">1000</item>")
				.append("<item name=\"filler_1\"></item>")
				.append("</items>")
				.append("</hose-message>")
				.append("</hose-messages>");
		*/
		//sender.send(xmlContent.toString());

		//System.exit(1);
		// sender.disconnect();
		// String msg =
		// "{\"symbol\": \"CVX\",\"name\": \"Chevron Corp New\",\"low\": 53.596965534922134,\"high\": 59.27220406479166,\"open\": 58.95,\"last\": 54.71344759057803,\"change\": 54.71344759057803}";
		/*
		 * String msgText = new StringBuffer() .append("{")
		 * .append("\"symbol\": \"CVX\",\n")
		 * .append("\"name\": \"Chevron Corp New\",\n") .append("\"low\": 1,\n")
		 * .append("\"high\": 3,\n") .append("\"open\": 1,\n")
		 * .append("\"last\": 1,\n") .append("\"change\": 1") .append("}\n")
		 * .toString(); System.out.println(msgText);
		 * 
		 * while(true){ try { Thread.sleep(5000); } catch (InterruptedException
		 * e) { // TODO Auto-generated catch block e.printStackTrace(); }
		 * Message msg; try { random = new Random(); Stock stock = new Stock();
		 * simulateChange(stock);
		 * 
		 * msg = createStockMessage(sender.topicSession,stock);
		 * msg.setStringProperty("symbol","CVX"); //newsProducer.send(msg);
		 * sender.send2(msg); } catch (Exception e) { // TODO Auto-generated
		 * catch block e.printStackTrace(); }
		 * 
		 * 
		 * }
		 */

	}

}
