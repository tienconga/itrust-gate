package com.fss.auto.trading.engine;

public class ListenTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MessageListenerA test = new MessageListenerA("E:\\tiendt\\tele\\itrust-gate\\configs_test\\JMS.properties");
	}

}
