package com.fss.auto.trading.engine;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import com.fss.timesten.adapter.TimesTenConnectionPool;
import com.fss.timesten.adapter.TimesTenPooledConnection;
import com.noname.itrust.gate.model.Market;
import com.timesten.jdbc.TimesTenPreparedStatement;

public class FeedAllPrice {

	private static Random random;

	static TimesTenConnectionPool connPool;

	static MessageSender sender = null;

	/**
	 * @param args
	 * @throws IOException 
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws IOException, SQLException {
		sender = new MessageSender("JMS_Price.properties");
		initConnectionPool();
		FeedAllPrice test = new FeedAllPrice();
		test.test();
	}

	public void test() {
		Timer timer = new Timer();
		TimerTask task = new CheckTimeoutTask();
		timer.schedule(task, 0, 1000);
	}

	class CheckTimeoutTask extends TimerTask {
		public void run() {
			try {
				TimesTenPreparedStatement statement = null;
				ResultSet rs = null;

				TimesTenPooledConnection ttConnection = connPool.getConnection();

				statement = ttConnection.getPreparedStmt("SEL_INSTRUMENTS");

				rs = statement.executeQuery();

				while (rs.next()) {
					String symbol = rs.getString("SYMBOL");
					BigDecimal price = rs.getBigDecimal("PRICE_RF");
					System.out.println(symbol + ":" + price);
					doTask(symbol, price);
				}

				if (rs != null) {
					rs.close();
					rs = null;
				}

				ttConnection.commit();
				connPool.releaseConnection(ttConnection);

			} catch (Exception ex) {
				System.out.println(ex.getMessage());
			}
		}
	}

	public void doTask(String symbol, BigDecimal price) {
		Market ins = new Market();
		ins.setSymbol(symbol);
		ins.setLatestPrice(price);
		sender.send3(ins);
		//System.out.println("sent.");
	}

	public static void initConnectionPool() {

		// create connection pool
		connPool = new TimesTenConnectionPool(1);
		try {
			connPool.initialise("jdbc:timesten:client:ttc_server=192.168.1.20;tcp_port=53397;ttc_server_dsn=FOTEST", false);
			connPool.addPreparedStatement("SEL_INSTRUMENTS", "SELECT * FROM INSTRUMENTS");

			connPool.enable();

		} catch (SQLException e) {
			System.err.println(e.getMessage());
			System.exit(1);
		}

	}
}
