package com.fss.auto.trading.engine;

import java.util.Properties;

import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import com.noname.itrust.gate.model.Market;

public class MessageSender {

	private Properties props;
	private Context context = null;
	private QueueConnectionFactory queueConnectionFactory = null;
	private QueueConnection queueConnection = null;
	private QueueSession queueSession = null;
	private Queue queue = null;;
	private MessageProducer producer = null;
	private String queueName = "";

	/*private Properties props;
	private Context context = null;
	private TopicConnectionFactory topicConnectionFactory = null;
	private TopicConnection topicConnection = null;
	public TopicSession topicSession = null;
	private Topic topic = null;;
	private MessageProducer producer = null;
	private String queueName = "";*/

	public MessageSender(String jmsProperties) {

		try {
			props = ConfigLoader.getProperties(jmsProperties);

			connect();

		} catch (Exception e) {

		}
	}

	public void connect() {

		try {
			queueName = props.getProperty(CommonConstants.JMS_MESSAGE_ENGINE_REQUEST);
			//queueName = props.getProperty("queue.JMS_MESSAGE_RESPONSE");

			context = new InitialContext(props);

			queueConnectionFactory = (QueueConnectionFactory) context.lookup("QueueConnectionFactory");

			//queueConnection = queueConnectionFactory.createQueueConnection();
			queueConnection = queueConnectionFactory.createQueueConnection("admin", "admin");

			queueSession = queueConnection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);

			queue = queueSession.createQueue(queueName);

			producer = queueSession.createProducer(queue);

			producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/*public void connect2() {

	    try {
	    	queueName = props.getProperty(CommonConstants.JMS_MESSAGE_REQUEST_NAME);

	    	context = new InitialContext(props);
	        //TopicConnectionFactory topicConnectionFactory = null;
	    	topicConnectionFactory = (TopicConnectionFactory) context.lookup("TopicConnectionFactory");
	        //TopicConnection topicConnection = null;
	        topicConnection = topicConnectionFactory.createTopicConnection();
	        //TopicSession topicSession = null;
	        topicSession = topicConnection.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
	        //Topic topic = null;
	        topic =  topicSession.createTopic("stockQuoteTopic");
	        producer = topicSession.createPublisher(topic);
	        producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
	        
	    } catch (Exception e) {
			System.out.println("");
	    }
	}*/

	public void send(String message,String correlationId) {
		//ObjectMessage msgObj = null;
		TextMessage msgObj = null;
		try {
			//QuotesBean bean = new QuotesBean();
			//bean.setSource(message);
			//bean.setQuoteid("12345");
			//msgObj = queueSession.createObjectMessage();
			msgObj = queueSession.createTextMessage();
			//msgObj.setObject(bean);
			msgObj.setText(message);
			msgObj.setJMSCorrelationID(correlationId);
			producer.send(msgObj);
		} catch (JMSException e) {

			e.printStackTrace();
		}

	}

	public void send2(Message message) {
		ObjectMessage msgObj = null;
		try {
			//msgObj = topicSession.createObjectMessage();
			//msgObj.setObject(message);

			producer.send(message);
		} catch (JMSException e) {

			e.printStackTrace();
		}

	}

	public void send3(Market message) {
		ObjectMessage msgObj = null;
		try {
			msgObj = queueSession.createObjectMessage();
			msgObj.setObject(message);

			producer.send(msgObj);
		} catch (JMSException e) {

			e.printStackTrace();
		}

	}

	public void disconnect() {
		try {
			if (queueConnection != null) {
				queueConnection.stop();
				queueSession.close();
			}
			System.exit(0);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			queueConnection = null;
			queueSession = null;
		}
	}

}
