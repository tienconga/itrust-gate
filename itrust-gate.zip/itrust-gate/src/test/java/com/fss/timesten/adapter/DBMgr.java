/*
 * Copyright(C) 2014 FSS Software Company
 *
 * $Id: BackendDBMgr.java,v 1.0 2014/06/26 11:08:05 tien.do Exp $
 *
 */

package com.fss.timesten.adapter;

import java.sql.SQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fss.newfo.common.sql.SQLStatement;

/**
 * This Class contain Methods for connection to Database.
 * @author 	tien.do<tien.do@fssc.com.vn> $Author: tien.do$
 * @version 	$Revision: 1.0 $
 */
public class DBMgr {
	
	protected final Logger log = LoggerFactory.getLogger(getClass());
	
	private static TimesTenConnectionPool connPool;
	private TimesTenPooledConnection connection = null;
	
	public TimesTenPooledConnection getConnection() {
		try {
			connection = connPool.getConnectionWait();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void setConnection(TimesTenPooledConnection connection) {
		this.connection = connection;
	}

	public TimesTenConnectionPool getConnPool() {
		return connPool;
	}

	public void setConnPool(TimesTenConnectionPool connPool) {
		DBMgr.connPool = connPool;
	}

	public static DBMgr getInstance(){
		return new DBMgr();
	}
	
	public void initConnectionPool(String url,String username, String password, int numConnections){
        connPool = new TimesTenConnectionPool(numConnections);
    	
        try {
    	    //connPool.initialise(url,false);
        	connPool.initialise(url, username, password, false);

        	//connPool.addPreparedStatement("SEL_POOL", "SELECT GRANTED,INUSED FROM POOLROOM WHERE POLICYTYPE = 'P'");
    	    connPool.addCallableStatement("sp_process_order_buy", "call CSPKS_FO_ORDER_NEW.sp_process_order_buy(?,?,?,?,?,?)");
    	    connPool.addCallableStatement("sp_get_pp_pp0", "call CSPKS_FO_COMMON.sp_get_pp_pp0(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    	    connPool.addCallableStatement("fn_get_asset_amt", "{? = call CSPKS_FO_COMMON.fn_get_asset_amt(?)}");
    	    connPool.addCallableStatement("fn_get_order_ppse_amt", "{? = call CSPKS_FO_COMMON.fn_get_order_ppse_amt(?,?)}");
    	    
    	    
    	    
    	   
    	    connPool.enable();
    	   
    	} catch (SQLException e) {
            System.err.println("Error:" + e.getMessage());
    	    System.exit(1);
        }
	}
	
	public void closeConnection(TimesTenPooledConnection connection) {
		try {
			connPool.releaseConnection(connection);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
