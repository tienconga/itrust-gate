package com.fss.timesten.adapter;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;
import java.net.URL;
import java.sql.*;

import com.timesten.jdbc.*;

/**
 * Represents a TimesTen statement.
 *
 * This class should not be instantiated directly. Instances of this classs
 * are manipulated via methods in the associated TimesTenPooledConnection and
 * TimesTenConnectionPool classes.
 * <p><p>
 * This class implements the standard Statement interface, plus 
 * some additional methods.
 * <p><p>
 * Any methods which are not explicitly documented behave identically to
 * the corresponding method in TimesTenStatement.
 * <p><p>
 * Any individual instance of this class should not be shared amongst multiple 
 * threads.
 * <p><p>
 * If the connection that owns this statement has been invalidated due to a 
 * failover most methods will throw a TTCP_ERR_STMT_INVALID exception.
 */
public final class TimesTenPooledStatement 
	implements TimesTenStatement
{
    ///////////////////// CONSTANTS //////////////////
    //
    // Classname
    private static final String className = "TimesTenPooledStatement";

    ///////////////////// PRIVATE VARIABLES //////////////////

    // Lock for things that affect the connection
    private ReentrantLock stmtLock = null;   

    // The underlying prepared statement for this 
    // TimesTenPreparedStatement
    private TimesTenStatement sStmt = null;

    // The 'label' for this statement
    private String stmtLabel = null;

    // The SQL statement that this represents
    private String sqlText = null;

    // The TimesTenPooledConnection that 'owns' this TimesTenPooledStatement
    private TimesTenPooledConnection stmtConn = null;

    // The TimesTenConnectionPool that ultimately 'owns' this TimesTenPooledStatement
    private TimesTenConnectionPool stmtPool = null;

    // Is statement invalid due to failover
    private boolean isDefunct = false;

    ///////////////////// CONSTRUCTORS /////////////////////////
    
    // Create a prepared statement with the specified label on the given 
    // connection
    protected TimesTenPooledStatement(
		                        TimesTenConnectionPool pool, 
		                        TimesTenPooledConnection conn, 
		                        String label)
	    throws SQLException
    {
	this.stmtConn = conn;
	this.stmtPool = pool;
	this.stmtLabel = label;
	this.sStmt = (TimesTenStatement)this.stmtConn.getNativeConnection().createStatement();
        stmtLock = new ReentrantLock(stmtPool.getLockingFairness());
    }

    ////////////// FINALIZER /////////////

    protected void finalize()
	    throws Throwable
    {
        stmtLabel = null;
        sqlText = null;
        stmtConn = null;
        stmtPool = null;
	if (  this.sStmt != null  )
	    try {
	       sStmt.close();
	    } catch ( SQLException e ) {
		// ignore it
	    }
	super.finalize();
    }

    //////////////////// PRIVATE METHODS ///////////////////////
 
    // lock the statement
    private final void lockStmt()
    {
	this.stmtLock.lock();
    }

    // unlock the statement
    private final void unlockStmt()
    {
	this.stmtLock.unlock();
    }

    // Check if statement is locked
    private final boolean isStmtLocked()
    {
	return this.stmtLock.isLocked();
    }

    // Handle defunct statement
    private final void checkDefunct(String funcname)
	    throws SQLException
    {
	if (  this.isDefunct  )
	    throw new SQLException(
	        className + funcname + ":statement invalid due to failover",
		TimesTenConnectionPool.TTCP_SQLSTATE,
		TimesTenConnectionPool.TTCP_ERR_STMT_INVALID);
    }
    
    //////////////////// PROTECTED METHODS ///////////////////////
    
    // Close this prepared statement.
    protected final void realClose() 
	    throws SQLException
    {
	lockStmt();
	try {
	    if (  !this.isDefunct  )
	        sStmt.close();
	} finally {
            unlockStmt();
        }
    }

    // Set the isDefunct flag
    protected final void setIsDefunct(boolean isdefunct)
    {
	this.isDefunct = isdefunct;
    }

    // Get the isDefunct flag
    protected final boolean isDefunct()
    {
	return this.isDefunct;
    }
 
    ////////////////// ADDITIONAL PUBLIC METHODS /////////////////////
    
    /**
     * Returns the textual label associated with this statement.
     * The label is defined when the statement is created via the
     * the addStatement() method in the TimesTenConnectionPool
     * class.
     */
    public final String getLabel()
    {
	return this.stmtLabel;
    }
    
    /**
     * Returns the SQL text for this prepared statement.
     * This can be useful for debugging or tracing.
     */
    public final String getSql()
    {
	return this.sqlText;
    }

    ////////////////// OVERRIDDEN METHODS //////////////////////////

    /**
     * Always returns false.
     * Statement pooling is not required and so is not supported.
     */
    public final boolean isPoolable() // from Statement
    {
	return false; // we don't support statement pooling (no need)
    }

    /**
     * Silently does nothing.
     * Statement pooling is not required and so is not supported.
     */
    public final void setPoolable(boolean poolable) // from Statement
    {
	// silently do nothing - we don't support statement pooling
    }

    /**
     * Returns the TimesTenPooledConnection (as a Connection) with
     * which this TimesTenPoolPreparedStatement is associated.
     */
    public final Connection getConnection() 
    {
	return this.stmtConn;
    }

    /**
     * Indicates if statement is 'closed'.
     * Statements are never closed while they are accessible.
     */
    public final boolean isClosed() 
    {
	return false;
    }

    /**
     * Silently does nothing.
     * A TimesTenPoolPreparedStatement can only be closed by the owning
     * TimesTenPooledConnection object which in turn will only close
     * the statement when directed to by its owning TimestenConnectionPool
     * object, via of the removeStatement() method.
     */
    public final void close() 
    {
	// Silently do nothing.
	// Only the owning connection can close the statement
	// via the realClose() method.
    }
 
    ////////////////////////////////////////////////////////////////////////
    //               NOTHING INTERESTING BEYOND THIS POINT                //
    //                                                                    //
    // All the following methods pretty much just call the corresponding  //
    // method in the associated TimesTenPreparedStatement object.         //
    ////////////////////////////////////////////////////////////////////////

    // Methods from TimesTenStatement
    
    /**
     * See com.timesten.jdbc.TimesTenStatement.getQueryTimeThreshold()
     */
    public final int getQueryTimeThreshold()
	    throws SQLException
    {
	checkDefunct("getQueryTimeThreshold");

	return sStmt.getQueryTimeThreshold();
    }

    /**
     * See com.timesten.jdbc.TimesTenStatement.setQueryTimeThreshold()
     */
    public final void setQueryTimeThreshold(int seconds)
	    throws SQLException
    {
	checkDefunct("setQueryTimeThreshold");

	sStmt.setQueryTimeThreshold(seconds);
    }

    // Methods from Statement

    /**
     * See java.sql.Statement.addBatch()
     */
    public final void addBatch(String sql) 
	    throws SQLException
    {
	checkDefunct("addBatch");

	sStmt.addBatch(sql);
    }

    /**
     * See java.sql.Statement.cancel()
     */
    public final void cancel() 
	    throws SQLException
    {
	checkDefunct("cancel");

	sStmt.cancel();
    }

    /**
     * See java.sql.Statement.clearBatch()
     */
    public final void clearBatch() 
	    throws SQLException
    {
	checkDefunct("clearBatch");

	sStmt.clearBatch();
    }

    /**
     * See java.sql.Statement.clearWarnings()
     */
    public final void clearWarnings() 
	    throws SQLException
    {
	checkDefunct("clearWarnings");

	sStmt.clearWarnings();
    }

    /**
     * See java.sql.Statement.execute()
     */
    public final boolean execute(String sql) 
	    throws SQLException
    {
	checkDefunct("execute");

	this.stmtConn.setInTxn(true);
	return sStmt.execute(sql);
    }
 
    /**
     * See java.sql.Statement.execute()
     */
    public final boolean execute(String sql, int autoGeneratedKeys) 
	    throws SQLException
    {
	checkDefunct("execute");

	this.stmtConn.setInTxn(true);
	return sStmt.execute(sql, autoGeneratedKeys);
    }
 
    /**
     * See java.sql.Statement.execute()
     */
    public final boolean execute(String sql, int[] columnIndexes) 
	    throws SQLException
    {
	checkDefunct("execute");

	this.stmtConn.setInTxn(true);
	return sStmt.execute(sql, columnIndexes);
    }
 
    /**
     * See java.sql.Statement.execute()
     */
    public final boolean execute(String sql, String[] columnNames) 
	    throws SQLException
    {
	checkDefunct("execute");

	this.stmtConn.setInTxn(true);
	return sStmt.execute(sql, columnNames);
    }

    /**
     * See java.sql.Statement.executeBatch()
     */
    public final int[] executeBatch() 
	    throws SQLException
    {
	checkDefunct("executeBatch");

	this.stmtConn.setInTxn(true);
	return sStmt.executeBatch();
    }
 
    /**
     * See java.sql.Statement.executeQuery()
     */
    public final ResultSet executeQuery(String sql) 
	    throws SQLException
    {
	checkDefunct("executeQuery");

	this.stmtConn.setInTxn(true);
	return sStmt.executeQuery(sql);
    }
 
    /**
     * See java.sql.Statement.executeUpdate()
     */
    public final int executeUpdate(String sql) 
	    throws SQLException
    {
	checkDefunct("executeUpdate");

	this.stmtConn.setInTxn(true);
	return sStmt.executeUpdate(sql);
    }
 
    /**
     * See java.sql.Statement.executeUpdate()
     */
    public final int executeUpdate(String sql, int autoGeneratedKeys) 
	    throws SQLException
    {
	checkDefunct("executeUpdate");

	this.stmtConn.setInTxn(true);
	return sStmt.executeUpdate(sql, autoGeneratedKeys);
    }
 
    /**
     * See java.sql.Statement.executeUpdate()
     */
    public final int executeUpdate(String sql, int[] columnIndexes) 
	    throws SQLException
    {
	checkDefunct("executeUpdate");

	this.stmtConn.setInTxn(true);
	return sStmt.executeUpdate(sql, columnIndexes);
    }
 
    /**
     * See java.sql.Statement.executeUpdate()
     */
    public final int executeUpdate(String sql, String[] columnNames) 
	    throws SQLException
    {
	checkDefunct("executeUpdate");

	this.stmtConn.setInTxn(true);
	return sStmt.executeUpdate(sql, columnNames);
    }
 
    /**
     * See java.sql.Statement.getFetchDirection()
     */
    public final int getFetchDirection() 
	    throws SQLException
    {
	return sStmt.getFetchDirection();
    }
 
    /**
     * See java.sql.Statement.getFetchSize()
     */
    public final int getFetchSize() 
	    throws SQLException
    {
	checkDefunct("getFetchSize");

	return sStmt.getFetchSize();
    }
 
    /**
     * See java.sql.Statement.getGeneratedKeys()
     */
    public final ResultSet getGeneratedKeys() 
	    throws SQLException
    {
	checkDefunct("getFetchSize");

	return sStmt.getGeneratedKeys();
    }
 
    /**
     * See java.sql.Statement.getMaxFieldSize()
     */
    public final int getMaxFieldSize() 
	    throws SQLException
    {
	checkDefunct("getMaxFieldSize");

	return sStmt.getMaxFieldSize();
    }
 
    /**
     * See java.sql.Statement.getMaxRows()
     */
    public final int getMaxRows() 
	    throws SQLException
    {
	checkDefunct("getMaxRows");

	return sStmt.getMaxRows();
    }
 
    /**
     * See java.sql.Statement.getMoreResults()
     */
    public final boolean getMoreResults() 
	    throws SQLException
    {
	checkDefunct("getMoreResults");

	return sStmt.getMoreResults();
    }

    /**
     * See java.sql.Statement.getMoreResults()
     */
    public final boolean getMoreResults(int current) 
	    throws SQLException
    {
	checkDefunct("getMoreResults");

	return sStmt.getMoreResults(current);
    }
 
    /**
     * See java.sql.Statement.getQueryTimeout()
     */
    public final int getQueryTimeout() 
	    throws SQLException
    {
	checkDefunct("getQueryTimeout");

	return sStmt.getQueryTimeout();
    }
 
    /**
     * See java.sql.Statement.getResultSet()
     */
    public final ResultSet getResultSet() 
	    throws SQLException
    {
	checkDefunct("getResultSet");

	return sStmt.getResultSet();
    }
 
    /**
     * See java.sql.Statement.getResultSetConcurrency()
     */
    public final int getResultSetConcurrency() 
	    throws SQLException
    {
	checkDefunct("getResultSetConcurrency");

	return sStmt.getResultSetConcurrency();
    }
 
    /**
     * See java.sql.Statement.getResultSetHoldability()
     */
    public final int getResultSetHoldability() 
	    throws SQLException
    {
	checkDefunct("getResultSetHoldability");

	return sStmt.getResultSetHoldability();
    }
 
    /**
     * See java.sql.Statement.getResultSetType()
     */
    public final int getResultSetType() 
	    throws SQLException
    {
	checkDefunct("getResultSetType");

	return sStmt.getResultSetType();
    }
 
    /**
     * See java.sql.Statement.getUpdateCount()
     */
    public final int getUpdateCount() 
	    throws SQLException
    {
	checkDefunct("getUpdateCount");

	return sStmt.getUpdateCount();
    }

    /**
     * See java.sql.Statement.getWarnings()
     */
    public final SQLWarning getWarnings() 
	    throws SQLException
    {
	checkDefunct("getWarnings");

	return sStmt.getWarnings();
    }

    /**
     * See java.sql.Statement.setCursorName()
     */
    public final void setCursorName(String name) 
	    throws SQLException
    {
	checkDefunct("setCursorName");

	sStmt.setCursorName(name);
    }

    /**
     * See java.sql.Statement.setEscapeProcessing()
     */
    public final void setEscapeProcessing(boolean enable) 
	    throws SQLException
    {
	checkDefunct("setEscapeProcessing");

	sStmt.setEscapeProcessing(enable);
    }

    /**
     * See java.sql.Statement.setFetchDirection()
     */
    public final void setFetchDirection(int direction) 
	    throws SQLException
    {
	checkDefunct("setFetchDirection");

	sStmt.setFetchDirection(direction);
    }

    /**
     * See java.sql.Statement.setFetchSize()
     */
    public final void setFetchSize(int rows) 
	    throws SQLException
    {
	checkDefunct("setFetchSize");

	sStmt.setFetchSize(rows);
    }

    /**
     * See java.sql.Statement.setMaxFieldSize()
     */
    public final void setMaxFieldSize(int max) 
	    throws SQLException
    {
	checkDefunct("setMaxFieldSize");

	sStmt.setMaxFieldSize(max);
    }

    /**
     * See java.sql.Statement.setMaxRows()
     */
    public final void setMaxRows(int rows) 
	    throws SQLException
    {
	checkDefunct("setMaxRows");

	sStmt.setMaxRows(rows);
    }

    /**
     * See java.sql.Statement.setQueryTimeout()
     */
    public final void setQueryTimeout(int seconds) 
	    throws SQLException
    {
	checkDefunct("setQueryTimeout");

	sStmt.setQueryTimeout(seconds);
    }

    // Methods from Wrapper

    public final boolean isWrapperFor(Class<?> iface) 
	    throws SQLException
    {
	return sStmt.isWrapperFor(iface);
    }

    public final <T> T unwrap(Class <T> iface) 
	    throws SQLException
    {
	return sStmt.unwrap(iface);
    }

	@Override
	public void closeOnCompletion() throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isCloseOnCompletion() throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getLobPrefetchSize() throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setLobPrefetchSize(int arg0) throws SQLException {
		// TODO Auto-generated method stub
		
	}
}

