package com.fss.timesten.adapter;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.locks.ReentrantLock;

import com.fss.newfo.common.utility.StringUtils;
import com.timesten.jdbc.ClientFailoverEvent;
import com.timesten.jdbc.ClientFailoverEventListener;
import com.timesten.jdbc.TimesTenConnection;
import com.timesten.jdbc.TimesTenDataSource;
import com.timesten.jdbc.TimesTenVendorCode;

/**
 * Represents a Timesten Connection Pool.
 * This class instantiates a TimesTen connection pool i.e. a pool of
 * TimestenPooledConnection objects.
 */
public final class TimesTenConnectionPool
{
	// Classname
	private static final String className = "TimesTenConnectionPool";

	// DEBUG or not DEBUG?
	protected static final boolean DEBUG = false;

	// PRIVATE CLASS
	/*
	 * Represents a Timesten Failover Handler.
	 * This class instantiates a TimesTen Failover Handler object.
	 */
	private final class TimesTenFailoverHandler
			implements ClientFailoverEventListener
	{
		////////////// PRIVATE DATA /////////////

		// The owning connection pool
		private TimesTenConnectionPool cpool = null;

		////////////// CONSTRUCTOR /////////////

		TimesTenFailoverHandler(TimesTenConnectionPool pool)
		{
			this.cpool = pool;
		}

		////////////// FINALIZER /////////////

		protected void finalize()
				throws Throwable
		{
			this.cpool = null;
			super.finalize();
		}

		////////////// PUBLIC FUNCTIONS /////////////

		public void notify(ClientFailoverEvent event)
		{
			ClientFailoverEvent.FailoverEvent theEvent = event.getTheFailoverEvent();
			switch (theEvent)
			{
			case BEGIN:
				cpool.beginFailover();
				break;
			case END:
				cpool.endFailover();
				break;
			case ABORT:
				cpool.abortFailover();
				break;
			}
		}
	}

	/////////////// ERROR CODES /////////////

	/**
	 * SQLSTATE value used for all SQLExceptions originating from 
	 * TimesTenConnectionPool.
	 */
	public static final String TTCP_SQLSTATE = "TTCP1";

	// Extended TimesTen Native Error Codes base value
	private static final int TTCP_EB = 90000;

	/**
	 * Connection Pool Error - Still In Transaction.
	 * A SQLException with this error code is thrown if an attempt is made 
	 * to release a connection (return it to the pool) while the connection 
	 * has an open transaction. The application should finish the transaction
	 * by either comitting or rolling back and then retry the releaseConnection
	 * call.
	 */
	public static final int TTCP_ERR_STILL_IN_TRANSACTION = (TTCP_EB + 1);

	/**
	 * Connection Pool Error - Invalid Parameter.
	 * A SQLException with this error code is thrown in some cases when an 
	 * invalid parameter is passed to a connection pool method.
	 */
	public static final int TTCP_ERR_INVALID_PARAMETER = (TTCP_EB + 2);

	/**
	 * Connection Pool Error - State Error.
	 * A SQLException with this error code is thrown if a method is called 
	 * which is invalid for the current state of the connection pool. For 
	 * example, attemtping to initialise() an already initialised connection 
	 * pool.
	 */
	public static final int TTCP_ERR_STATE_ERROR = (TTCP_EB + 3);

	/**
	 * Connection Pool Error - Not Allowed.
	 * A SQLException with this error code is thrown if a method is called which
	 * is not supported. A TimesTenPooledConnection only supports a limited
	 * subset of the operations that are allowed on a normal connection.
	 * Operations which are not commonly used, or which are anyway not supported
	 * by Timesten, may return this error.
	 */
	public static final int TTCP_ERR_NOT_ALLOWED = (TTCP_EB + 4);

	/**
	 * Connection Pool Error - Resize Error.
	 * A resizePool() operation failed due to some lower level error.
	 * The pool may have been partially resized.
	 */
	public static final int TTCP_ERR_RESIZE_ERROR = (TTCP_EB + 5);

	/**
	 * Connection Pool Error - Connection not in use.
	 * An attempt was made to release a connection that was not 'in use'.
	 */
	public static final int TTCP_ERR_NOT_IN_USE = (TTCP_EB + 6);

	/**
	 * Connection Pool Error - Prepare Error.
	 * A statement prepare failed. The chained exception will give the underlying cause.
	 */
	public static final int TTCP_ERR_PREPARE_ERROR = (TTCP_EB + 7);

	/**
	 * Connection Pool Error - Pool is Dead.
	 * An unrecoverable error has occurred. The pool is unusable
	 * until after a successful shutdown() and initialise().
	 */
	public static final int TTCP_ERR_POOL_DEAD = (TTCP_EB + 8);

	/**
	 * Connection Pool Error - Internal Error.
	 * An unrecoverable internal error has occurred. The pool is unusable
	 * until after a successful shutdown() and initialise().
	 */
	public static final int TTCP_ERR_INTERNAL = (TTCP_EB + 9);

	/**
	 * Failover in progress.
	 * A failover operation is in progress for the pool. No other 
	 * operations are allowed until the failover has completed.
	 */
	public static final int TTCP_ERR_FAILOVER =
			TimesTenVendorCode.TT_ERR_FAILOVERINVALIDATION;

	/**
	 * Connection invalid due to failover.
	 * This connection is invalid due to an in progress failover.
	 * Return the connection to the pool and obtain a new connection after
	 * the failover has completed.
	 */
	public static final int TTCP_ERR_CONN_INVALID =
			TimesTenVendorCode.TT_ERR_FAILOVERINVALIDATION;

	/**
	 * Statement invalid due to failover.
	 * This statement is invalid due to an in progress failover.
	 * Return the associated connection to the pool and obtain a new 
	 * connection after the failover has completed.
	 */
	public static final int TTCP_ERR_STMT_INVALID =
			TimesTenVendorCode.TT_ERR_FAILOVERINVALIDATION;

	/////////////// CONSTANTS ///////////////

	// TimesTen direct URL prefix
	/**
	 * JDBC URL prefix for a direct mode connection.
	 */
	public static final String TIMESTEN_DIRECT_URL_PREFIX = "jdbc:timesten:direct:";

	// TimesTen client URL prefix
	/**
	 * JDBC URL prefix for a client/server connection.
	 */
	public static final String TIMESTEN_CLIENT_URL_PREFIX = "jdbc:timesten:client:";

	// TimesTen driver name
	// private static final String TT_DRIVER_NAME = "com.timesten.jdbc.TimesTenDriver";

	// Locking 'fariness'
	private static final boolean lockingIsFair = false;

	/////////////// PRIVATE VARIABLES ///////////

	// Lock for things that affect the pool
	private ReentrantLock poolLock = null;

	// The DataSource for this pool
	TimesTenDataSource ttdatasource = null;

	// Are we initialised?
	private volatile boolean initialised = false;

	// Are we suspended?
	private volatile boolean suspended = true;

	// Are we quiescent?
	private volatile boolean quiescent = true;

	// Are we processing a failover?
	private volatile boolean infailover = false;

	// Are we dead due to an unrecoverable error?
	private volatile boolean pooldead = false;

	// Direct or CS mode
	private boolean isClientServer = false;

	// Is failover enabled?
	private boolean failoverEnabled = false;

	// Connection URL
	private String URL = null;

	// Number of connections
	private int numConnections = 0;
	private int numFreeConnections = 0;

	// Connection free and busy maps
	private HashMap<Integer, TimesTenPooledConnection> freeConn = null;
	private HashMap<Integer, TimesTenPooledConnection> busyConn = null;

	// Failover callback functions
	private TimesTenFailoverHandler failoverHandler = null;

	/////////////// CONSTRUCTOR ///////////////

	/**
	 * Creates a connection pool initially containing 'numConnections'
	 * connections.
	 * The initial state of the pool is !initialised, suspended, quiescent.
	 * Before the pool can be used, the application must first initialise
	 * it and set the value for the URL
	 *
	 * @param       numConnections     The number of connections in the pool
	 *
	 * @see         #initialise
	 * @see         #resizePool
	 */
	public TimesTenConnectionPool(int numConnections)
	{
		if (numConnections < 1)
			this.numConnections = 1;
		else
			this.numConnections = numConnections;
		ttdatasource = new TimesTenDataSource();
		poolLock = new ReentrantLock(lockingIsFair);
	}

	////////////// FINALIZER /////////////

	protected void finalize()
			throws Throwable
	{
		URL = null;
		busyConn = null;
		freeConn = null;
		failoverHandler = null;
		poolLock = null;
		super.finalize();
	}

	/////////////// PRIVATE METHODS ////////////////

	// Create and open a connection
	private final TimesTenPooledConnection createConnection()
			throws SQLException
	{
		TimesTenPooledConnection ttpconn = null;
		TimesTenConnection ttconn = null;
		ttconn = (TimesTenConnection) ttdatasource.getConnection();
		ttpconn = new TimesTenPooledConnection(ttconn, this);
		ttpconn.setAutoCommitPool(false);

		return ttpconn;
	}

	// Mark all busy connections as defunct
	private final void markAllBusyAsDefunct()
	{
		Iterator<TimesTenPooledConnection> connit;

		connit = this.busyConn.values().iterator();
		while (connit.hasNext())
			connit.next().setIsDefunct(true);
	}

	// Re-prepare all statements on a connection
	private final void
			reprepareAllStatements(TimesTenPooledConnection ttpconn)
					throws SQLException
	{
		Iterator<TimesTenPooledPreparedStatement> pstmtit = null;
		TimesTenPooledPreparedStatement pstmt = null;
		Iterator<TimesTenPooledCallableStatement> cstmtit = null;
		TimesTenPooledCallableStatement cstmt = null;

		pstmtit = ttpconn.getPreparedStmtIterator();
		while (pstmtit.hasNext())
		{
			pstmt = pstmtit.next();
			ttpconn.createPreparedStmt(pstmt.getLabel(), pstmt.getSql(),
					pstmt.getOptHints());
		}
		cstmtit = ttpconn.getCallableStmtIterator();
		while (cstmtit.hasNext())
		{
			cstmt = cstmtit.next();
			ttpconn.createCallableStmt(cstmt.getLabel(), cstmt.getSql());
		}
	}

	// reprepare all statements on all free connections
	private final void
			reprepareAllFreeConnections()
					throws SQLException
	{
		Iterator<TimesTenPooledConnection> connit;

		connit = this.freeConn.values().iterator();
		while (connit.hasNext())
			reprepareAllStatements(connit.next());
	}

	// Duplicate an existing connection
	private final TimesTenPooledConnection
			cloneConnection(TimesTenPooledConnection ttpconn)
					throws SQLException
	{
		TimesTenPooledConnection newttpconn = null;
		Iterator<TimesTenPooledPreparedStatement> pstmtit = null;
		TimesTenPooledPreparedStatement pstmt = null;
		Iterator<TimesTenPooledCallableStatement> cstmtit = null;
		TimesTenPooledCallableStatement cstmt = null;
		Iterator<TimesTenPooledStatement> stmtit = null;
		TimesTenPooledStatement stmt = null;

		newttpconn = createConnection();

		// clone all prepared statements
		pstmtit = ttpconn.getPreparedStmtIterator();
		while (pstmtit.hasNext())
		{
			pstmt = pstmtit.next();
			try {
				newttpconn.createPreparedStmt(pstmt.getLabel(),
						pstmt.getSql(),
						pstmt.getOptHints());
			} catch (SQLException e) {
				newttpconn.realClose();
				throw e;
			}
		}

		// clone all callable statements
		cstmtit = ttpconn.getCallableStmtIterator();
		while (cstmtit.hasNext())
		{
			cstmt = cstmtit.next();
			try {
				newttpconn.createCallableStmt(cstmt.getLabel(),
						cstmt.getSql());
			} catch (SQLException e) {
				newttpconn.realClose();
				throw e;
			}
		}

		// clone all statements
		stmtit = ttpconn.getStmtIterator();
		while (stmtit.hasNext())
		{
			stmt = stmtit.next();
			try {
				newttpconn.createStmt(stmt.getLabel());
			} catch (SQLException e) {
				newttpconn.realClose();
				throw e;
			}
		}

		return newttpconn;
	}

	// find and return a free connection, marking it 'in use'
	private final TimesTenPooledConnection allocateConnection()
	{
		Iterator<TimesTenPooledConnection> connit;
		TimesTenPooledConnection ttconn = null;

		connit = this.freeConn.values().iterator();
		if (connit.hasNext())
		{
			ttconn = connit.next();
			connit.remove();
			this.busyConn.put(ttconn.getID(), ttconn);
			ttconn.setInUse(true);
			this.numFreeConnections--;
		}

		return ttconn;
	}

	// return a connection to the pool and mark it as 'free'
	private final void deallocateConnection(TimesTenPooledConnection ttconn)
	{
		ttconn.setInUse(false);
		this.busyConn.remove(ttconn.getID());
		this.freeConn.put(ttconn.getID(), ttconn);
		this.numFreeConnections++;
	}

	// lock the entire pool
	private final void lockPool()
	{
		this.poolLock.lock();
	}

	// unlock the entire pool
	private final void unlockPool()
	{
		this.poolLock.unlock();
	}

	// Check if pool is locked
	private final boolean isPoolLocked()
	{
		return this.poolLock.isLocked();
	}

	// Kill the pool (mark it as dead)
	private final void killPool()
	{
		this.lockPool();
		this.pooldead = true;
		this.infailover = false;
		this.unlockPool();
	}

	// Check if pool is initialised and not dead
	private boolean checkPoolAlive(String funcname)
			throws SQLException
	{
		if (!this.initialised)
			throw new SQLException(
					className + ":" + funcname + ": not initialised",
					TTCP_SQLSTATE,
					TTCP_ERR_STATE_ERROR);
		else if (this.pooldead)
			throw new SQLException(
					className + ":" + funcname + ": pool is DEAD",
					TTCP_SQLSTATE,
					TTCP_ERR_POOL_DEAD);

		return true;
	}

	/////////////// PROTECTED METHODS ////////////////

	// Begin failover processing
	protected final void beginFailover()
	{
		if (!this.infailover)
		{
			this.lockPool();
			this.infailover = true;
			try {
				this.markAllBusyAsDefunct();
			} finally {
				this.unlockPool();
			}
		}
	}

	// Finish failover processing
	protected final void endFailover()
	{
		if (this.infailover)
		{
			this.lockPool();
			this.infailover = false;
			try {
				this.reprepareAllFreeConnections();
			} catch (SQLException e) {
				killPool();
			}
			this.unlockPool();
		}
	}

	// Abort failover processing
	protected final void abortFailover()
	{
		killPool();
	}

	// Get value for locking fairness
	protected boolean getLockingFairness()
	{
		return this.lockingIsFair;
	}

	/////////////// PUBLIC METHODS ////////////////

	/**
	 * Obtains a connection from the pool without waiting.
	 * If no connection is currently available (pool suspended,
	 * no free connections, failover in progress) then immediately 
	 * returns null.
	 *
	 * @return      A TimesTenPooledConnection object for an open
	 *              connection.
	 *
	 * @exception   SQLException
	 *
	 * @see         #getConnectionWait
	 * @see         #getConnectionWait(int)
	 * @see         #releaseConnection
	 */
	public final TimesTenPooledConnection getConnection()
			throws SQLException
	{
		TimesTenPooledConnection ttconn = null;

		lockPool();
		try {
			checkPoolAlive("getConnection");
			if (!this.infailover && !this.suspended)
			{
				ttconn = allocateConnection();
				if (ttconn != null)
					this.quiescent = false;
			}
		} finally {
			unlockPool();
		}

		return ttconn;
	}

	/**
	 * Obtains a connection from the pool, waiting indefinitely.
	 * If no connection is currently available (pool suspended,
	 * no free connections, failover in progress) then waits until 
	 * one is available. Could wait indefinitely, so use with caution.
	 *
	 * @return      A TimesTenPooledConnection object for an open
	 *              connection.
	 *
	 * @exception   SQLException
	 *
	 * @see         #getConnection
	 * @see         #getConnectionWait(int)
	 * @see         #releaseConnection
	 */
	public final TimesTenPooledConnection getConnectionWait()
			throws SQLException
	{
		boolean mustReturn = false;
		TimesTenPooledConnection ttconn = null;

		while (!mustReturn)
		{
			lockPool();
			try {
				checkPoolAlive("getConnectionWait");
				if (!this.infailover && !this.suspended)
				{
					ttconn = allocateConnection();
					if (ttconn != null)
					{
						mustReturn = true;
						this.quiescent = false;
					}
				}
			} finally {
				unlockPool();
			}
			if (!mustReturn)
				try {
					Thread.sleep(1); // ~1 millisecond
				} catch (InterruptedException e) {
					// ignore it
				}
		}

		return ttconn;
	}

	/**
	 * Obtains a connection from the pool, waiting for a specified time.
	 * If no connection is currently available (pool suspended, 
	 * no free connections, failover in progress) then waits until one 
	 * is available. If no connection is available within the specified
	 * number of milliseconds, returns null.
	 * <p><p>
	 * Passing a negative value for 'millis' results in the same 
	 * behaviour as getConnectionWait(). Passing a zero value for 'millis'
	 * results in the same behaviour as getConnection().
	 *
	 * @return      A TimesTenPooledConnection object for an open
	 *              connection.
	 *
	 * @param       millis The maximum time (in milliseconds) to wait for a
	 *                     connection to be available.
	 *
	 * @exception   SQLException
	 *
	 * @see         #getConnection
	 * @see         #getConnectionWait
	 * @see         #releaseConnection
	 */
	public final TimesTenPooledConnection getConnectionWait(int millis)
			throws SQLException
	{
		boolean mustReturn = false;
		long startTime = System.currentTimeMillis();
		long now;
		TimesTenPooledConnection ttconn = null;

		if (millis == 0)
			ttconn = this.getConnection();
		else if (millis < 0)
			ttconn = this.getConnectionWait();
		else
			while (!mustReturn)
			{
				lockPool();
				try {
					checkPoolAlive("getConnectionWait");
					if (!this.infailover && !this.suspended)
					{
						ttconn = allocateConnection();
						if (ttconn != null)
						{
							mustReturn = true;
							this.quiescent = false;
						}
					}
				} finally {
					unlockPool();
				}
				if (!mustReturn)
					try {
						now = System.currentTimeMillis();
						if ((now - startTime) >= millis)
							mustReturn = true;
						else
							Thread.sleep(1); // ~1 millisecond
					} catch (InterruptedException e) {
						// ignore it
					}
			}

		return ttconn;
	}

	/**
	 * Returns a connection to the pool.
	 * The application has the responsibility to ensure that the connection
	 * does not have an active transaction when it is returned. Essentially
	 * this means that the last thing the application does on the connection
	 * before returning it must be either commit() or rollback(). Attempting to
	 * return a connection with an active transaction will result in an
	 * exception being thrown. Once the application has returned the 
	 * connection it must not perform any further operations on that 
	 * connection, or on any of the associated statements retrieved via
	 * getPreparedStmt(), getCallableStmt(), getStmt() and should discard
	 * any references it has to those objects.
	 *
	 * @param       ttconn   A TimesTenPooledConnection object previously
	 *                       obtained from the pool using one of the
	 *                       getConnection() methods.
	 *
	 * @exception   SQLException
	 *
	 * @see         #getConnection
	 * @see         #getConnectionWait
	 * @see         #getConnectionWait(int)
	 */
	public final void releaseConnection(TimesTenPooledConnection ttconn)
			throws SQLException
	{
		if (ttconn == null)
			throw new SQLException(
					className + ":releaseConnection: null connection passed",
					TTCP_SQLSTATE,
					TTCP_ERR_INVALID_PARAMETER);

		lockPool();
		try {
			if (!this.initialised)
				throw new SQLException(
						className + ":releaseConnection: not initialised",
						TTCP_SQLSTATE,
						TTCP_ERR_STATE_ERROR);

			if (!ttconn.inUse())
				throw new SQLException(
						className + ":releaseConnection: connection not 'in use'",
						TTCP_SQLSTATE,
						TTCP_ERR_NOT_IN_USE);

			if (ttconn.inTxn())
				if (this.infailover)
					ttconn.setInTxn(false);
				else
					throw new SQLException(
							className + ":releaseConnection: still in transaction",
							TTCP_SQLSTATE,
							TTCP_ERR_STILL_IN_TRANSACTION);

			try {
				if (!this.infailover && ttconn.isDefunct())
					reprepareAllStatements(ttconn);
			} catch (SQLException e) {
				killPool();
				throw e;
			} finally {
				deallocateConnection(ttconn);

				if (this.suspended)
				{ // check if we can now quiesce the pool
					Iterator<TimesTenPooledConnection> connit;

					connit = this.busyConn.values().iterator();
					if (!connit.hasNext())
						this.quiescent = true;
				}
			}

		} finally {
			unlockPool();
		}
	}
	
    public final void initialise(
			String url,
            String user,
            String password,
			boolean enablefailover) throws SQLException{
			if(!StringUtils.isEmpty(user)) {
				ttdatasource.setUser(user);
			}
			
			if (!StringUtils.isEmpty(password)){
				ttdatasource.setPassword(password);
			}
			
			initialise(url, enablefailover);
		}
    

	/**
	 * Initialises the pool for use.
	 * Sets the values for the URL and whether failover handling should 
	 * be enabled.
	 *
	 * After the method returns, the pool is initialised but still suspended
	 * and quiescent. Typically the application will then add various
	 * statements to the pool using addXXXXStatement() before enabling 
	 * it for use via enable().
	 *
	 * @param       url   The TimesTen JDBC connection URL for the pool.
	 *
	 * @param       enablefailover   Indicates if the pool should automatically
	 *                               handle connection failover. Automatic
	 *                               failover handling is only supported
	 *                               for client/server connections. If this
	 *                               parameter is passed as 'true' for a direct
	 *                               mode pool it is silently changed to false.
	 *
	 * @exception   SQLException
	 *
	 * @see         #shutdown
	 */
	public final void initialise(
			String url, // URL - cannot be null
			boolean enablefailover
			)
					throws SQLException
	{
		boolean isclientserver = false;
		boolean error = false;

		if (url == null)
			throw new SQLException(
					className + ":initialise: null value for URL",
					TTCP_SQLSTATE,
					TTCP_ERR_INVALID_PARAMETER);

		if (url.startsWith(TIMESTEN_DIRECT_URL_PREFIX))
			isclientserver = false;
		else if (url.startsWith(TIMESTEN_CLIENT_URL_PREFIX))
			isclientserver = true;
		else
			throw new SQLException(
					className + ":initialise: invalid value for URL",
					TTCP_SQLSTATE,
					TTCP_ERR_INVALID_PARAMETER);

		if (!isclientserver)
			enablefailover = false;

		lockPool();
		try {
			TimesTenPooledConnection ttconn = null;

			if (this.initialised)
				throw new SQLException(
						className + ":initialise: already initialised",
						TTCP_SQLSTATE,
						TTCP_ERR_STATE_ERROR);

			this.pooldead = false;
			this.suspended = true;
			this.quiescent = true;
			this.URL = url;
			ttdatasource.setUrl(url);
			this.isClientServer = isclientserver;
			this.failoverEnabled = enablefailover;
			if (this.failoverEnabled)
				this.failoverHandler = new TimesTenFailoverHandler(this);
			else
				this.failoverHandler = null;
			freeConn = new HashMap<Integer, TimesTenPooledConnection>(this.numConnections);
			busyConn = new HashMap<Integer, TimesTenPooledConnection>(this.numConnections);
			for (int c = 1; c <= this.numConnections; c++)
			{
				ttconn = createConnection();
				if (this.failoverHandler != null)
					ttconn.addFailoverHandler(this.failoverHandler);
				ttconn.setID(new Integer(c));
				this.freeConn.put(ttconn.getID(), ttconn);
			}
			this.numFreeConnections = this.numConnections;
			this.initialised = true;
		} catch (SQLException e) {
			error = true;
			throw e;
		} finally {
			if (error)
				try {
					this.shutdown();
				} catch (SQLException e) {
					// ignore it
				}
			unlockPool();
		}
	}

	/**
	 * Shuts the pool down and releases its resources.
	 * Once shutdown, it can not then be used until it has again been 
	 * initialised.  In order for the shutdown to succeed, the pool must 
	 * be in the quiescent state (no active connections). Shutting down 
	 * an already shutdown pool, or a not yet initialised pool, is 
	 * considered successful.
	 *
	 * @exception   SQLException
	 *
	 * @see         #initialise
	 * @see         #suspend
	 * @see         #isQuiescent
	 * @see         #waitforQuiescent
	 * @see         #waitforQuiescent(int)
	 */
	public final void shutdown()
			throws SQLException
	{
		lockPool();
		try {
			if (!this.quiescent)
				throw new SQLException(
						className + ":shutdown: not quiescent",
						TTCP_SQLSTATE,
						TTCP_ERR_STATE_ERROR);
			else
			{
				if (this.initialised)
				{
					if (this.freeConn != null)
					{
						Iterator<TimesTenPooledConnection> connit;
						TimesTenPooledConnection ttconn = null;

						connit = this.freeConn.values().iterator();
						while (connit.hasNext())
						{
							ttconn = connit.next();
							connit.remove();
							ttconn.realClose();
						}
						connit = null;
						ttconn = null;
					}
					this.freeConn = null;
					this.busyConn = null;
					this.isClientServer = false;
					this.URL = null;
					this.initialised = false;
					this.pooldead = false;
					this.suspended = true;
					this.quiescent = true;
					this.infailover = false;
					this.failoverEnabled = false;
					this.failoverHandler = null;
				}
			}
		} finally {
			unlockPool();
		}
	}

	/**
	 * Change the number of connections in the pool.
	 * The number can be increased or decreased. Count is the absolute
	 * number of connections desired in the pool. If an error is encountered
	 * during the resizing, the pool may have been partially resized.
	 * The return value indicates how many connections are now in the pool.
	 * The pool must be in the quiescent state for this call to succeed. 
	 *
	 * @param       count   The new number of connections in the pool. This
	 *                      can be larger or smaller than the current number
	 *                      of connections.
	 *
	 * @return              The number of connections in the pool after the
	 *                      (possibly partial) resize.
	 *
	 * @exception   SQLException
	 *
	 * @see         #suspend
	 * @see         #isQuiescent
	 * @see         #waitforQuiescent
	 * @see         #waitforQuiescent(int)
	 */
	public final int resizePool(int count)
			throws SQLException
	{
		if (count < 1)
			throw new SQLException(
					className + ":resizePool: count < 1",
					TTCP_SQLSTATE,
					TTCP_ERR_INVALID_PARAMETER);
		else if (count != this.numConnections)
		{
			lockPool();
			try {
				checkPoolAlive("resizePool");

				if (!this.quiescent)
					throw new SQLException(
							className + ":resizePool: not quiescent",
							TTCP_SQLSTATE,
							TTCP_ERR_STATE_ERROR);
				else if (this.infailover)
					throw new SQLException(
							className + ":resizePool: failover in progress",
							TTCP_SQLSTATE,
							TTCP_ERR_FAILOVER);
				else
				{
					TimesTenPooledConnection ttconn = null;

					if (count > this.numConnections) // grow pool
					{
						TimesTenPooledConnection newconn = null;

						try {
							ttconn = allocateConnection(); // template
							if (ttconn == null)
							{
								killPool();
								throw new SQLException(
										className + ":resizePool: no free connections",
										TTCP_SQLSTATE,
										TTCP_ERR_INTERNAL);
							}

							while (this.numConnections < count)
							{
								newconn = cloneConnection(ttconn);
								this.numConnections++;
								this.numFreeConnections++;
								newconn.setID(new Integer(this.numConnections));
								this.freeConn.put(newconn.getID(), newconn);
							}
						} finally {
							if (ttconn != null)
								deallocateConnection(ttconn);
						}
					}
					else // shrink pool
					{
						while (this.numConnections > count)
						{
							ttconn = this.freeConn.remove(new Integer(this.numConnections));
							if (ttconn == null)
							{
								killPool();
								throw new SQLException(
										className + ":resizePool: connection not found",
										TTCP_SQLSTATE,
										TTCP_ERR_INTERNAL);
							}
							ttconn.realClose();
							this.numConnections--;
							this.numFreeConnections--;
						}
					}
				}
			} finally {
				unlockPool();
			}
		}

		return this.numConnections;
	}

	/**
	 * Adds a prepared statement to all connections in the pool.
	 * The value of 'label' is used to retrieve the statement when
	 * the application needs to use it, and must be unique.
	 * If you add a statement with the same label value as an existing 
	 * statement then it will replace the original statement. The pool 
	 * must be in the quiescent state for this call to succeed.
	 *
	 * @param      label  A (unique) label used to identify the statement.
	 *
	 * @param      sql    The SQL statement text.
	 *
	 * @exception  SQLException
	 *
	 * @see        #removePreparedStmt
	 * @see        #suspend
	 * @see        #isQuiescent
	 * @see        #waitforQuiescent
	 * @see        #waitforQuiescent(int)
	 */
	public final void addPreparedStatement(String label, String sql)
			throws SQLException
	{
		this.addPreparedStatement(label, sql, null);
	}

	/**
	 * Adds a prepared statement, with optimiser hints, to all connections 
	 * in the pool.
	 * The value of 'label' is used to retrieve the statement when
	 * the application needs to use it, and must be unique.
	 * If you add a statement with the same label value as an existing 
	 * statement then it will replace the original statement. 
	 * Multiple optimiser hints may be passed and will be applied to the 
	 * prepared statement. The pool must be in the quiescent state for 
	 * this call to succeed.
	 *
	 * @param      label  A (unique) label used to identify the statement.
	 *
	 * @param      sql    The SQL statement text.
	 *
	 * @param      opthints  An array of optimiser hints. For example:
	 *                       { "call ttOptSetFlag('Scan',0)",
	 *                       "call ttOptSetFlag('Hash',1)" }
	 *
	 * @exception  SQLException
	 *
	 * @see        #removePreparedStmt
	 * @see        #suspend
	 * @see        #isQuiescent
	 * @see        #waitforQuiescent
	 * @see        #waitforQuiescent(int)
	 */
	public final void addPreparedStatement(String label, String sql,
			String[] opthints)
			throws SQLException
	{
		lockPool();
		try {
			checkPoolAlive("addPreparedStatement");

			if (!this.quiescent)
				throw new SQLException(
						className + ":addPreparedStatement: not quiescent",
						TTCP_SQLSTATE,
						TTCP_ERR_STATE_ERROR);
			else
			{
				Iterator<TimesTenPooledConnection> connit;
				boolean error = false;

				try {
					connit = this.freeConn.values().iterator();
					while (connit.hasNext())
					{
						connit.next().createPreparedStmt(label, sql, opthints);
					}
				} catch (SQLException e) {
					error = true;
					throw e;
				} finally {
					if (error)
					{
						connit = this.freeConn.values().iterator();
						while (connit.hasNext())
							try {
								connit.next().closePreparedStmt(label);
							} catch (SQLException e) {
								// ignore it
							}
					}
				}
			}
		} finally {
			unlockPool();
		}
	}

	/**
	 * Removes a prepared statement from all connections in the pool.
	 * The value of 'label' identifies the statement to be removed.
	 * Removing a label value that does not exist is considered
	 * successful. The pool must be in the quiescent state for this 
	 * call to succeed.
	 *
	 * @param      label  Identifies the statement to be removed.
	 *
	 * @exception  SQLException
	 *
	 * @see        #addPreparedStatement
	 * @see        #suspend
	 * @see        #isQuiescent
	 * @see        #waitforQuiescent
	 * @see        #waitforQuiescent(int)
	 */
	public final void removePreparedStmt(String label)
			throws SQLException
	{
		lockPool();
		try {
			checkPoolAlive("removePreparedStmt");

			if (!this.quiescent)
				throw new SQLException(
						className + ":removePreparedStmt: not quiescent",
						TTCP_SQLSTATE,
						TTCP_ERR_STATE_ERROR);
			else
			{
				Iterator<TimesTenPooledConnection> connit;

				connit = this.freeConn.values().iterator();
				while (connit.hasNext())
				{
					try {
						connit.next().closePreparedStmt(label);
					} catch (SQLException e) {
						// ignore it
					}
				}
			}
		} finally {
			unlockPool();
		}
	}

	/**
	 * Adds a callable statement to all connections in the pool.
	 * The value of 'label' is used to retrieve the statement when
	 * the application needs to use it, and must be unique.
	 * If you add a statement with the same label value as an existing 
	 * statement then it will replace the original statement. 
	 * The pool must be in the quiescent state for this call to succeed.
	 *
	 * @param      label  A (unique) label used to identify the statement.
	 *
	 * @param      sql    The SQL statement text.
	 *
	 * @exception  SQLException
	 *
	 * @see        #removeCallableStmt
	 * @see        #suspend
	 * @see        #isQuiescent
	 * @see        #waitforQuiescent
	 * @see        #waitforQuiescent(int)
	 */
	public final void addCallableStatement(String label, String sql)
			throws SQLException
	{
		lockPool();
		try {
			checkPoolAlive("addCallableStatement");

			if (!this.quiescent)
				throw new SQLException(
						className + ":addCallableStatement: not quiescent",
						TTCP_SQLSTATE,
						TTCP_ERR_STATE_ERROR);
			else
			{
				Iterator<TimesTenPooledConnection> connit;
				boolean error = false;

				try {
					connit = this.freeConn.values().iterator();
					while (connit.hasNext())
					{
						connit.next().createCallableStmt(label, sql);
					}
				} catch (SQLException e) {
					error = true;
					throw e;
				} finally {
					if (error)
					{
						connit = this.freeConn.values().iterator();
						while (connit.hasNext())
							try {
								connit.next().closeCallableStmt(label);
							} catch (SQLException e) {
								// ignore it
							}
					}
				}
			}
		} finally {
			unlockPool();
		}
	}

	/**
	 * Removes a callable statement from all connections in the pool.
	 * The value of 'label' identifies the statement to be removed.
	 * Removing a label value that does not exist is considered
	 * successful. The pool must be in the quiescent state for this 
	 * call to succeed.
	 *
	 * @param      label  Identifies the statement to be removed.
	 *
	 * @exception  SQLException
	 *
	 * @see        #addCallableStatement
	 * @see        #suspend
	 * @see        #isQuiescent
	 * @see        #waitforQuiescent
	 * @see        #waitforQuiescent(int)
	 */
	public final void removeCallableStmt(String label)
			throws SQLException
	{
		lockPool();
		try {
			checkPoolAlive("removeCallableStmt");

			if (!this.quiescent)
				throw new SQLException(
						className + ":removeCallableStmt: not quiescent",
						TTCP_SQLSTATE,
						TTCP_ERR_STATE_ERROR);
			else
			{
				Iterator<TimesTenPooledConnection> connit;

				connit = this.freeConn.values().iterator();
				while (connit.hasNext())
				{
					try {
						connit.next().closeCallableStmt(label);
					} catch (SQLException e) {
						// ignore it
					}
				}
			}
		} finally {
			unlockPool();
		}
	}

	/**
	 * Adds a statement to all connections in the pool.
	 * The value of 'label' is used to retrieve the statement when
	 * the application needs to use it, and must be unique.
	 * If you add a statement with the same label value as an existing 
	 * statement then it will replace the original statement. The pool
	 * must be in the quiescent state for this to succeed.
	 *
	 * @param      label  A (unique) label used to identify the statement.
	 *
	 * @exception  SQLException
	 *
	 * @see        #removeStmt
	 * @see        #suspend
	 * @see        #isQuiescent
	 * @see        #waitforQuiescent
	 * @see        #waitforQuiescent(int)
	 */
	public final void addStatement(String label)
			throws SQLException
	{
		lockPool();
		try {
			checkPoolAlive("addStatement");

			if (!this.quiescent)
				throw new SQLException(
						className + ":addStatement: not quiescent",
						TTCP_SQLSTATE,
						TTCP_ERR_STATE_ERROR);
			else
			{
				Iterator<TimesTenPooledConnection> connit;
				boolean error = false;

				try {
					connit = this.freeConn.values().iterator();
					while (connit.hasNext())
					{
						connit.next().createStmt(label);
					}
				} catch (SQLException e) {
					error = true;
					throw e;
				} finally {
					if (error)
					{
						connit = this.freeConn.values().iterator();
						while (connit.hasNext())
							try {
								connit.next().closeStmt(label);
							} catch (SQLException e) {
								// ignore it
							}
					}
				}
			}
		} finally {
			unlockPool();
		}
	}

	/**
	 * Removes a statement from all connections in the pool.
	 * The value of 'label' identifies the statement to be removed.
	 * Removing a label value that does not exist is considered
	 * successful. The pool must be in the quiescent state for this 
	 * call to succeed.
	 *
	 * @param      label  Identifies the statement to be removed.
	 *
	 * @exception  SQLException
	 *
	 * @see        #addStatement
	 * @see        #suspend
	 * @see        #isQuiescent
	 * @see        #waitforQuiescent
	 * @see        #waitforQuiescent(int)
	 */
	public final void removeStmt(String label)
			throws SQLException
	{
		lockPool();
		try {
			checkPoolAlive("removeStmt");

			if (!this.quiescent)
				throw new SQLException(
						className + ":removeStmt: not quiescent",
						TTCP_SQLSTATE,
						TTCP_ERR_STATE_ERROR);
			else
			{
				Iterator<TimesTenPooledConnection> connit;

				connit = this.freeConn.values().iterator();
				while (connit.hasNext())
				{
					try {
						connit.next().closeStmt(label);
					} catch (SQLException e) {
						// ignore it
					}
				}
			}
		} finally {
			unlockPool();
		}
	}

	/**
	 * Sets the pool state to 'suspended'.
	 * While it is suspended, the pool will not give out any new connections
	 * (via getConnection() and its variants) but will allow currently active
	 * connections to be returned via releaseConnection(). Once the last 
	 * active connection is returned, the pool enters the 'quiescent' state.
	 * If there are no active connections at the time suspend() is called, 
	 * then the pool immediately becomes quiescent and suspend() returns true.
	 * Otherwise, suspend() returns false and you must check for the pool 
	 * having become quiescent using the isQuiescent() method.
	 *
	 * @return     True if pool is already quiescent, false if not.
	 *
	 * @exception  SQLException
	 *
	 * @see        #enable
	 * @see        #isQuiescent
	 * @see        #waitforQuiescent
	 * @see        #waitforQuiescent(int)
	 */
	public final boolean suspend()
			throws SQLException
	{
		lockPool();
		try {
			checkPoolAlive("suspend");

			this.suspended = true;
			// check if the pool is quiescent
			Iterator<TimesTenPooledConnection> connit;

			connit = this.busyConn.values().iterator();
			if (!connit.hasNext())
				this.quiescent = true;
		} finally {
			unlockPool();
		}
		return this.quiescent;
	}

	/**
	 * Clears the 'suspended' state for the pool allowing it to be used.
	 * A pool can only be enabled if it has already been initialised.
	 * Once the pool is enabled, connections can be obtained using
	 * the getConnection() methods.
	 *
	 * @exception  SQLException
	 *
	 * @see        #suspend
	 */
	public final void enable()
			throws SQLException
	{
		boolean retVal = false;

		lockPool();
		try {
			checkPoolAlive("enable");

			this.suspended = false;
		} finally {
			unlockPool();
		}
	}

	/**
	 * Indicates if the pool is in the 'initialised' state.
	 * A pool must be initialised before most other methods can be used.
	 *
	 * @return  True if pool is initialised, false otherwise.
	 *
	 * @see     #initialise
	 * @see     #shutdown
	 */
	public final boolean isInitialised()
	{
		return this.initialised;
	}

	/**
	 * Indicates if the pool is alive.
	 * A pool must be alive for most methods to be used. A pool will
	 * become 'dead' if a non-recoverable error is encountered. In this
	 * case the pool must be shutdown using the shutdown() method and
	 * then re-initialised using the initialise() method.
	 *
	 * @return  True if pool is alive, false if it is dead.
	 *
	 * @see     #initialise
	 * @see     #shutdown
	 */
	public final boolean isAlive()
	{
		return this.initialised && !this.pooldead;
	}

	/**
	 * Indicates if the pool is in the 'suspended' state.
	 * When in the suspended state, the pool will not give out any new 
	 * connections. It will however allow the return of currently in use
	 * connections.
	 *
	 * @return  True if pool is suspended, false otherwise.
	 *
	 * @see     #suspend
	 */
	public final boolean isSuspended()
	{
		return this.suspended;
	}

	/**
	 * Indicates if the pool is in the 'quiescent' state.
	 * A pool enters the 'quiescent' state when it is in the 'suspended'
	 * state and the last active connection is returned to the pool. The
	 * pool remains in the quiescent state until it is re-enabled and a
	 * connection is given out via one of the getConnection methods.
	 *
	 * @return  True if pool is quiescent, false otherwise.
	 *
	 * @see     #suspend
	 * @see     #waitforQuiescent
	 * @see     #waitforQuiescent(int)
	 */
	public final boolean isQuiescent()
	{
		return this.quiescent;
	}

	/**
	 * Indicates if the pool is currently processing a failover.
	 *
	 * @return	True if pool is currently processign a failover, false otherwise.
	 *
	 * @see     #waitforFailover
	 * @see     #waitforFailover(int)
	 */
	public final boolean isInFailover()
	{
		return this.infailover;
	}

	/**
	 * Waits for pool to enter 'quiescent' state.
	 * Will wait for ever if required.
	 *
	 * @exception  SQLException
	 *
	 * @see      #suspend
	 * @see      #isQuiescent
	 * @see      #waitforQuiescent(int)
	 */
	public final boolean waitforQuiescent()
			throws SQLException
	{
		checkPoolAlive("waitForQuiescent");

		while (!this.quiescent)
		{
			try {
				Thread.sleep(1); // ~1 millisecond
			} catch (InterruptedException e) {
				// ignore it
			}
		}

		return this.quiescent;
	}

	/**
	 * Waits for pool to enter 'quiescent' state.
	 * Will wait at for at most 'millis' milliseconds. Immediately returns 
	 * true if pool becomes quiescent during this time. If pool does not
	 * become quiescent, returns false.
	 *
	 * @param    millis  Maximum number of milliseconds to wait. If
	 *                   value passed is < 0 then behaviour is the
	 *                   same as waitforQuiescent(). If value passed
	 *                   is 0, behaviour is same as isQuiescent().
	 *
	 * @exception  SQLException
	 *
	 * @see      #suspend
	 * @see      #isQuiescent
	 * @see      #waitforQuiescent
	 */
	public final boolean waitforQuiescent(int millis)
			throws SQLException
	{
		long startTime;
		long now;

		if (millis < 0)
			return waitforQuiescent();
		else if (millis == 0)
			return isQuiescent();

		checkPoolAlive("waitForQuiescent");

		startTime = System.currentTimeMillis();
		now = startTime;
		while (!this.quiescent && ((now - startTime) < millis))
		{
			try {
				Thread.sleep(1); // ~1 miillisecond
			} catch (InterruptedException e) {
				// ignore it
			}
			now = System.currentTimeMillis();
		}

		return this.quiescent;
	}

	/**
	 * Waits for pool to complete a failover.
	 * Will wait for ever if required.
	 *
	 * @exception  SQLException
	 *
	 * @see      #isInFailover
	 * @see      #waitforFailover(int)
	 */
	public final boolean waitforFailover()
			throws SQLException
	{
		checkPoolAlive("waitForFailover");

		while (this.infailover)
		{
			try {
				Thread.sleep(1); // ~1 millisecond
			} catch (InterruptedException e) {
				// ignore it
			}
		}

		return !this.infailover;
	}

	/**
	 * Waits for pool to complete a failover.
	 * Will wait at for at most 'millis' milliseconds. Immediately returns 
	 * true if failover completes during this time. If failover does not
	 * complete during this time, returns false.
	 *
	 * @param    millis  Maximum number of milliseconds to wait. If
	 *                   value passed is < 0 then behaviour is the
	 *                   same as waitforFailover(). If value passed
	 *                   is 0, behaviour is same as isInFailover().
	 *
	 * @exception  SQLException
	 *
	 * @see      #isInFailover
	 * @see      #waitforFailover
	 */
	public final boolean waitforFailover(int millis)
			throws SQLException
	{
		long startTime;
		long now;

		if (millis < 0)
			return waitforFailover();
		else if (millis == 0)
			return isInFailover();

		checkPoolAlive("waitForFailover");

		startTime = System.currentTimeMillis();
		now = startTime;
		while (this.infailover && ((now - startTime) < millis))
		{
			try {
				Thread.sleep(1); // ~1 millisecond
			} catch (InterruptedException e) {
				// ignore it
			}
			now = System.currentTimeMillis();
		}

		return !this.infailover;
	}

	/**
	 * Indicates if this pool is a client/server pool or a direct mode pool.
	 *
	 * @return  True if pool is client/server, false otherwise. If the pool
	 *          has not been initialised, returns false.
	 */
	public final boolean isClientServer()
	{
		return this.isClientServer;
	}

	/**
	 * Returns the URL value for this pool.
	 *
	 * @return  URL value set for pool. If the pool has not yet been
	 *          initialised, returns null.
	 *
	 * @see     #initialise
	 */
	public final String getURL()
	{
		return this.URL;
	}

	/**
	 * Returns the total number of connections in the pool.
	 *
	 * @return  Number of connections in pool.
	 */
	public final int getPoolSize()
	{
		return this.numConnections;
	}

	/**
	 * Returns the number of free connections in the pool.
	 *
	 * @return  Number of free connections in pool as of the time this 
	 *          method is called. If the pool has not been initialised,
	 *          returns 0.
	 */
	public final int getFreePoolSize()
	{
		return this.numFreeConnections;
	}
}
