package com.fss.testpackage;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import com.fss.newfo.common.sql.SQLStatement;
import com.fss.timesten.adapter.DBMgr;
import com.fss.timesten.adapter.TimesTenPooledConnection;
import com.timesten.jdbc.TimesTenCallableStatement;

public class testStoreMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Khoi tao DB
		DBMgr obj = new DBMgr();
		obj.initConnectionPool("jdbc:timesten:client:ttc_server=192.168.1.30;tcp_port=53397;ttc_server_dsn=NEWFOTEST;oraclepwd=NEWFOTEST;", "NEWFOTEST", "NEWFOTEST", 10);
	
		TimesTenPooledConnection connection = null;
		try {
			connection = obj.getConnection();
			
			long start = System.currentTimeMillis();
			//1.BUY
			//buy(connection);
			
			
			//2. Get PP0
			//getPP0(connection);
			
			//3.fn_get_asset_amt
			//fn_get_asset_amt(connection);
			
			//4.fn_get_order_ppse_amt
			fn_get_order_ppse_amt(connection);
			
			
			long end = System.currentTimeMillis();
			NumberFormat formatter = new DecimalFormat("#0.000000000000000");
			System.out.println("AAA Execution time is " + formatter.format((end - start)) + " miliseconds");
			
			connection.commit();
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		
			e.printStackTrace();
		}finally{
			obj.closeConnection(connection);
		}
	}
	
	/**
	 * @description Buy stock
	 * @param connection
	 * @throws SQLException
	 */
	public static void buy(TimesTenPooledConnection connection) throws SQLException{
		TimesTenCallableStatement statement = null;
		
		statement = connection.getCallableStmt("sp_process_order_buy");
		statement.registerOutParameter(1, Types.VARCHAR);
		statement.registerOutParameter(2, Types.DECIMAL);
		statement.registerOutParameter(3, Types.VARCHAR);

		statement.setLong(4, 100);
		statement.setBigDecimal(5, new BigDecimal(200));
		//statement.setString(6,"201507160002188245");//0001000008, normal
		statement.setString(6,"201508010000681660");//0001000006, margin
		
		statement.execute();
		
		String errorCode = statement.getString(1);
		System.out.println(errorCode);
	}
	
	
	/**
	 * @description Get PP0
	 * @param connection
	 * @throws SQLException
	 */
	public static void getPP0(TimesTenPooledConnection connection) throws SQLException{
		TimesTenCallableStatement statement = null;
		
		statement = connection.getCallableStmt("sp_get_pp_pp0");
		statement.registerOutParameter(1, Types.VARCHAR);
		statement.registerOutParameter(2, Types.DECIMAL);
		

		statement.setBigDecimal(3, new BigDecimal(200));//p_ordamt
		statement.setString(4, "0001000006");//f_acctno
		
		statement.setBigDecimal(5, new BigDecimal(200));//f_bal
		statement.setBigDecimal(6, new BigDecimal(200));//f_t0value
		statement.setBigDecimal(7, new BigDecimal(200));//f_td
		statement.setBigDecimal(8, new BigDecimal(200));//f_payable
		statement.setBigDecimal(9, new BigDecimal(200));//f_debt
		statement.setBigDecimal(10, new BigDecimal(200));//f_ratebrk
		statement.setBigDecimal(11, new BigDecimal(200));//f_advbal
		statement.setBigDecimal(12, new BigDecimal(200));//f_crlimit
		statement.setBigDecimal(13, new BigDecimal(200));//f_rate_margin
		statement.setBigDecimal(14, new BigDecimal(200));//f_price_margin
		
		
		statement.setString(15, "MS TopUp TPB");//f_basketid
		statement.setString(16, "PPSE");//f_fomulacd

		statement.setBigDecimal(17, new BigDecimal(200));//f_bod_adv
		
		statement.execute();
		
		String errorCode = statement.getString(1);
		System.out.println("errorCode:" +errorCode);
		System.out.println("PP0:" +statement.getString(2));
	}
	
	/**
	 * @description fn_get_asset_amt
	 * @param connection
	 * @throws SQLException
	 */
	public static void fn_get_asset_amt(TimesTenPooledConnection connection) throws SQLException{
		TimesTenCallableStatement statement = null;
		
		statement = connection.getCallableStmt("fn_get_asset_amt");
		statement.registerOutParameter(1, Types.DECIMAL);
		statement.setString(2,"0001000006");//0001000006, margin
		
		statement.execute();;
		
		System.out.println("fn_get_asset_amt:" +statement.getString(1));
	}
	
	
	/**
	 * @description fn_get_order_ppse_amt
	 * @param connection
	 * @throws SQLException
	 */
	public static void fn_get_order_ppse_amt(TimesTenPooledConnection connection) throws SQLException{
		TimesTenCallableStatement statement = null;
		
		statement = connection.getCallableStmt("fn_get_order_ppse_amt");
		statement.registerOutParameter(1, Types.DECIMAL);
		statement.setString(2,"0001000006");//0001000006, margin
		statement.setString(3,"PPSE");//f_fomulacd
		
		statement.execute();;
		
		System.out.println("fn_get_order_ppse_amt:" +statement.getString(1));
	}
	

}
