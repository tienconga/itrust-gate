package thread.turning;

import java.util.Timer;
import java.util.TimerTask;

/**
 * 
 * @author do.tran.tien
 *
 */
public class LoadTestFO {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoadTestFO test = new LoadTestFO();
		test.test();
		//test.loadTest();
	}

	public void test() {
		Timer timer = new Timer();
		TimerTask task = new CheckTimeoutTask();
		timer.schedule(task, 0, 1000);
	}

	class CheckTimeoutTask extends TimerTask {
		public void run() {
			try {
				doTask();
			} catch (Exception ex) {
				System.out.println(ex.getMessage());
			}
		}
	}

	public void doTask() {
		/*FrontThreadMgr threadMgr = FrontThreadMgr.getThreadMgr();
		int rtn = 0;
		rtn = threadMgr.fireEmptyThread(1);*/
		 loadTest();
	}

	public void loadTest() {

		long start = System.currentTimeMillis();
		for (int i = 0; i < 100; i++) {
			FrontThreadMgr threadMgr = FrontThreadMgr.getThreadMgr();
			int rtn = threadMgr.fireEmptyThread(i,"Content " + i);

			//System.out.println(i);
		}
		
		//System.out.println("Init OK.");

		/*long end = System.currentTimeMillis();
		NumberFormat formatter = new DecimalFormat("#0.000000000000000");
		System.out.println("AAA Execution time is " + formatter.format((end - start) / 1000d) + " seconds");
*/
	}

}
