package thread.turning;



/**
 * 
 * @author do.tran.tien
 *
 */
public class FrontThreadBeforeWork implements Runnable {

	long id = 0;
	String strContent = "";

	public FrontThreadBeforeWork(long id, String content) {
		//this.id = Thread.currentThread().getId();
		this.id = id;
		strContent = content;

	}

	private void doMyTask() throws InterruptedException {
		placeOrder();
		
		//get_PPSE_Data();
		//Thread.sleep(3000);
		//System.out.println("===ID:" +id + ", Content:" + strContent);
	}

	
	private void placeOrder(){/*
		String str = "{\"msgtype\":\"tx0001\",\"requestid\":\"00022\",\"userid\":\"0002\",\"classcd\":\"DLO\"," +
				"\"via\":\"F\",\"typecd\":\"LO\",\"subtypecd\":\"LO\",\"symbol\":\"ACB\",\"qtty\":100," +
				"\"acctno\":\"RANDOM_ACCTNO\",\"price\":18000}"; //0001000002
		str = str.replaceAll("RANDOM_ACCTNO", getAcctno());
		FrontGateServiceService service = new FrontGateServiceService();
		IFrontGateService obj = service.getFrontGateServicePort();
		String result = obj.sendMessage(str);
		System.out.println(result);
	*/}
	
	private void get_PPSE_Data(){/*
		try {
			String str = "{\"msgtype\":\"tx6000\",\"acctno\":\"RANDOM_ACCTNO\",\"symbol\":\"ABI\",\"price\":13000}";
			FrontGateServiceService service = new FrontGateServiceService();
			IFrontGateService obj = service.getFrontGateServicePort();
			
			int minimum = 1;
			int maximum = 9999;
			int randomNum = minimum + (int)(Math.random()*maximum); 
			
			String acctno= "000100" + randomNum;
			
			if (acctno.length() == 7){
				acctno= "000100000" + randomNum;
			}else if (acctno.length() == 8){
				acctno= "00010000" + randomNum;
			}else if (acctno.length() == 9){
				acctno= "0001000" + randomNum;
			}
			
			str = str.replaceAll("RANDOM_ACCTNO", acctno);
			
			
			String result = obj.getData(str);
			System.out.println("ID:" + result);
		} catch (Exception_Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	*/}
	private String getAcctno(){
		int minimum = 1;
		int maximum = 9999;
		int randomNum = minimum + (int)(Math.random()*maximum); 
		
		String acctno= "000100" + randomNum;
		
		if (acctno.length() == 7){
			acctno= "000100000" + randomNum;
		}else if (acctno.length() == 8){
			acctno= "00010000" + randomNum;
		}else if (acctno.length() == 9){
			acctno= "0001000" + randomNum;
		}
		
		
		return acctno;
	}
	
	public void run() {
		try {
			doMyTask();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.exit(1);
		}

	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FrontThreadBeforeWork test = new FrontThreadBeforeWork(1, "");
		test.placeOrder();
		//test.loadTest();
	}

}
