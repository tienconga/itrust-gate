package thread.turning;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class FrontThreadMgr {

	private static volatile FrontThreadMgr threadMgr;

	private ThreadPoolExecutor executor;

	public static final int DEFAULT_QUEUE_SIZE = 100;

	public static void initThreadMgr(int size, long timeout, int queueSize) {
		threadMgr = new FrontThreadMgr(size, timeout, queueSize);
	}

	public static FrontThreadMgr getThreadMgr() {

		if (threadMgr == null) {
			threadMgr = new FrontThreadMgr(500, 1000, DEFAULT_QUEUE_SIZE);
		} else {
		}

		return threadMgr;
	}

	public FrontThreadMgr(int size, long timeout, int queueSize) {
		//BlockingQueue<Runnable> queue = (BlockingQueue<Runnable>) new ArrayBlockingQueue<Runnable>(queueSize);
		BlockingQueue<Runnable> queue = (BlockingQueue<Runnable>) new LinkedBlockingQueue<Runnable>();
		//new LinkedBlockingQueue<Runnable>()
		this.executor = new ThreadPoolExecutor(size, size, timeout, TimeUnit.MILLISECONDS, queue);

	}

	public int fireEmptyThread(long id, String content) {

		try {
			FrontThreadBeforeWork bWork = new FrontThreadBeforeWork(id, content);
			this.executor.execute(bWork);
			return -1;
		} catch (RejectedExecutionException e) {
			System.out.println("Error:" + e.getMessage());
			System.exit(1);
			return 0;
		}
	}

}
