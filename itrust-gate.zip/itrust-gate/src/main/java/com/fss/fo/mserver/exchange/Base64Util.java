package com.fss.fo.mserver.exchange;

import java.io.UnsupportedEncodingException;

//import org.apache.mina.util.Base64;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author DuongLH convert from and to using base64 encoding to avoid CR LF
 * 
 */
public class Base64Util {
	private final String CHARSET = "UTF-8";
	private final Logger log = LoggerFactory.getLogger(Base64Util.class);

	/**
	 * Convert Base64 Encoding string reversed to original byte[]
	 * 
	 * @param uncompressed
	 * @return original bytes
	 */
	public byte[] compressBytes(String uncompressed) {
		try {
			return Base64.decodeBase64(uncompressed.getBytes(CHARSET));
		} catch (UnsupportedEncodingException e) {
			log.error("compressBytes.:" + uncompressed, e);
		}
		return null;
	}

	/**
	 * Convert byte[] to Base64 Encoding
	 * 
	 * @param strBytes
	 *            input bytes
	 * @return Base64 String to transmit
	 */
	public String uncompressBytes(byte[] strBytes) {
		try {
			return new String(Base64.encodeBase64(strBytes), CHARSET);
		} catch (UnsupportedEncodingException e) {
			log.error("uncompressBytes.:" + new String(strBytes), e);
			return null;
		}
	}
}
