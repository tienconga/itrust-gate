﻿package com.fss.fo.mserver.exchange;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fss.fo.mserver.exchange.CSIDXInforProtos.CSIDXInfor;
import com.fss.fo.mserver.exchange.MarketInforProtos.MarketInfor;
import com.fss.fo.mserver.exchange.PTMatchProtos.PTMatch;
import com.fss.fo.mserver.exchange.PutThroughInfoProtos.PutThroughInfo;
import com.fss.fo.mserver.exchange.StockInforProtos.StockInfor;
import com.fss.fo.mserver.exchange.TransLogProtos.TransLog;

public class SerializeUtils {
	private final static Logger logger = LoggerFactory
			.getLogger(SerializeUtils.class);

	public static byte[] GetBytes(int value) {
		ByteBuffer buffer = ByteBuffer.allocate(4).order(
				ByteOrder.nativeOrder());
		buffer.putInt(value);
		return buffer.array();
	}

	public static int FromBytes(byte[] value) {
		ByteBuffer buffer = ByteBuffer.allocate(4).order(
				ByteOrder.nativeOrder());
		buffer.put(value);
		buffer.flip();
		return buffer.getInt();
	}

	private static Base64Util base64Util = new Base64Util();

	public static String Serialize(Object obj) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			byte[] serializedBytes = null;
			if (obj instanceof MarketInfor) {
				MarketInfor proto = (MarketInfor) obj;
				serializedBytes = proto.toByteArray();
			}
			if (serializedBytes != null) {
				int lengthValue = serializedBytes.length;
				baos.write(GetBytes(getTypeIndex(obj)));
				baos.write(GetBytes(lengthValue));
				baos.write(serializedBytes);
			}
		} catch (IOException e) {
			logger.error("Serialize.:IOException.:" + obj, e);
		}
		String stringBase64 = base64Util.uncompressBytes(baos.toByteArray());
		return stringBase64;
	}

	public static Object Deserialize(String stringBase64) {
		try {
			byte[] byteAfter64 = base64Util.compressBytes(stringBase64);
			ByteArrayInputStream bais = new ByteArrayInputStream(byteAfter64);
			byte[] headerPresen = new byte[4];
			byte[] lengthPresen = new byte[4];
			bais.read(headerPresen, 0, 4);
			bais.read(lengthPresen, 0, 4);
			int currentTypeIndex = FromBytes(headerPresen);
			int currentLength = FromBytes(lengthPresen);
			byte[] serializedBytes = new byte[currentLength];
			bais.read(serializedBytes, 0, currentLength);
			switch (currentTypeIndex) {
			case 0:
				return StockInfor.parseFrom(serializedBytes);
			case 1:
				return MarketInfor.parseFrom(serializedBytes);
			case 2:
				return TransLog.parseFrom(serializedBytes);
			case 3:
				return PutThroughInfo.parseFrom(serializedBytes);
			case 4:
				return PTMatch.parseFrom(serializedBytes);
			case 5:
				return CSIDXInfor.parseFrom(serializedBytes);
			default:
				return null;
			}
		} catch (Exception e) {
			logger.error("Deserialize.:" + stringBase64, e);
			return null;
		}
	}

	static Class[] allTypes = new Class[] {
			(StockInfor.newBuilder()).getClass(),
			(MarketInfor.newBuilder()).getClass(),
			(TransLog.newBuilder()).getClass(),
			(PutThroughInfo.newBuilder()).getClass(),
			(PTMatch.newBuilder()).getClass(),
			(CSIDXInfor.newBuilder()).getClass()};

	static int getTypeIndex(Object o) {
		for (int i = 0; i < allTypes.length; i++) {
			if (allTypes[i].equals(o.getClass()))
				return i;
		}
		return 0;
	}

	static Class getTypeFromIndex(int index) {
		if (index >= 0 && index < allTypes.length)
			return allTypes[index];
		else
			return null;
	}
}
