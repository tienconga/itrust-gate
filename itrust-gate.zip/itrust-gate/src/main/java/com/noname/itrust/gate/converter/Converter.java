package com.noname.itrust.gate.converter;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fss.newfo.common.constant.Fields;
import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.json.UpperCasePropertyNamingStrategy;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.github.fge.jackson.JsonLoader;

public class Converter {
	public static String convertQuote2String(Quote quote){
		String result = "";
		try {
			ObjectMapper mapper = new ObjectMapper();
			mapper.setSerializationInclusion(Include.NON_NULL);
			mapper.setSerializationInclusion(Include.NON_DEFAULT);
			mapper.setPropertyNamingStrategy(new UpperCasePropertyNamingStrategy());
			
			result = mapper.writeValueAsString(quote);
			// Validate data

			// Remove fields for delivering
			ObjectNode objNode = (ObjectNode) JsonLoader.fromString(result);
			objNode.remove(Fields.OBJECT_TYPE);
			result = objNode.toString();
		} catch (Exception e) {
			SLF4JLoggerProxy.error(Converter.class, e);
		}
		
		return result;
		
	}

}
