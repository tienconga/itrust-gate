package com.noname.itrust.gate.ors.response;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fss.newfo.common.model.ORSObject;
import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.data.adaper.TimesTenPooledConnection;
import com.noname.itrust.gate.data.adaper.TimestenManager;
import com.noname.itrust.gate.data.dao.DAOCommon;
import com.noname.itrust.gate.rules.CPORule;
import com.noname.itrust.gate.rules.OCORule;
import com.noname.itrust.gate.rules.PCORule;
import com.noname.itrust.gate.rules.SORule;
import com.noname.itrust.gate.sending.NewOrderSending;
import com.noname.itrust.gate.sql.SQLStatement;
import com.timesten.jdbc.TimesTenPreparedStatement;

@Service
public class ORSResponse {
	
	@Autowired
	private TimestenManager timestenManager;
	
	public void proces(ORSObject orsObject){
		String orderid = orsObject.getOrderid();
		String singalType = orsObject.getSingalType();
		String exchange = orsObject.getExchange();
		if(singalType != null && singalType.equalsIgnoreCase("CC")){//xac nhan lenh
			processConfirmCancel(orderid,exchange);
		}else if(singalType != null && singalType.equalsIgnoreCase("CD")){ //khop lenh
			processConfirmDeal(orsObject);
		}	
	}
	
	private void processConfirmCancel(String orderid,String exchange){
		Connection conn = null; 
        ConnectionManager mgr = new ConnectionManager();
        CallableStatement callableStatement = null;
        ResultSet rs = null;
        
        boolean cancelFlag = false;
        String log = "";
        String p_err_code = "After execute:";
        try {
        	conn = mgr.getConnection();
        	
			callableStatement = conn.prepareCall(ConnectionManager.sqlMap.get(SQLStatement.KEY_CONFIRM_CANCEL_ORDER));
			callableStatement.registerOutParameter(1, Types.VARCHAR);// p_err_code
			callableStatement.registerOutParameter(2, Types.VARCHAR);// p_out_message
			callableStatement.registerOutParameter(3, Types.VARCHAR);// p_out_result
			callableStatement.registerOutParameter(4, Types.VARCHAR);// p_out_orderid
			callableStatement.registerOutParameter(5, Types.VARCHAR);// p_out_ordertype
			callableStatement.registerOutParameter(6, Types.NUMERIC);// p_out_qtty
			callableStatement.registerOutParameter(7, Types.VARCHAR);// p_out_quoteid
			callableStatement.setString(8, orderid); // p_orderid
			callableStatement.setString(9, exchange);// p_exchange
							
			log = "store parametter -|  CSPKS_HFT_RESPONSE_ORS.sp_confirm_cancel_order |  p_orderid: " + orderid
			+ "|  p_exchange:" + exchange;
			
			SLF4JLoggerProxy.info(this, log);
			callableStatement.execute();
			p_err_code = callableStatement.getString(1);
			if(!p_err_code.equalsIgnoreCase("0") ){
				SLF4JLoggerProxy.error(this, "Could not confirm cancel order:" + orderid + ",p_err_code:" + p_err_code);
			}else{
				String p_out_result = callableStatement.getString(3);
				String p_out_orderid = callableStatement.getString(4);
				String p_out_ordertype = callableStatement.getString(5);
				int p_out_qtty = callableStatement.getInt(6);
				String p_out_message = callableStatement.getString(2);
				String p_out_quoteid = callableStatement.getString(7);
				
				SLF4JLoggerProxy.info(this, "sp_confirm_cancel_order result, p_out_result:" + p_out_result + "," +
						" p_out_orderid:" + p_out_orderid + ",p_out_ordertype:" + p_out_ordertype + 
						",p_out_qtty:" + p_out_qtty + ", p_out_message:" +p_out_message + ", p_out_quoteid:" + p_out_quoteid);
				
				if(p_out_orderid != null && p_out_ordertype != null && p_out_ordertype.equals("PCO")){
					
					//check session
					DAOCommon obj = new DAOCommon();
					cancelFlag = true;
					if(exchange != null && exchange.equalsIgnoreCase("HSX")){
						if(HandlerCacheData.hsxSession.equalsIgnoreCase("END") || HandlerCacheData.hsxSession.equalsIgnoreCase("CROSS")){
							obj.updateStatus(p_out_quoteid, "A", p_out_ordertype); //CHO NGAY HOM SAU KICH HOAT
						}
					}else if(exchange != null && exchange.equalsIgnoreCase("HNX") || HandlerCacheData.hsxSession.equalsIgnoreCase("CROSS")){
						if(HandlerCacheData.hnxSession.equalsIgnoreCase("END")){
							obj.updateStatus(p_out_quoteid, "A", p_out_ordertype); //CHO NGAY HOM SAU KICH HOAT
						}
					}else if(exchange != null && exchange.equalsIgnoreCase("UPCOM") || HandlerCacheData.hsxSession.equalsIgnoreCase("CROSS")){
						if(HandlerCacheData.upcomSession.equalsIgnoreCase("END")){
							obj.updateStatus(p_out_quoteid, "A", p_out_ordertype); //CHO NGAY HOM SAU KICH HOAT
						}
					}else{
						//sinh lenh moi
						PCORule rule = new PCORule();
						rule.generalNewOrder(p_out_orderid, p_out_qtty,exchange);
					}
					
				}else if(p_out_orderid != null && p_out_ordertype != null && p_out_ordertype.equals("CPO")){
					//sinh lenh moi
					CPORule rule = new CPORule();
					rule.placeNewOrder(p_out_orderid);
					cancelFlag = true;
				}
				
				//Cap nhat trang thai lenh cha
				if(p_out_result != null && p_out_quoteid != null && p_out_quoteid != null && p_out_result.equalsIgnoreCase("C") && !cancelFlag){
					int count = getOrderInfo(p_out_quoteid);
					SLF4JLoggerProxy.info(this, "getOrderInfo, p_out_quoteid:" + p_out_quoteid + ", count:" + count);
					if(count == 0){//tat ca cac lenh con da huy
						DAOCommon obj = new DAOCommon();
						if(exchange != null && exchange.equalsIgnoreCase("HSX")){
							if(HandlerCacheData.hsxSession.equalsIgnoreCase("END") || HandlerCacheData.hsxSession.equalsIgnoreCase("CROSS")){
								obj.updateStatus(p_out_quoteid, "A", p_out_ordertype); //CHO NGAY HOM SAU KICH HOAT
							}else{
								obj.updateStatus(p_out_quoteid, "E", p_out_ordertype);
							}
						}else if(exchange != null && exchange.equalsIgnoreCase("HNX")){
							if(HandlerCacheData.hnxSession.equalsIgnoreCase("END") || HandlerCacheData.hsxSession.equalsIgnoreCase("CROSS")){
								obj.updateStatus(p_out_quoteid, "A", p_out_ordertype); //CHO NGAY HOM SAU KICH HOAT
							}else{
								obj.updateStatus(p_out_quoteid, "E", p_out_ordertype);
							}
						}else if(exchange != null && exchange.equalsIgnoreCase("UPCOM")){
							if(HandlerCacheData.upcomSession.equalsIgnoreCase("END") || HandlerCacheData.hsxSession.equalsIgnoreCase("CROSS")){
								obj.updateStatus(p_out_quoteid, "A", p_out_ordertype); //CHO NGAY HOM SAU KICH HOAT
							}else{
								obj.updateStatus(p_out_quoteid, "E", p_out_ordertype);
							}
						}
						
					}
				}
			}
			
			conn.commit();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {				
				if (rs != null) {
					rs.close();
				}
				if (callableStatement != null) {
					callableStatement.clearParameters();
					callableStatement.close();
					callableStatement = null;
				}
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
			
			SLF4JLoggerProxy.info(this, "process p_err_code:" +p_err_code);
		}
	}
	
	
	private void processConfirmDeal(ORSObject orsObject){
		
		String orderid = orsObject.getOrderid();
		String classcd = NewOrderSending.activeOrderMap.get(orderid);
		if(null == classcd){
			SLF4JLoggerProxy.info(this, "Not Process for other orders of condition order, orderid:" + orderid);
			return;
		}else if(classcd.equalsIgnoreCase("OCO")){
			processDealOCO(orsObject);
		}else{
			Connection conn = null; 
	        ConnectionManager mgr = new ConnectionManager();
	        CallableStatement callableStatement = null;
	        ResultSet rs = null;
	        
	        String log = "";
	        String p_err_code = "After execute:";
	        try {
	        	conn = mgr.getConnection();
	        	
				callableStatement = conn.prepareCall(ConnectionManager.sqlMap.get(SQLStatement.KEY_CONFIRM_DEAL_ORDER));
				callableStatement.registerOutParameter(1, Types.VARCHAR);// p_err_code
				callableStatement.registerOutParameter(2, Types.VARCHAR);// p_out_message
				callableStatement.registerOutParameter(3, Types.VARCHAR);// p_out_result
				callableStatement.registerOutParameter(4, Types.VARCHAR);// p_out_orderid
				callableStatement.registerOutParameter(5, Types.VARCHAR);// p_out_ordertype
				callableStatement.registerOutParameter(6, Types.NUMERIC);// p_out_qtty
				callableStatement.setString(7, orsObject.getOrderid()); // p_orderid
				callableStatement.setString(8, orsObject.getExchange());// p_exchange
								

				log = "store parametter -|  CSPKS_HFT_RESPONSE_ORS.sp_confirm_deal_order |  p_orderid: " + orsObject.getOrderid()
				+ "|  p_exchange:" + orsObject.getExchange();
				
				SLF4JLoggerProxy.info(this, log);
				callableStatement.execute();
				p_err_code = callableStatement.getString(1);
				if(!p_err_code.equalsIgnoreCase("0") ){
					SLF4JLoggerProxy.error(this, "Could not process deal order:" + orsObject.getOrderid() + ",p_err_code:" + p_err_code);
				}else{
					String p_out_result = callableStatement.getString(3);
					String p_out_ordertype = callableStatement.getString(5);
					SLF4JLoggerProxy.info(this, "123456, p_out_result:" + p_out_result + ", p_out_ordertype:" + p_out_ordertype);
					if(p_out_result != null && p_out_result.equalsIgnoreCase("Y") && 
							p_out_ordertype != null && p_out_ordertype.equals("OTO")){ //lenh mua OTO da khop het
						
						String quoteid = callableStatement.getString(4);
						if(quoteid != null){
							String symbol = callableStatement.getString(2);
							//Quote quote = HandlerCacheData.otoMap.get(orsObject.getSymbol()).get(quoteid);
							Quote quote = HandlerCacheData.otoMap.get(symbol).get(quoteid);
							if(quote != null){
								quote.setSide("S");
								quote.setTypecd("LO");
								quote.setSubtypecd("LO");
								quote.setPrice(quote.getOrderprice());
								quote.setStatus("P");//trang thai cho tin hieu khop lenh tu so ve de kich hoat
							}
							
							
							/*Quote newQuote = new Quote();
							newQuote.setQuoteid(quoteid);
							newQuote.setSide("S");*/
							
							//TODO: kiem tra gia khop moi nhat cua ma chung khoan de kich hoat ngay
							//kich hoat lenh dung OTO
							//OTORule rule = new OTORule();
							//rule.process(null, quote);
						}
						
					}else if(p_out_result != null && p_out_result.equalsIgnoreCase("W") && 
							p_out_ordertype != null && p_out_ordertype.equals("OTO")){ //Lenh khop chua kip dong bo tu timesten->oracle
						retryOTODeal(orsObject);
					}else if(p_out_ordertype != null && p_out_ordertype.equals("SO")){ //lenh chia SO da khop
						String quoteid = callableStatement.getString(4);
						if(quoteid != null){
							int remain_qtty = getRemainQtty(orsObject.getOrderid());
							if(remain_qtty == 0){
								SORule rule = new SORule();
								rule.divideOrder_type_D(quoteid);
							}
						}
					}		
				}
				
				conn.commit();
			} catch (SQLException e) {
				SLF4JLoggerProxy.error(this, e);
			} catch (Exception e) {
				SLF4JLoggerProxy.error(this, e);
			}finally{
				try {				
					if (rs != null) {
						rs.close();
					}
					if (callableStatement != null) {
						callableStatement.clearParameters();
						callableStatement.close();
						callableStatement = null;
					}
					mgr.closeConnection(conn);
				} catch (SQLException e) {				
					SLF4JLoggerProxy.error(this, e);
				}
				
				SLF4JLoggerProxy.info(this, "process p_err_code:" +p_err_code);
			}
		}
	}
		
	private synchronized void processDealOCO(ORSObject orsObject){
		Connection conn = null; 
        ConnectionManager mgr = new ConnectionManager();
        CallableStatement callableStatement = null;
        ResultSet rs = null;
        
        String log = "";
        String p_err_code = "After execute:";
        try {
        	conn = mgr.getConnection();
        	 
        	Thread.sleep(500);
        	
			callableStatement = conn.prepareCall(ConnectionManager.sqlMap.get(SQLStatement.KEY_CONFIRM_DEAL_ORDER_OCO));
			callableStatement.registerOutParameter(1, Types.VARCHAR);// p_err_code
			callableStatement.registerOutParameter(2, Types.VARCHAR);// p_out_message
			callableStatement.registerOutParameter(3, Types.VARCHAR);// p_out_result
			callableStatement.registerOutParameter(4, Types.VARCHAR);// p_out_orderid
			callableStatement.registerOutParameter(5, Types.VARCHAR);// p_out_ordertype
			callableStatement.registerOutParameter(6, Types.NUMERIC);// p_out_qtty
			callableStatement.setString(7, orsObject.getOrderid()); // p_orderid
			callableStatement.setString(8, orsObject.getExchange());// p_exchange
			callableStatement.registerOutParameter(9, OracleTypes.CURSOR); // p_out_recordset
							

			log = "store parametter -|  CSPKS_HFT_RESPONSE_ORS.sp_confirm_deal_order_oco |  p_orderid: " + orsObject.getOrderid()
			+ "|  p_exchange:" + orsObject.getExchange();
			
			SLF4JLoggerProxy.info(this, log);
			callableStatement.execute();
			p_err_code = callableStatement.getString(1);
			if(!p_err_code.equalsIgnoreCase("0") ){
				SLF4JLoggerProxy.error(this, "Could not process deal order:" + orsObject.getOrderid() + ",p_err_code:" + p_err_code);
			}else{
				String p_out_result = callableStatement.getString(3);
				String p_out_ordertype = callableStatement.getString(5);
				SLF4JLoggerProxy.info(this, "123456, p_out_result:" + p_out_result + ", p_out_ordertype:" + p_out_ordertype);
				
				 //lenh mua OCO da khop 
				String quoteid = p_out_result;
				String cancelOrderid = callableStatement.getString(4);
				String p_out_message = callableStatement.getString(2);
				SLF4JLoggerProxy.info(this, "OCO ==============quoteid :" + quoteid + ", cancelOrderid: " 
				+ cancelOrderid + ", p_out_message: " + p_out_message + ",Orderid:" + orsObject.getOrderid());
				
				if(p_out_message != null && p_out_message.equalsIgnoreCase("W")){
					SLF4JLoggerProxy.info(this, "wait. Other order not yet place to ORS, so can not cancel...");
					
					Thread.sleep(3000);
					
					//TODO: fix case : lenh 1 khop het, lenh 2 khop 1 nua -> sinh yeu cau trong active_order
					List<String> list = DAOCommon.getCancelOrder(quoteid,  orsObject.getOrderid());
					for(int i = 0; i < list.size(); i++){
						OCORule rule = new OCORule();
						rule.cancelOrder(list.get(i),quoteid);
					}
					
				}else{
					//cancel other order
					SLF4JLoggerProxy.info(this, "ACTIVE OCO CANCEL ORDER................." + cancelOrderid);
					//
					rs = (ResultSet) callableStatement.getObject(9); //list suborder that will cancel
					while (rs.next()) {
						String cancel_orderid = rs.getString("ORDERID");
						OCORule rule = new OCORule();
						rule.cancelOrder(cancel_orderid,quoteid);
					}

				}
			}
			
			conn.commit();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {				
				if (rs != null) {
					rs.close();
				}
				if (callableStatement != null) {
					callableStatement.clearParameters();
					callableStatement.close();
					callableStatement = null;
				}
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
			
			SLF4JLoggerProxy.info(this, "process p_err_code:" +p_err_code);
		}
	}
	
	private void retryOTODeal(ORSObject orsObject){	
		Connection conn = null; 
        ConnectionManager mgr = new ConnectionManager();
        CallableStatement callableStatement = null;
    
        String log = "";
        String p_err_code = "After execute:";
        try {
        	Thread.sleep(2000);
        	conn = mgr.getConnection();
        	
			callableStatement = conn.prepareCall(ConnectionManager.sqlMap.get(SQLStatement.KEY_CONFIRM_DEAL_ORDER));
			callableStatement.registerOutParameter(1, Types.VARCHAR);// p_err_code
			callableStatement.registerOutParameter(2, Types.VARCHAR);// p_out_message
			callableStatement.registerOutParameter(3, Types.VARCHAR);// p_out_result
			callableStatement.registerOutParameter(4, Types.VARCHAR);// p_out_orderid
			callableStatement.registerOutParameter(5, Types.VARCHAR);// p_out_ordertype
			callableStatement.registerOutParameter(6, Types.NUMERIC);// p_out_qtty
			callableStatement.setString(7, orsObject.getOrderid()); // p_orderid
			callableStatement.setString(8, orsObject.getExchange());// p_exchange
							

			log = "=====RETRY CALL store parametter -|  CSPKS_HFT_RESPONSE_ORS.sp_confirm_deal_order |  p_orderid: " + orsObject.getOrderid()
			+ "|  p_exchange:" + orsObject.getExchange();
			
			SLF4JLoggerProxy.info(this, log);
			callableStatement.execute();
			p_err_code = callableStatement.getString(1);
			if(!p_err_code.equalsIgnoreCase("0") ){
				SLF4JLoggerProxy.error(this, "Could not retry process deal order:" + orsObject.getOrderid() + ",p_err_code:" + p_err_code);
			}else{
				String p_out_result = callableStatement.getString(3);
				String p_out_ordertype = callableStatement.getString(5);
				SLF4JLoggerProxy.info(this, "123456, p_out_result:" + p_out_result + ", p_out_ordertype:" + p_out_ordertype);
				if(p_out_result != null && p_out_result.equalsIgnoreCase("Y") && 
						p_out_ordertype != null && p_out_ordertype.equals("OTO")){ //lenh mua OTO da khop het
					
					String quoteid = callableStatement.getString(4);
					if(quoteid != null){
						String symbol = callableStatement.getString(2);
						//Quote quote = HandlerCacheData.otoMap.get(orsObject.getSymbol()).get(quoteid);
						Quote quote = HandlerCacheData.otoMap.get(symbol).get(quoteid);
						if(quote != null){
							quote.setSide("S");
							quote.setTypecd("LO");
							quote.setSubtypecd("LO");
							quote.setPrice(quote.getOrderprice());
							quote.setStatus("P");//trang thai cho tin hieu khop lenh tu so ve de kich hoat
						}											
					}	
				}	
			}
			
			conn.commit();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {								
				if (callableStatement != null) {
					callableStatement.clearParameters();
					callableStatement.close();
					callableStatement = null;
				}
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
			
			SLF4JLoggerProxy.info(this, "process p_err_code:" +p_err_code);
		}
	}
	
	/**
	 * Thay cho cau lenh sau:
	 * SELECT COUNT(1) COUNT FROM ORDERS 
						WHERE ORDERID IN (SELECT ORDERID FROM ACTIVE_ORDERS WHERE QUOTEID = ?) 
							AND SUBSTATUS NOT IN ('FF','DD');
	 * @param quoteid
	 * @return
	 */
	private int getRemainQtty(String orderid){
		TimesTenPooledConnection conn = null;
		ResultSet rs = null;
		TimesTenPreparedStatement statement = null;
		int count = 1;
		try {
			conn = timestenManager.getConnection();
			statement = conn.getPreparedStmt(SQLStatement.KEY_TT_GET_ORDER_INFO);
			statement.setString(1, orderid);				
			rs = statement.executeQuery();
			
			if (rs.next()) {
				count = rs.getInt("REMAIN_QTTY");
			}
			conn.commit();
					
			return count;
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, "getOrderInfo error");
			SLF4JLoggerProxy.error(this, e);
			try {
				conn.rollback();
			} catch (SQLException e1) {
				SLF4JLoggerProxy.error(this, e1);
			}
			
			return -1;
		} finally {
			timestenManager.closeConnection(conn);			
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.clearParameters();
					statement.close();
					statement = null;
				}
			} catch (SQLException e) {
				SLF4JLoggerProxy.error(this, e);
			}
			
		}
	}
	
	private int getOrderInfo(String quoteid){
		TimesTenPooledConnection conn = null;
		ResultSet rs = null;
		TimesTenPreparedStatement statement = null;
		int count = 0; // total rows in table
		try {
			List<String> list = DAOCommon.getListActiveOrder(quoteid);
			
			if(list != null && list.size() > 0){
				conn = timestenManager.getConnection();
				for(int i=0; i< list.size();i++){
					String orderid = list.get(i);	
					statement = conn.getPreparedStmt(SQLStatement.KEY_TT_GET_ORDER_LIST);
					statement.setString(1, orderid);				
					rs = statement.executeQuery();
					
					if (rs.next()) {
						int temp = rs.getInt("COUNT");
						count = count + temp;
					}
					conn.commit();
				}
			}
					
			return count;
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, "getOrderInfo error");
			SLF4JLoggerProxy.error(this, e);
			try {
				conn.rollback();
			} catch (SQLException e1) {
				SLF4JLoggerProxy.error(this, e1);
			}
			
			return -1;
		} finally {
			timestenManager.closeConnection(conn);			
			try {
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.clearParameters();
					statement.close();
					statement = null;
				}
			} catch (SQLException e) {
				SLF4JLoggerProxy.error(this, e);
			}
			
		}
	}

}
