package com.noname.itrust.gate.aq;

import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import org.apache.activemq.command.ActiveMQObjectMessage;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.common.ConfigLoader;
import com.noname.itrust.gate.model.MarketInfo;
import com.noname.itrust.gate.model.StockInfo;
import com.noname.itrust.gate.model.TradeInfo;

@Component
public class MarketListenerTest /*implements MessageListener */{/*

	final static Logger logger = Logger.getLogger(MarketListenerTest.class);

	private Context context = null;
	private QueueConnectionFactory queueConnectionFactory = null;
	private QueueConnection queueConnection = null;
	private QueueSession queueSession = null;
	private Queue queue = null;;
	private MessageConsumer consumer = null;
	private String queueName = "";

	private boolean connectStatus = true;
	
	@Autowired
	private SignalProcessor signalProcessor;
	
	@Autowired
	private TSOService tSOService;

	public MarketListenerTest(String jmsProperties) {
		try {
			if (ConfigLoader.marketJMSProps == null) {
				ConfigLoader.loadProperties(jmsProperties,"MarketListenerTest");
			}
			
			connect();
		} catch (Exception e) {
			logger.error(e.getStackTrace());
		}
	}

	public MarketListenerTest() {
	}

	public static void init() {
		MarketListenerTest instance = new MarketListenerTest();
		instance.connect();
	}

	*//**
	 * 
	 * @throws JMSException
	 * @throws NamingException
	 *//*
	public void connect() {
		try {
			queueName = ConfigLoader.marketJMSProps.getProperty("queue.JMS_MESSAGE_ENGINE_MARKET");
			context = new InitialContext(ConfigLoader.marketJMSProps);
			queueConnectionFactory = (QueueConnectionFactory) context.lookup("QueueConnectionFactory");
			queueConnection = queueConnectionFactory.createQueueConnection("karaf", "karaf");
			queueSession = queueConnection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			queue = queueSession.createQueue(queueName);
			consumer = queueSession.createConsumer(queue);
			consumer.setMessageListener(this);
			queueConnection.start();
		} catch (Exception e) {
			connectStatus = false;
			e.printStackTrace();
			System.exit(1);
		}
	}

	public boolean connectStatus() {
		try {
			if ((connectStatus) && (queueConnection.getExceptionListener() != null))
				connectStatus = false;
		} catch (JMSException e) {
			connectStatus = false;
		}
		return connectStatus;
	}

	public void disconnect() {
		try {
			if (queueConnection != null) {
				queueConnection.stop();
				queueSession.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			queueConnection = null;
			queueSession = null;
		}
	}

	@Override
	public void onMessage(Message message) {
		if (message instanceof ActiveMQObjectMessage) {
			ActiveMQObjectMessage objMsg = (ActiveMQObjectMessage) message;
			try {
				Object obj = objMsg.getObject();
				if (obj instanceof MarketInfo) {
					MarketInfo marketinfo = (MarketInfo) obj;
					
					//lay tap lenh lien quan den lenh MCO 
					synchronized (HandlerCacheData.mcoMap) {
						signalProcessor.execute(HandlerCacheData.mcoMap,marketinfo); 
					}
				}else if (obj instanceof StockInfo) {
					StockInfo stockinfo = (StockInfo) obj;
					
					String symbol = stockinfo.getSymbol();
					//lay tap lenh lien quan den lenh SEO
					synchronized (HandlerCacheData.seoMap) {
						Map<String,Quote> seoOrders = HandlerCacheData.seoMap.get(symbol);
						if(null != seoOrders){
						  signalProcessor.execute(seoOrders,stockinfo);
						}
					}
					
					//lay tap lenh lien quan den lenh MCO 
					synchronized (HandlerCacheData.mcoMap) {
						signalProcessor.execute(HandlerCacheData.mcoMap,stockinfo); 
					}
				}else if (obj instanceof TradeInfo) {
					TradeInfo tradeinfo = (TradeInfo) obj;
					
					SLF4JLoggerProxy.info(this, "TradeInfo: symbol:" + tradeinfo.getSymbol() + ",formattedmatchprice:" + tradeinfo.getFormattedmatchprice());
					
					String symbol = tradeinfo.getSymbol();
					
					 //lay tap lenh lien quan den lenh TSO
					 synchronized (HandlerCacheData.tsoMap) {
						 Map<String,Quote> tsoOrders = HandlerCacheData.tsoMap.get(symbol);
						  if(null != tsoOrders){
							  tSOService.execute(tsoOrders,tradeinfo,"TransLog");
						  } 
					 }
					 
					  
					  //lay tap lenh lien quan den lenh STO
					  synchronized ( HandlerCacheData.stoMap) {
						 // SLF4JLoggerProxy.info(this,"=================stoMap1:" + HandlerCacheData.stoMap.size() );
						  Map<String,Quote> stoOrders = HandlerCacheData.stoMap.get(symbol);
						  //SLF4JLoggerProxy.info(this,"=================stoMap2:" + stoOrders.size() );
						  if(null != stoOrders){
							  signalProcessor.execute(stoOrders,tradeinfo);
						  }
					  }
					  
					  
					  //lay tap lenh lien quan den lenh SEO
					  synchronized (HandlerCacheData.seoMap) {
						  Map<String,Quote> seoOrders = HandlerCacheData.seoMap.get(symbol);
						  if(null != seoOrders){
							  signalProcessor.execute(seoOrders,tradeinfo);
						  }
					  }
					  
					  
					  //lay tap lenh lien quan den lenh OTO
					  synchronized (HandlerCacheData.otoMap) {
						  Map<String,Quote> otOrders = HandlerCacheData.otoMap.get(symbol);
						  if(null != otOrders){
							  signalProcessor.execute(otOrders,tradeinfo);
						  } 
					  }
					 
					  
					//lay tap lenh lien quan den lenh MCO
					  synchronized (HandlerCacheData.mcoMap) {
						  signalProcessor.execute(HandlerCacheData.mcoMap,tradeinfo); 
					  }
					
				}
			
			} catch (Exception e) {
				SLF4JLoggerProxy.error(this, e);
			}
		}
	}
*/}
