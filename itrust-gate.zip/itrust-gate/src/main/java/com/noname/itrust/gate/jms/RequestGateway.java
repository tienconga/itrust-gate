package com.noname.itrust.gate.jms;

import java.util.UUID;

import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.SessionCallback;
import org.springframework.jms.support.JmsUtils;
import org.springframework.jms.support.destination.DestinationResolver;
import org.springframework.stereotype.Component;

import com.fss.newfo.common.constant.ErrorCode;
import com.fss.newfo.common.constant.Fields;
import com.fss.newfo.common.utility.StringUtils;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;

@Component
public class RequestGateway {

	private static final class ProducerConsumer implements SessionCallback<Message> {

		private final String msg;

		private final DestinationResolver destinationResolver;

		private final String queue;

		private final Integer timeout;

		public ProducerConsumer(final String msg, String queue, Integer timeout, final DestinationResolver destinationResolver) {
			this.msg = msg;
			this.queue = queue;
			this.timeout = timeout;
			this.destinationResolver = destinationResolver;
		}

		@Override
		public Message doInJms(final Session session) {
			MessageConsumer consumer = null;
			MessageProducer producer = null;
			String correlationId = "";
			try {

				correlationId = UUID.randomUUID().toString();
				// correlationId = RandomStringUtils.randomAlphanumeric(100);

				final Destination requestQueue = destinationResolver.resolveDestinationName(session, queue + "-request", false);
				final Destination replyQueue = destinationResolver.resolveDestinationName(session, queue + "-response?consumer.prefetchSize=100000", false);

				// Create the consumer first!
				consumer = session.createConsumer(replyQueue, "JMSCorrelationID = '" + correlationId + "'");
				// writeLog("createConsumer MSGCorrelationID ", correlationId, startTime, endTime);

				// Create text message from session
				final TextMessage textMessage = session.createTextMessage(msg);

				// Set Correlation ID for text message
				textMessage.setJMSCorrelationID(correlationId);
				// textMessage.setJMSReplyTo( replyQueue );

				// Send the request second!
				producer = session.createProducer(requestQueue);
				// writeLog("createProducer MSGCorrelationID ", correlationId, startTime, endTime);

				// The effect of this difference is that persistent messaging is usually slower than non-persistent delivery
				// But when use non-persistent the messages will survive a broker restart and persistent is not.
				producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
				// producer.setDeliveryMode(DeliveryMode.PERSISTENT);

				// The messages sending only live in 5's
				// producer.setTimeToLive(TIMEOUT);

				// Send message to queue
				producer.send(requestQueue, textMessage);
				// writeLog("send MSGCorrelationID ", correlationId, startTime, endTime);

				// Block on receiving the response with a timeout
				Message msgReplied = consumer.receive(timeout);
				// writeLog("Received MSGCorrelationID ", correlationId, startTime, endTime);

				return msgReplied;
			} catch (JMSException e) {
				/** 26/03/2016 Nam.Vu sua log */
				SLF4JLoggerProxy.error(this, "ERROR Activemq", msg, e);
				return null;
			} finally {
				try {
					// Don't forget to close your resources
					JmsUtils.closeMessageConsumer(consumer);
					JmsUtils.closeMessageProducer(producer);
					// writeLog("Closed MSGCorrelationID ", correlationId, startTime, endTime);
				} catch (Exception e) {
					SLF4JLoggerProxy.error(this, e);
				}
			}
		}
	}

	/**
	 * Just to do write log
	 * 
	 * @param msg
	 * @param correlationId
	 * @param startTime
	 * @param endTime
	 */
	static void writeLog(String msg, String correlationId, long startTime, long endTime) {
		if (SLF4JLoggerProxy.isDebugEnabled(RequestGateway.class)) {
			endTime = System.nanoTime();
			SLF4JLoggerProxy.debug(RequestGateway.class, msg + correlationId + " in " + ((endTime - startTime) / 1000000.0));
		}
	}

	private final JmsTemplate jmsTemplate;

	@Autowired
	public RequestGateway(final JmsTemplate jmsTemplate) {
		this.jmsTemplate = jmsTemplate;
	}

	public String request(final String msg, String queue, String timeout) throws JMSException {
		SLF4JLoggerProxy.debug(this, "Received: " + msg);
		Integer timeoutInt = Integer.parseInt(timeout);
		// Must pass true as the second param to start the connection
		TextMessage msgReplied = (TextMessage) jmsTemplate.execute(new ProducerConsumer(msg, queue, timeoutInt, jmsTemplate.getDestinationResolver()), true);

		String result = null;
		if (msgReplied != null) {
			result = msgReplied.getText();
		} else {
			SLF4JLoggerProxy.error(this, "ERROR INTERNAL ACTIVEMQ.");
		}
		//
		try {
			result = result.replaceAll("\"ERRORCODE\":\"-95555\"", "\"ERRORCODE\":\"0\"");
		} catch (Exception ex) {
			SLF4JLoggerProxy.error(this, ex);
			SLF4JLoggerProxy.error(this, "Can't find String ERRORCODE -95555. Ignore that");
		}
		SLF4JLoggerProxy.debug(this, "Replied: " + msgReplied);

		return StringUtils.isEmpty(result) ? String.format("{\"%s\":\"%s\"}", Fields.ERROR_CODE, ErrorCode.SERVER_TIMEOUT) : result;
	}
}