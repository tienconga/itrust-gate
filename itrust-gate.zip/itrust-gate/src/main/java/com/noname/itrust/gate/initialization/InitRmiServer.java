package com.noname.itrust.gate.initialization;

import java.net.InetAddress;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import org.springframework.stereotype.Service;

import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.common.rmi.ConditionQuoteImpl;
import com.noname.itrust.gate.initialization.InitData;

@Service
public class InitRmiServer {
	//private static final int PORT = 1098;
	//private static Registry registry;
	//private static final String nameURL = "rmi://192.168.1.30:1099/myabc";
	
	public void initRmiServer() throws Exception {		
		try {
			int port = new Integer(InitData.prop.getPort()).intValue();
			String nameRemote = InitData.prop.getNameRemote();
			SLF4JLoggerProxy.info(this, "RMI infomation, host: " + InetAddress.getLocalHost() + ", port:" + port);
			//SLF4JLoggerProxy.info(this, "RMI infomation, host: " + InetAddress.getLocalHost() + ", port:" + PORT);
			
            // create on port 1098
            //Registry registry = LocateRegistry.createRegistry(PORT);
			Registry registry = LocateRegistry.createRegistry(port);
            
            // create a new service named myMessage
			//registry.rebind("myEngine", new ConditionQuoteImpl());
			registry.rebind(nameRemote, new ConditionQuoteImpl());
        } catch (Exception e) {
            e.printStackTrace();
        }      
	}
}
