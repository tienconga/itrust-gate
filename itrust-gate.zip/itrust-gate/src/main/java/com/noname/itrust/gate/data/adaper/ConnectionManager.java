package com.noname.itrust.gate.data.adaper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Component;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.fss.newfo.properties.Properties;

import oracle.jdbc.pool.OracleDataSource;

@Component
public class ConnectionManager {
		
	public static HashMap<String, String> sqlMap = new HashMap<String, String>();

	private static OracleDataSource datasource;
	
	public void create(){
		//System.out.print(connDB);
	}
	
	public Connection getConnection(){
		Connection conn = null;
		try {
			//SLF4JLoggerProxy.info(this, "Get connection: ");
			 conn = datasource.getConnection();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, "Get connection error: " + e.getMessage());
		}
		
		return conn;
	}
	
	public void closeConnection(Connection conn){
		try {
			conn.close();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, "Close connection error: " + e.getMessage());
		}
	}
	
	public OracleDataSource getDatasource() {
		return datasource;
	}

	public void setDatasource(OracleDataSource datasource) {
		this.datasource = datasource;
	}

	/**
	 * 
	 * @param args arg[0]: label arg[1]: sql
	 * @throws SQLException
	 */
	public void setCallableStatements(Map<String, String> map) throws SQLException {
		for (String label : map.keySet()) {
			registerCallableStatement(label, map.get(label));
		}
	}

	public void registerCallableStatement(String label, String sql) throws SQLException {
		sqlMap.put(label, sql);
	}

	/**
	 * 
	 * @param args arg[0]: label arg[1]: sql
	 * @throws SQLException
	 */
	public void setPreparedStatements(Map<String, String> map) throws SQLException {
		for (String label : map.keySet()) {
			registerPreparedStatement(label, map.get(label));
		}
	}

	public void registerPreparedStatement(String label, String sql) throws SQLException {
		sqlMap.put(label, sql);
	}
	
	
	public Connection getBackupConnection(Properties properties){
		Connection conn = null;
		java.util.Properties props = new java.util.Properties();
		//String sDBUser = "HOSTMSBS3";
		//String sDBPwd = "HOST";
        //String sDBConn = "jdbc:oracle:thin:@192.168.1.233:1521:FLEX";
        //String sDBConn = "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=192.168.1.233)(PORT=1521))(CONNECT_DATA=(SID=FLEX)))";
		String sDBUser = properties.getFlexuid();
		String sDBPwd = properties.getFlexpass();
		String sDBConn = properties.getFlexurl();
        
        props.setProperty("user", sDBUser);
        props.setProperty("password", sDBPwd);     
        //creating connection to Oracle database using JDBC 
        try {
			DriverManager.registerDriver (new oracle.jdbc.OracleDriver());
			conn = DriverManager.getConnection(sDBConn, props); //sDBConn, sDBConn	"jdbc:oracle:thin:@localhost:1521:fss"
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, "COULD NOT CONNECT 2 FLEX ORACLE DB");
			SLF4JLoggerProxy.error(this, e.getMessage());
		}
         		
		return conn;
	}
	
}
