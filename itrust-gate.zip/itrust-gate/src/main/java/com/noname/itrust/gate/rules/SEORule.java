package com.noname.itrust.gate.rules;

import java.math.BigDecimal;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.common.CommonConstants;
import com.noname.itrust.gate.data.dao.DAOCommon;
import com.noname.itrust.gate.model.ISignal;
import com.noname.itrust.gate.model.StockInfo;
import com.noname.itrust.gate.model.TradeInfo;
import com.noname.itrust.gate.thread.TicketQueue;

public class SEORule implements IRules {

	private LinkedBlockingQueue<Quote> queue;
	
	@Override
	public void process(ISignal market, Quote quote) {
		String pricetype = quote.getPricetype();
		String side = quote.getSide();
		BigDecimal orderprice = quote.getOrderprice();//gia kich hoat
		
		if((market instanceof TradeInfo) && pricetype != null && pricetype.equalsIgnoreCase("D")){ //voi tin hieu khop lenh
			TradeInfo tradinfo = (TradeInfo) market;
			BigDecimal marketPrice = tradinfo.getFormattedmatchprice();
			SLF4JLoggerProxy.info(this, "TradeInfo:" + pricetype);
			if(side.equalsIgnoreCase("B")){//mua
				if(marketPrice.compareTo(orderprice) == 1 || marketPrice.compareTo(orderprice) == 0){
					//kich hoat lenh
					activeOrder(quote,orderprice);
				}
			}else if(side.equalsIgnoreCase("S")){//Ban
				if(marketPrice.compareTo(orderprice) == -1 || marketPrice.compareTo(orderprice) == 0){
					//kich hoat lenh
					activeOrder(quote,orderprice);
				}
			}
		}else if((market instanceof StockInfo) && pricetype != null && !pricetype.equalsIgnoreCase("D")){ //voi tin hieu thong tin chung khoan
			StockInfo stockinfo = (StockInfo) market;
			BigDecimal marketPrice = null;
			SLF4JLoggerProxy.info(this, "StockInfo:" + pricetype);
			
			if(pricetype.equalsIgnoreCase("B")){//gia chao mua tot nhat
				marketPrice = stockinfo.getBidprice1();
			}else if(pricetype.equalsIgnoreCase("S")){//gia chao ban tot nhat
				marketPrice = stockinfo.getOfferprice1();
			}else if(pricetype.equalsIgnoreCase("C")){//gia tran
				marketPrice = stockinfo.getCeiling();
			}else if(pricetype.equalsIgnoreCase("F")){//gia san
				marketPrice = stockinfo.getFloor();
			}
			
			if(marketPrice != null){
				if(side.equalsIgnoreCase("B")){//mua
					if(marketPrice.compareTo(orderprice) == 1 || marketPrice.compareTo(orderprice) == 0){
						//kich hoat lenh
						activeOrder(quote,orderprice);
					}
				}else if(side.equalsIgnoreCase("S")){//Ban
					if(marketPrice.compareTo(orderprice) == -1 || marketPrice.compareTo(orderprice) == 0){
						//kich hoat lenh
						activeOrder(quote,orderprice);
					}
				}
			}
			
		}else {
			SLF4JLoggerProxy.info(this, "Not mapping SEO order with signal.");
		}
	}

	
	private void activeOrder(Quote quote, BigDecimal marketPrice){
		//kich hoat lenh
		SLF4JLoggerProxy.info(this,"Active SEO Order========quoteid:" + quote.getQuoteid() + ",latestPrice:" + marketPrice);
		try {
			quote.setPrice(marketPrice);
			TicketQueue queThread = TicketQueue.getTicketQueueThread();
			queue = queThread.getTicketqueue();
			queue.put(quote);
		} catch (InterruptedException e) {
			SLF4JLoggerProxy.error(this, "Error when active SEO Order========quoteid:" + quote.getQuoteid() + "," + e);
		}
		
		//xoa khoi orders list
		synchronized(HandlerCacheData.seoMap){
			HandlerCacheData.seoMap.get(quote.getSymbol()).remove(quote.getQuoteid());
		}
		
		//syn to DB
		DAOCommon obj = new DAOCommon();
		obj.updateStatus(quote.getQuoteid(), CommonConstants.ORDER_STATUS_ACTIVING,"SEO");
		
	}
	
	@Override
	public void putRequest(Quote quote) {
		// TODO Auto-generated method stub

	}

	@Override
	public void load() {
		// TODO Auto-generated method stub

	}

}
