package com.noname.itrust.gate.data.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.sql.SQLStatement;


public class MCODBPersistent {
	
	public void insertMCO(Quote quote, String status) {
		
		/*Connection conn = null;
		CallableStatement callableStatement = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        String log = "";
        String p_err_code = "After execute:";
        try {
        	conn = mgr.getConnection();
			callableStatement = conn.prepareCall(ConnectionManager.sqlMap.get(SQLStatement.KEY_INSERT_MCO));
			callableStatement.registerOutParameter(1, Types.VARCHAR);// p_err_code
			callableStatement.setString(2, quote.getQuoteid()); // p_quoteid
			callableStatement.setString(3, quote.getAcctno());// p_acctno
			callableStatement.setString(4, quote.getSymbol());// p_symbol
			callableStatement.setLong(5, quote.getQtty());// p_qtty
			callableStatement.setBigDecimal(6, quote.getPrice());// p_price
			callableStatement.setString(7, quote.getSide());// p_side
			callableStatement.setString(8, quote.getCondition1());// p_condition1
			callableStatement.setString(9, quote.getOperation1());// p_operation1
			callableStatement.setInt(10, quote.getValue1());// p_value1
			callableStatement.setString(11, quote.getCondition2());// p_condition2
			callableStatement.setString(12, quote.getOperation2());// p_operation2
			callableStatement.setInt(13, quote.getValue2());// p_value2
			callableStatement.setString(14, quote.getCondition3());// p_condition3
			callableStatement.setString(15, quote.getOperation3());// p_operation3
			callableStatement.setInt(16, quote.getValue3());// p_value3
			callableStatement.setString(17, quote.getCondition4());// p_condition4
			callableStatement.setString(18, quote.getOperation4());// p_operation4
			callableStatement.setInt(19, quote.getValue4());// p_value4
			
			callableStatement.setDate(20, new java.sql.Date(quote.getCreateddt().getTime()));// p_fromdate
			callableStatement.setDate(21, new java.sql.Date(quote.getExpireddt().getTime()));// p_todate
			callableStatement.setString(22, status);// p_status
			callableStatement.setString(23,quote.getBroker()); // p_broker

			log = "store parametter -|  CSPKS_HFT_SAVE_NEW.sp_create_mco_orders |  p_quoteid: " + quote.getQuoteid()
			+ "|  p_acctno: " + quote.getAcctno() + "|  p_symbol1: " + quote.getSymbol() + "|  p_qtty: " + quote.getQtty()
			+ "|  p_price: " + quote.getPrice() + " |  p_side: " + quote.getSide() 
			+ "|  p_condition1: " + quote.getCondition1() + "|  p_operation1: " + quote.getOperation1() + "|  p_value1: " + quote.getValue1()
			+ "|  p_condition2: " + quote.getCondition2() + "|  p_operation2: " + quote.getOperation2() + "|  p_value2: " + quote.getValue2()
			+ "|  p_condition3: " + quote.getCondition3() + "|  p_operation3: " + quote.getOperation3() + "|  p_value3: " + quote.getValue3()
			+ "|  p_condition4: " + quote.getCondition4() + "|  p_operation4: " + quote.getOperation4() + "|  p_value4: " + quote.getValue4()
			+ "|  p_fromdate: " + quote.getCreateddt() + "|  p_todate: " + quote.getExpireddt() + "|  p_status: " + status
			+ "|  p_broker: " + quote.getBroker();
			
			SLF4JLoggerProxy.info(this, log);
			callableStatement.execute();
			p_err_code = callableStatement.getString(1);
			conn.commit();
			
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if (callableStatement != null) {
					callableStatement.clearParameters();
					callableStatement.close();
					callableStatement = null;
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
			
			SLF4JLoggerProxy.info(this, p_err_code);
		}*/
	}
	
	

}
