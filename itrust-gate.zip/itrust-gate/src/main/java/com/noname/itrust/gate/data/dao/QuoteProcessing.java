package com.noname.itrust.gate.data.dao;

import java.sql.SQLException;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.sql.SQLStatement;
import com.noname.itrust.gate.data.adaper.TimesTenPooledConnection;
import com.noname.itrust.gate.data.adaper.TimestenManager;
import com.timesten.jdbc.TimesTenPreparedStatement;

public class QuoteProcessing {

	public void updateQuoteStatus(Quote quote, String status) {
		//update Quote
		TimesTenPooledConnection conn = null;
		TimestenManager ttMgr = new TimestenManager();
		try {
			conn = ttMgr.getConnection();
			TimesTenPreparedStatement statement = null;
			statement = conn.getPreparedStmt(SQLStatement.Order.KEY_SQL_UPDATE_QUOTE_STATUS);

			statement.setString(1, status);
			statement.setString(2, status);
			statement.setString(3, quote.getQuoteid());

			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			ttMgr.closeConnection(conn);
		}

	}

}
