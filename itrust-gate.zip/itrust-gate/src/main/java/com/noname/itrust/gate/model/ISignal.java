package com.noname.itrust.gate.model;

public interface ISignal {

}
