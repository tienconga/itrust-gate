package com.noname.itrust.gate;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class TestPerformance {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//long start1 = System.currentTimeMillis();
		long start1 = System.nanoTime();

		//long end1 = System.currentTimeMillis();
		long end1 = System.nanoTime();
		NumberFormat formatter = new DecimalFormat("#0.00000");
		System.out.println("put:" + (end1 - start1));

		//long start2 = System.currentTimeMillis();
		long start2 = System.nanoTime();

		//long end2 = System.currentTimeMillis();
		long end2 = System.nanoTime();
		System.out.println("Show:" + (end2 - start2));
		//System.out.println("Execution time is " + formatter.format((end2 - start2) / 1000d) + " seconds");

	}

}
