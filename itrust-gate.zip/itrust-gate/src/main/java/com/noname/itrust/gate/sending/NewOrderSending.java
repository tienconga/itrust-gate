package com.noname.itrust.gate.sending;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.github.fge.jackson.JsonLoader;
import com.noname.itrust.gate.caching.CacheProcessing;
import com.noname.itrust.gate.data.dao.DAOCommon;
import com.noname.itrust.gate.initialization.InitData;
import com.noname.itrust.gate.rules.ICORule;
import com.noname.itrust.gate.thread.TicketQueue;

@Service
public class NewOrderSending {

	final static Logger logger = Logger.getLogger(TicketQueue.class);
	
	public static Map<String, String> activeOrderMap = new HashMap<String, String>();
	
	public void placeOrder(Quote quote) {		
		Long qttySum = quote.getQtty();
		
		String board = CacheProcessing.InstrumentMap.get(quote.getSymbol()).getBoard();
		Long lot_qtty = CacheProcessing.maxQttyMap.get(board);
		SLF4JLoggerProxy.debug(this, "Lot qtty:" + lot_qtty + ", quoteid:" + quote.getQuoteid());
		
		if(qttySum <= lot_qtty){
			sendOrder(quote);
		}else{
			while(qttySum > lot_qtty){
				Long sendQtty = (long) lot_qtty;
				Long remainQtty = qttySum - lot_qtty;
				qttySum = qttySum - lot_qtty;
				quote.setQtty(sendQtty);
				sendOrder(quote);
				
				if(remainQtty <= lot_qtty){
					quote.setQtty(remainQtty);
					sendOrder(quote);
				}
			}
		}
	}
	
	public void sendOrder(Quote quote) {/*
		String result = "";
		
		try {
			//FrontGateServiceService service = new FrontGateServiceService();
			URL url = new URL(InitData.prop.getWsdlLocation());
			FrontGateServiceService service = new FrontGateServiceService(url);
			IFrontGateService obj = service.getFrontGateServicePort();
			
			String requestid = DAOCommon.getSequence();
			if(requestid == null){
				long time = System.currentTimeMillis();
				requestid = String.valueOf(time);
				requestid = quote.getClasscd() + requestid;
			}
			
			String str = buildPlaceOrderString(quote, requestid);
			result = obj.sendMessage(str);
			
			SLF4JLoggerProxy.info(this, "Send message to ORS: " + str + "; RESPONE FROM ORS:" + result);
		
			//process result
			ObjectNode node;
			
			node = (ObjectNode) JsonLoader.fromString(result);

			JsonNode errorNode = node.get("ERRORCODE");
			JsonNode subquoteid = node.get("QUOTEID");
			JsonNode orderid = node.get("ORDERID");
			String subquoteidStr = "";
			String orderidStr = "";
			String errorCode = "";
			if (errorNode != null) {
				errorCode = errorNode.toString();
				errorCode = errorCode.replaceAll("\"", "");
													
				if(subquoteid != null){
					subquoteidStr = subquoteid.toString();
					subquoteidStr = subquoteidStr.replaceAll("\"", "");
				}
				
				if(orderid != null){
					orderidStr = orderid.toString();
					orderidStr = orderidStr.replaceAll("\"", "");
					
					if(errorCode.equalsIgnoreCase("0")){
						activeOrderMap.put(orderidStr, quote.getClasscd());
					}
					
				}
				
				if(classcd != null){					
					DAOCommon persistentObj = new DAOCommon();
					persistentObj.updateResult(classcd, quote.getQuoteid(), errorCode, subquoteidStr,orderidStr);
				}
				
				//Process for ICO order
				String classcd = quote.getClasscd();
				if(classcd != null && classcd.equalsIgnoreCase("ICO") && errorCode.equalsIgnoreCase("0")){
					ICORule rule = new ICORule();
					rule.cancelOrder(quote, errorCode, orderidStr);
				}
				
				
			} else {
				SLF4JLoggerProxy.error(this, "Error connect webservice");
			}
			 
			DAOCommon persistentObj = new DAOCommon();
			persistentObj.saveExecuteOrder(quote, requestid, subquoteidStr,errorCode, orderidStr,"N");
			
			if(!errorCode.equalsIgnoreCase("0")){
				SLF4JLoggerProxy.info(this, "=================111quoteid:" + quote.getQuoteid() + ",errorCode:" + errorCode);
				persistentObj.updateResponeStatus(quote.getQuoteid(), "E",quote.getClasscd());
			}else{
				SLF4JLoggerProxy.info(this, "=================222quoteid:" + quote.getQuoteid() + ",errorCode:" + errorCode);
				persistentObj.updateStatus(quote.getQuoteid(), "F",quote.getClasscd());
			}
			

		} catch (IOException e) {
			SLF4JLoggerProxy.error(this, "Error connect webservice, " +e);
		}
	*/}
	
	private String buildPlaceOrderString(Quote quote,String requestid ){
		String str = "{\"msgtype\":\"MSGTYPE_VALUE\",\"requestid\":\"REQUESTID_VALUE\",\"userid\":\"USERID_VALUE\",\"classcd\":\"CLASSCD_VALUE.DL\",\"via\":\"E\",\"typecd\":\"TYPECD_VALUE\",\"subtypecd\":\"SUBTYPECDAAA_VALUE\"," +
				"\"symbol\":\"SYMBOL_VALUE\",\"qtty\":QTTY_VALUE,\"acctno\":\"ACCTNO_VALUE\",\"price\":PRICE_VALUE}";

		if(quote.getSide() != null && quote.getSide().equals("B") ){
			str = str.replaceAll("MSGTYPE_VALUE", "tx0001");
		}else{
			str = str.replaceAll("MSGTYPE_VALUE", "tx0000");
		}
		
		//STO
		if(quote.getClasscd() != null && quote.getClasscd().equalsIgnoreCase("STO")){
			str = str.replaceAll("MSGTYPE_VALUE", "tx0000");
		}
		
		//PCO
		if(quote.getClasscd() != null && (quote.getClasscd().equalsIgnoreCase("PCO") || quote.getClasscd().equalsIgnoreCase("OTO"))){
			str = str.replaceAll("TYPECD_VALUE", quote.getTypecd());
			str = str.replaceAll("SUBTYPECDAAA_VALUE", quote.getSubtypecd());	
		}else{
			str = str.replaceAll("TYPECD_VALUE", "LO");
			str = str.replaceAll("SUBTYPECDAAA_VALUE", "LO");
		}
		
		str = str.replaceAll("REQUESTID_VALUE", requestid);
		
		if(quote.getUserid() != null){
			str = str.replaceAll("USERID_VALUE", quote.getUserid());
			//str = str.replaceAll("USERID_VALUE", quote.getClasscd());
		}else{
			str = str.replaceAll("USERID_VALUE", quote.getClasscd());
		}
		
		if(quote.getSymbol() != null){
			str = str.replaceAll("SYMBOL_VALUE", quote.getSymbol());
		}
		
		if(quote.getQtty() != null){
			str = str.replaceAll("QTTY_VALUE", quote.getQtty().toString());
		}
		
		if(quote.getAcctno() != null){
			str = str.replaceAll("ACCTNO_VALUE", quote.getAcctno());
		}
		
		if(quote.getPrice() != null){
			str = str.replaceAll("PRICE_VALUE", quote.getPrice().toString());
		}else{
			str = str.replaceAll("PRICE_VALUE","0");
		}
		
		if(quote.getClasscd() != null){
			str = str.replaceAll("CLASSCD_VALUE", quote.getClasscd().toString());
		}
		
		return str;
	}
}
