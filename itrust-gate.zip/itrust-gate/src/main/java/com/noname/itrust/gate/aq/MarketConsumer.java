package com.noname.itrust.gate.aq;

import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fss.fo.mserver.exchange.MarketInforProtos.MarketInfor;
import com.fss.fo.mserver.exchange.SerializeUtils;
import com.fss.fo.mserver.exchange.StockInforProtos.StockInfor;
import com.fss.fo.mserver.exchange.TransLogProtos.TransLog;
import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.file.GeneralCSV;
import com.noname.itrust.gate.filter.MarketFilter;
import com.noname.itrust.gate.model.MarketInfo;
import com.noname.itrust.gate.model.StockInfo;
import com.noname.itrust.gate.model.TradeInfo;


@Component
public class MarketConsumer implements Processor {
	
	@Autowired
	private GeneralCSV generalCSV;
	
	//@Autowired
	//private SignalProcessor signalProcessor;
	
	//@Autowired
	//private TSOService tSOService;
	
	@Override
	public void process(Exchange exchange) {
		//SLF4JLoggerProxy.info(this, " Received message from adapter: " + exchange.getIn().getBody());
		String msg = exchange.getIn().getBody(String.class);
		try {
			Object exchangeData = SerializeUtils.Deserialize(msg);
			if (exchangeData instanceof MarketInfor) {
			  MarketInfor mkt = (MarketInfor) exchangeData;
			  
			  generalCSV.writeMarketInfor(mkt,"BEFORE");  
			  
			  //convert message
			  MarketInfo marketinfo = new MarketInfo();
			  marketinfo = marketinfo.copyFromMarketInfor(mkt);
			  //JMSSender sender = JMSSenderTest.senderMap.get("MarketInfor");
			  
			  //lay tap lenh lien quan den lenh MCO
			 /* String value = MCORequestHandler.mco_register_marketInfo.get("INDEX");
			  if(HandlerCacheData.mcoMap.size() > 0 && value != null){
				  signalProcessor.execute(HandlerCacheData.mcoMap,marketinfo);  
			  }*/
			  
			} else if (exchangeData instanceof StockInfor) {
			  StockInfor stock = (StockInfor) exchangeData;
			  
			  generalCSV.writeStockInfor(stock,"BEFORE");
			  
			  MarketFilter filter = new MarketFilter();
			  stock = filter.filter(stock);
			  if(null != stock){				  
				  //convert
				  StockInfo stockinfo = new StockInfo();
				  stockinfo = stockinfo.copyFromStockInfor(stock);
				  
				  generalCSV.writeStockInfor(stock,"AFTER");
				  
				  String symbol = stockinfo.getSymbol();
				  //lay tap lenh lien quan den lenh SEO
				  Map<String,Quote> seoOrders = HandlerCacheData.seoMap.get(symbol);
				  if(null != seoOrders){
					  //signalProcessor.execute(seoOrders,stockinfo);
				  }
				  
				  //lay tap lenh lien quan den lenh MCO
				  /*String value = MCORequestHandler.mco_register_stockInfo.get(symbol);
				  if(HandlerCacheData.mcoMap.size() > 0 && value != null){
					  signalProcessor.execute(HandlerCacheData.mcoMap,stockinfo);  
				  }*/
				  			  
			  }
		    }else if (exchangeData instanceof TransLog) {
		      TransLog trans = (TransLog) exchangeData;
		    		    
		      generalCSV.writeTransLog(trans,"BEFORE");
			  
			  MarketFilter filter = new MarketFilter();
			  trans = filter.filter(trans);
			  if(null != trans){
				  //convert
				  TradeInfo tradeinfo = new TradeInfo();
				  tradeinfo = tradeinfo.copyFromTransLog(trans);
				  //JMSSender sender = JMSSenderTest.senderMap.get("TransLog");
				  //sender.sendObject(trans);
				  //sender.sendObject(tradeinfo);
				  
				  generalCSV.writeTransLog(trans,"AFTER");
				  String symbol = tradeinfo.getSymbol();
				  
				  List<Object> list = HandlerCacheData.translog_symbol.get(symbol);
				 /* for(int i=0;i<list.size() ; i++){
					  Object object = list.get(i);
					  signalProcessor.execute(object,tradeinfo,"TransLog");
				  }
				  */
				  
				  //lay tap lenh lien quan den lenh TSO
				  Map<String,Quote> tsoOrders = HandlerCacheData.tsoMap.get(symbol);
				  if(null != tsoOrders){
					  //tSOService.execute(tsoOrders,tradeinfo,"TransLog");
				  }
				  
				  //lay tap lenh lien quan den lenh STO
				  Map<String,Quote> stoOrders = HandlerCacheData.stoMap.get(symbol);
				  if(null != stoOrders){
					 // signalProcessor.execute(stoOrders,tradeinfo);
				  }
				  
				  //lay tap lenh lien quan den lenh SEO
				  Map<String,Quote> seoOrders = HandlerCacheData.seoMap.get(symbol);
				  if(null != seoOrders){
					  //signalProcessor.execute(seoOrders,tradeinfo);
				  } 
				  
				  //lay tap lenh lien quan den lenh MCO
				 /* String value = MCORequestHandler.mco_register_tradeInfo.get(symbol);
				  if(HandlerCacheData.mcoMap.size() > 0 && value != null){
					  signalProcessor.execute(HandlerCacheData.mcoMap,tradeinfo);  
				  }*/
				  
				  
			  }
			  
		    }/* else if (exchangeData instanceof PutThroughInfo) {
		      PutThroughInfo trans = (PutThroughInfo) exchangeData;
		      key = trans.getSymbol() + String.valueOf(trans.getOrderId());
		      // putthrough.put(key, msgData);
		      isBroadCast = false;
		    } else if (exchangeData instanceof PTMatch) {
		      PTMatch trans = (PTMatch) exchangeData;
		      key = trans.getSymbol() + String.valueOf(trans.getConfirmNo());
		      // ptmatch.put(key, msgData);
		      isBroadCast = false;
		  }*/
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}
	}
}
