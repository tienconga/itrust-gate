package com.noname.itrust.gate.model;

import java.math.BigDecimal;

public class TickSize {
	
	private Long tickSize;
	private BigDecimal fromPrice;
	private BigDecimal toPrice;
	
	public Long getTickSize() {
		return tickSize;
	}
	public void setTickSize(Long tickSize) {
		this.tickSize = tickSize;
	}
	public BigDecimal getFromPrice() {
		return fromPrice;
	}
	public void setFromPrice(BigDecimal fromPrice) {
		this.fromPrice = fromPrice;
	}
	public BigDecimal getToPrice() {
		return toPrice;
	}
	public void setToPrice(BigDecimal toPrice) {
		this.toPrice = toPrice;
	}

}
