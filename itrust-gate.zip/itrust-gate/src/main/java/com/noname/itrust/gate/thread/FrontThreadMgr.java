package com.noname.itrust.gate.thread;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.fss.newfo.common.model.Quote;
import com.noname.itrust.gate.model.ISignal;

public class FrontThreadMgr {

	final static Logger logger = Logger.getLogger(FrontThreadMgr.class);

	private static volatile FrontThreadMgr threadMgr;

	private ThreadPoolExecutor executor;

	public static final int DEFAULT_QUEUE_SIZE = 100000;

	public static void initThreadMgr(int size, long timeout, int queueSize) {
		threadMgr = new FrontThreadMgr(size, timeout, queueSize);
	}

	public static FrontThreadMgr getThreadMgr() {

		if (threadMgr == null) {
			threadMgr = new FrontThreadMgr(50, 1000, DEFAULT_QUEUE_SIZE);
		} else {
		}

		return threadMgr;
	}

	public FrontThreadMgr(int size, long timeout, int queueSize) {
		BlockingQueue<Runnable> queue = (BlockingQueue<Runnable>) new ArrayBlockingQueue<Runnable>(queueSize);
		this.executor = new ThreadPoolExecutor(size, size, timeout, TimeUnit.MILLISECONDS, queue);
	}

	public int fireEmptyThread(ISignal signal, String threadName,Quote quote) {

		try {
			FrontThreadBeforeWork bWork = new FrontThreadBeforeWork(signal, threadName, quote);
			this.executor.execute(bWork);
			return -1;
		} catch (RejectedExecutionException e) {
			//e.printStackTrace();
			logger.error("ERROR: " + e.getLocalizedMessage());
			//System.exit(0);
			return 0;
		}
	}

}
