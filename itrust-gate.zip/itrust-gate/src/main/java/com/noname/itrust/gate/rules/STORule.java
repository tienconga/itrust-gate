package com.noname.itrust.gate.rules;

import java.math.BigDecimal;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.CacheProcessing;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.common.CommonConstants;
import com.noname.itrust.gate.data.dao.DAOCommon;
import com.noname.itrust.gate.model.ISignal;
import com.noname.itrust.gate.model.TradeInfo;
import com.noname.itrust.gate.thread.TicketQueue;

public class STORule implements IRules {

	private LinkedBlockingQueue<Quote> queue;
	
	@Override
	public void process(ISignal market,Quote quote) {
		//check phien
		String exchange = CacheProcessing.InstrumentMap.get(quote.getSymbol()).getBoard();
		
		boolean isactive = true;
		//chi dat trong phien lien tuc
		if((exchange != null && exchange.equalsIgnoreCase("HNX")) && // 
						(HandlerCacheData.hnxSession.equalsIgnoreCase("END") || HandlerCacheData.hnxSession.equalsIgnoreCase("CROSS")  )){
			isactive = false;
		}else if((exchange != null && exchange.equalsIgnoreCase("HSX")) && //
				(HandlerCacheData.hsxSession.equalsIgnoreCase("END") || HandlerCacheData.hsxSession.equalsIgnoreCase("CROSS"))){
			isactive = false;
		}else if((exchange != null && exchange.equalsIgnoreCase("UPCOM")) && //				
				(HandlerCacheData.upcomSession.equalsIgnoreCase("CNT") || HandlerCacheData.upcomSession.equalsIgnoreCase("CNT"))){
			isactive = false;
		}
		
		if(!isactive){
			SLF4JLoggerProxy.info(this,"Could not active order, incorrect session ========quoteid:" + quote.getQuoteid() 
					+ ",HSX:" + HandlerCacheData.hsxSession + ",HNX:" + HandlerCacheData.hnxSession + ",UPCOM:" + HandlerCacheData.upcomSession);
			return;
		}
		
		TradeInfo marketObj = (TradeInfo) market;
		BigDecimal latestPrice = marketObj.getFormattedmatchprice();//gia khop tra ve tu market
		
		String removeQuoteid = null;
		
		//synchronized (HandlerCacheData.stoMap) {
			String quoteid = quote.getQuoteid();
			BigDecimal orderPrice = quote.getOrderprice();
			String side = quote.getSide();
			
			if(side != null && side.equalsIgnoreCase("P")){
				if(latestPrice.compareTo(orderPrice) == 1 || latestPrice.compareTo(orderPrice) == 0){
					//kich hoat lenh
					SLF4JLoggerProxy.info(this,"Active STO Order========quoteid:" + quoteid + ",latestPrice:" + latestPrice);
					try {
						TicketQueue queThread = TicketQueue.getTicketQueueThread();
						queue = queThread.getTicketqueue();
						queue.put(quote);
					} catch (InterruptedException e) {
						SLF4JLoggerProxy.error(this, "Error when active STO Order========quoteid:" + quoteid + "," + e);
					}
					
					removeQuoteid = quote.getQuoteid();
				}
			}else if (side != null && side.equalsIgnoreCase("L")){
				if(latestPrice.compareTo(orderPrice) == -1 || latestPrice.compareTo(orderPrice) == 0){
					//kich hoat lenh
					SLF4JLoggerProxy.info(this,"Active STO Order========quoteid:" + quoteid + ",latestPrice:" + latestPrice);
					try {
						TicketQueue queThread = TicketQueue.getTicketQueueThread();
						queue = queThread.getTicketqueue();
						queue.put(quote);
					} catch (InterruptedException e) {
						SLF4JLoggerProxy.error(this, "Error when active STO Order========quoteid:" + quoteid + "," + e);
					}
					
					removeQuoteid = quote.getQuoteid();
				}
			}
			
			//remove cache and update database:
			if(removeQuoteid != null){
				//syn to DB
				DAOCommon obj = new DAOCommon();
				obj.updateStatus(quote.getQuoteid(), CommonConstants.ORDER_STATUS_ACTIVING,"STO");
				
				//xoa khoi orders list
				synchronized ( HandlerCacheData.stoMap) {
					Map<String,Quote> tsoOrders = HandlerCacheData.stoMap.get(quote.getSymbol());
					tsoOrders.remove(removeQuoteid);
				}
			}
		//}synchronized
	}

	@Override
	public void putRequest(Quote quote) {
		// TODO Auto-generated method stub

	}

	@Override
	public void load() {
		// TODO Auto-generated method stub

	}

}
