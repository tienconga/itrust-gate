package com.noname.itrust.gate.dataservice;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fss.newfo.common.model.MobileInfo;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.data.adaper.TimesTenPooledConnection;
import com.noname.itrust.gate.data.adaper.TimestenManager;
import com.noname.itrust.gate.sql.SQLStatement;
import com.timesten.jdbc.TimesTenPreparedStatement;

@Service
public class GetDataService {

	@Autowired
	private TimestenManager timestenManager;
	
	public String proces(String phonenumber){
		return getData(phonenumber);
	}
	
	private String getData(String phonenumber){
		String rerult = "No data for [" + phonenumber + "]";
		TimesTenPooledConnection conn = null;
		ResultSet rs = null;
		TimesTenPreparedStatement statement = null;
		//String phone = "";
		String phone = phonenumber;
		try {	
			
			phone = phonenumber;
			if(phone != null && (phone.length() > 10)) {
				int length = phone.length();
				phone = phone.substring(length - 9);
				phone = "0" + phone;
			}
			
			conn = timestenManager.getConnection();
			statement = conn.getPreparedStmt(SQLStatement.KEY_TT_GET_ORDER_INFO);
			statement.setString(1, phone);				
			rs = statement.executeQuery();
			MobileInfo objJson = new MobileInfo();
			//System.out.println("================111111111111:" );
			if (rs.next()) {
				objJson.setCustomerName(rs.getString("CUSTOMER_NAME"));
				objJson.setPhoneNumber(rs.getString("PHONENUMBER"));
				objJson.setLegelid(rs.getString("LEGALID"));
				objJson.setSex(rs.getString("LEGALID"));
				objJson.setCity(rs.getString("CITY"));
				objJson.setAddress(rs.getString("ADDRESS"));
			
				//System.out.println("================22222222222222:" );
				//Message messageObj = objJson;
			
				//rerult = FOJsonSchemaCached.convertJsonObjectToString(messageObj);
				//{"CUSTOMERNAME":"tiendt","PHONENUMBER":"091574236","LEGELID":"145072539","ADDRESS":"Khoai Chau - Hung Yen","RESPONE":true}
				StringBuffer bf = new StringBuffer();
				bf.append("{\"");
				bf.append("CUSTOMERNAME");
				bf.append("\":\"");
				bf.append(rs.getString("CUSTOMER_NAME"));
				bf.append("\"");
				
				bf.append(",");
				
				bf.append("\"");
				bf.append("PHONENUMBER");
				bf.append("\":\"");
				bf.append(rs.getString("PHONENUMBER"));
				bf.append("\"");
				
				bf.append(",");
				
				bf.append("\"");
				bf.append("CITY");
				bf.append("\":\"");
				bf.append(rs.getString("CITY"));
				bf.append("\"");
				
				bf.append(",");
				
				bf.append("\"");
				bf.append("LEGELID");
				bf.append("\":\"");
				bf.append(rs.getString("LEGALID"));
				bf.append("\"");
				
				bf.append(",");
				
				bf.append("\"");
				bf.append("ADDRESS");
				bf.append("\":\"");
				bf.append("Khoai Chau - Hung Yen");
				bf.append("\"");
				
				
				bf.append("}");
				
				rerult = bf.toString();
				System.out.println("================:" + bf.toString());
			}
			
					
			return rerult;
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, "getOrderInfo error");
			SLF4JLoggerProxy.error(this, e);
			try {
				conn.rollback();
			} catch (SQLException e1) {
				SLF4JLoggerProxy.error(this, e1);
			}
			
			return "-1";
		} finally {		
			try {
				conn.commit();
				if (rs != null) {
					rs.close();
				}
				if (statement != null) {
					statement.clearParameters();
					statement.close();
					statement = null;
				}
			} catch (SQLException e) {
				SLF4JLoggerProxy.error(this, e);
			}
			
			timestenManager.closeConnection(conn);
			
		}
	}
}
