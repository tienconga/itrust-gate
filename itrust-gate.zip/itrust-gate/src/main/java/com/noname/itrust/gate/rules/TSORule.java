package com.noname.itrust.gate.rules;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import org.apache.log4j.Logger;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.CacheProcessing;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.common.CommonConstants;
import com.noname.itrust.gate.data.dao.TSODBPersistent;
import com.noname.itrust.gate.model.ISignal;
import com.noname.itrust.gate.model.TickSize;
import com.noname.itrust.gate.model.TradeInfo;
import com.noname.itrust.gate.thread.TicketQueue;

//Trailing Order
public class TSORule implements IRules {

	final static Logger logger = Logger.getLogger(TSORule.class);

	public static HashMap<String, HashMap<String, Quote>> trailOrders = new HashMap<String, HashMap<String, Quote>>(); //<symbol,<quoteid,Quote>>
	public static Map<String, BigDecimal> trailPriceMap = new HashMap<String, BigDecimal>();

	private LinkedBlockingQueue<Quote> queue;

	public void load() {
		
	}

	public void process(ISignal market,Quote quote) {
		TradeInfo marketObj = (TradeInfo) market;
		BigDecimal latestPrice = marketObj.getFormattedmatchprice();//P, gia moi nhat tu so
		String symbol = "";

		String removeQuoteid = null;
		BigDecimal orderPrice = null;
		//synchronized (HandlerCacheData.tsoMap) {
			String quoteid = quote.getQuoteid();
			String side = quote.getSide();
			symbol = quote.getSymbol();
			if (symbol.equalsIgnoreCase(marketObj.getSymbol())) {
				if (side != null && side.equals("B")) { //mua
					//tinh gia kich hoat
					BigDecimal beforPrice = trailPriceMap.get(quoteid);//f(x-1)
					if(beforPrice == null){//tinh f0 tai thoi diem ban dau
						beforPrice = CacheProcessing.InstrumentMap.get(symbol).getPriceRF();
						
						if(quote.getDeltatype().equalsIgnoreCase("D")){ //khoang gia dung tuyet doi
							beforPrice = beforPrice.add(quote.getDeltavalue()); //gia tham chieu + D
						}else if(quote.getDeltatype().equalsIgnoreCase("P")){ //ti le phan tram
							BigDecimal deltaValue = beforPrice.multiply(quote.getDeltavalue());
							deltaValue = deltaValue.divide(new BigDecimal(100)); //chia cho 100
							beforPrice = beforPrice.add(deltaValue);//P + D 
						}
					}
					
					BigDecimal exePrice = null;
					if(quote.getDeltatype().equalsIgnoreCase("D")){ //khoang gia dung tuyet doi
						exePrice = latestPrice.add(quote.getDeltavalue());//P + D 
						
					}else if(quote.getDeltatype().equalsIgnoreCase("P")){ //ti le phan tram
						//ex: 10%
						BigDecimal deltaValue = latestPrice.multiply(quote.getDeltavalue());
						deltaValue = deltaValue.divide(new BigDecimal(100)); //chia cho 100
						exePrice = latestPrice.add(deltaValue);//P + D 
					}

					
					//tin MIN, f(x) = MIN[f(x-1), P + D ]
					if (exePrice.compareTo(beforPrice) == 1) {
						exePrice = beforPrice;
					}

					
					BigDecimal maxPrice = quote.getMinmaxprice();
					if(maxPrice != null && checkScopeprice(maxPrice, exePrice, "B")){ //gia mua cao nhat
						//BigDecimal orderPrice = getOrderPrice(quote.getPricestep(), maxPrice, symbol, "B");  //gia day so
						orderPrice = getOrderPrice(quote.getPricestep(), latestPrice, symbol, "B");  //gia day so
						activeOrder(quote, orderPrice);
						removeQuoteid = quote.getQuoteid();
					}else{
						orderPrice = getOrderPrice(quote.getPricestep(), latestPrice, symbol, "B");  //gia day so
						
						//f(x) <= P
						if (exePrice.compareTo(latestPrice) == -1 || exePrice.compareTo(latestPrice) == 0 /*&& !quote.getStatus().equalsIgnoreCase("C")*/) {
							//Kich hoat lenh
							activeOrder(quote, orderPrice);
							
							removeQuoteid = quote.getQuoteid();
						} else {
							putTrailPrice(quoteid, exePrice);
						}
					}
					
				} else {//ban
					//tinh gia kich hoat
					BigDecimal beforPrice = trailPriceMap.get(quoteid); //f(x-1)
					if(beforPrice == null){//tinh f0 tai thoi diem ban dau
						beforPrice = CacheProcessing.InstrumentMap.get(symbol).getPriceRF();
						
						if(quote.getDeltatype().equalsIgnoreCase("D")){ //khoang gia dung tuyet doi
							beforPrice = beforPrice.subtract(quote.getDeltavalue()); //gia tham chieu + D
						}else if(quote.getDeltatype().equalsIgnoreCase("P")){ //ti le phan tram
							BigDecimal deltaValue = beforPrice.multiply(quote.getDeltavalue());
							deltaValue = deltaValue.divide(new BigDecimal(100)); //chia cho 100
							beforPrice = beforPrice.subtract(deltaValue);//P + D 
						}
					}
					
					BigDecimal exePrice = null;
					if(quote.getDeltatype().equalsIgnoreCase("D")){ //khoang gia dung tuyet doi
						exePrice = latestPrice.subtract(quote.getDeltavalue()); //P - D 
					}else if(quote.getDeltatype().equalsIgnoreCase("P")){ //ti le phan tram
						//ex: 10%
						BigDecimal deltaValue = latestPrice.multiply(quote.getDeltavalue());
						deltaValue = deltaValue.divide(new BigDecimal(100)); //chia cho 100
						exePrice = latestPrice.subtract(deltaValue);//P - D 
					}
					
					//tinh MAX, f(x) = MAX [f(x-1), P - D ]
					if (exePrice.compareTo(beforPrice) == -1) {
						exePrice = beforPrice;
					}
					
					
					
					BigDecimal minPrice = quote.getMinmaxprice();
					if(minPrice != null && checkScopeprice(minPrice, exePrice, "S")){//gia ban thap nhat
						//BigDecimal orderPrice = getOrderPrice(quote.getPricestep(), minPrice, symbol,"S"); //gia day so
						orderPrice = getOrderPrice(quote.getPricestep(), latestPrice, symbol,"S"); //gia day so
						activeOrder(quote, orderPrice);
						removeQuoteid = quote.getQuoteid();
					}else{
						orderPrice = getOrderPrice(quote.getPricestep(), latestPrice, symbol,"S"); //gia day so
						
						//f(x) >= P
						if (exePrice.compareTo(latestPrice) == 1 || exePrice.compareTo(latestPrice) == 0) {
							
							activeOrder(quote, orderPrice);
							
							removeQuoteid = quote.getQuoteid();
							
						} else {
							//update f(x-1)
							putTrailPrice(quoteid, exePrice);
						}
					}
					
				}
			}
			
			//remove cache and update database:
			if(removeQuoteid != null){
				
				//xoa quoteid khoi trailpricemap khi lenh da kich hoat
				removeTrailPrice(removeQuoteid);
				
				//xoa khoi orders list
				Map<String,Quote> tsoOrders = HandlerCacheData.tsoMap.get(symbol);
				tsoOrders.remove(removeQuoteid);
				
				//syn to DB
				TSODBPersistent obj = new TSODBPersistent();
				obj.updateTSOOrder(quote, CommonConstants.ORDER_STATUS_ACTIVING, orderPrice);
			}
		//}	//synchronized	
	}

	public void putRequest(Quote quote) {

	}

	public synchronized static void putTrailPrice(String quoteid, BigDecimal price) {
		trailPriceMap.put(quoteid, price);
		
		//save to DB
		//TODO: turning
		TSODBPersistent obj = new TSODBPersistent();
		obj.updateFX1TSO(quoteid, price);
	}

	public static void removeTrailPrice(String quoteid) {
		synchronized (trailPriceMap) {
			trailPriceMap.remove(quoteid);
		}
	}
	
	private void activeOrder(Quote quote, BigDecimal orderPrice){
		//kich hoat lenh
		//Kich hoat lenh
		logger.info("Active TSO Order========quoteid:" + quote.getQuoteid() + ",orderPrice:" + orderPrice);
		try {
			TicketQueue queThread = TicketQueue.getTicketQueueThread();
			quote.setPrice(orderPrice);
			queue = queThread.getTicketqueue();
			queue.put(quote);
		} catch (InterruptedException e) {
			SLF4JLoggerProxy.error(this, "Error when active TSO Order========quoteid:" + quote.getQuoteid());
		}	
	}
	
	private boolean checkScopeprice(BigDecimal scopeprice, BigDecimal exePrice, String side){
		if(side.equalsIgnoreCase("B") && scopeprice != null && (exePrice.compareTo(scopeprice) == -1 || exePrice.compareTo(scopeprice) == 0)){ //gia mua cao nhat
			return true;
		}else if(side.equalsIgnoreCase("S") && scopeprice != null && (exePrice.compareTo(scopeprice) == 1 || exePrice.compareTo(scopeprice) == 0)){//gia ban thap nhat
			return true;
		}
		
		return false;
	}
	
	private BigDecimal getOrderPrice(BigDecimal stepPrice, BigDecimal latestPrice, String symbol, String side){
		
		if(stepPrice == null){
			return latestPrice;
		}
		
		BigDecimal orderPrice = null;
		String exchange = CacheProcessing.InstrumentMap.get(symbol).getExchange();
		String board = CacheProcessing.InstrumentMap.get(symbol).getBoard();
		BigDecimal price_ce = CacheProcessing.InstrumentMap.get(symbol).getPriceCE();
		BigDecimal price_fl = CacheProcessing.InstrumentMap.get(symbol).getPriceFL();
		
		String key = exchange + "." + board;
		
		ArrayList<TickSize> list = (ArrayList<TickSize>) CacheProcessing.ticksizeMap.getCollection(key);
		
		orderPrice = latestPrice;
				
		for(int k = 0; k < stepPrice.intValue(); k++){	
			for(int i = 0; i < list.size(); i++){
				TickSize ticksizeObj = list.get(i);
				if(orderPrice.compareTo(ticksizeObj.getFromPrice()) >=0 && orderPrice.compareTo(ticksizeObj.getToPrice()) <0){
					
					Long tickSize = ticksizeObj.getTickSize();
					if(side.equalsIgnoreCase("B")){//Mua
						//orderPrice = latestPrice.add(stepPrice.multiply(new BigDecimal(tickSize)));
						orderPrice = orderPrice.add((new BigDecimal(tickSize)));
						if(orderPrice.compareTo(price_ce) > 0){
							orderPrice = price_ce;
						}
					}else {//Ban
						orderPrice = orderPrice.subtract((new BigDecimal(tickSize)));
						if(orderPrice.compareTo(price_fl) < 0){
							orderPrice = price_fl;
						}
					}
					
					break;
					
				}
			}
		}
		
		
		
		return orderPrice;
	}
}
