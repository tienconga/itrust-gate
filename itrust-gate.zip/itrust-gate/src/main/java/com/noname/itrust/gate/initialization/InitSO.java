package com.noname.itrust.gate.initialization;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.stereotype.Service;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.sql.SQLStatement;

@Service
public class InitSO {

	/**
	 * init SO orders
	 */
	public void initSO(){
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
	        ps = conn.prepareStatement(ConnectionManager.sqlMap.get(SQLStatement.KEY_SEL_SO));
	        rs = ps.executeQuery();
		   
	        while(rs.next()){
	        	String quoteid = rs.getString("QUOTEID");
	        	String acctno = rs.getString("ACCTNO");
	        	String symbol = rs.getString("SYMBOL");
	        	Long qtty = rs.getLong("QTTY");
	        	String side = rs.getString("SIDE");
	        	BigDecimal price =rs.getBigDecimal("PRICE");
	        	BigDecimal pricedelta = rs.getBigDecimal("PRICE_DELTA");
	        	String devide_type = rs.getString("DEVIDE_TYPE");
	        	Long qtty_size = rs.getLong("QTTY_SIZE");
	        	Long qtty_delta = rs.getLong("QTTY_DELTA");
	        	int time_period = rs.getInt("TIME_PERIOD");
	        	int time_delta = rs.getInt("TIME_DELTA");
	        	String status = rs.getString("STATUS");
	        	String userid = rs.getString("USERID");
	        	String typecd = rs.getString("TYPECD");
	        	
	        	Quote soOrder = new Quote();
	        	soOrder.setQuoteid(quoteid);
	        	soOrder.setAcctno(acctno);
	        	soOrder.setSymbol(symbol);
	        	soOrder.setQtty(qtty);
	        	soOrder.setSide(side);
	        	soOrder.setPrice(price);
	        	soOrder.setPricedelta(pricedelta);
	        	soOrder.setDevide_type(devide_type);
	        	soOrder.setQtty_size(qtty_size);
	        	soOrder.setQttyDelta(qtty_delta);
	        	soOrder.setTime_period(time_period);
	        	soOrder.setTime_delta(time_delta);
	        	soOrder.setStatus(status);
	        	soOrder.setUserid(userid);
	        	soOrder.setTypecd(typecd);
	        	
	        	soOrder.setClasscd("SO");
	        	if(devide_type != null && devide_type.equalsIgnoreCase("T")){
	        		HandlerCacheData.soTypeTMap.put(quoteid, soOrder);
	        	}else{
	        		HandlerCacheData.soMap.put(quoteid, soOrder);
	        	}
	        	
	        	/*Map<String, Quote> orderInfos = HandlerCacheData.soMap.get(symbol);
				if(orderInfos == null){//chua co ma chung khoan nay trong he thong
					orderInfos = new HashMap<String, Quote>();
					orderInfos.put(quoteid, soOrder);
					HandlerCacheData.soMap.put(symbol, orderInfos);
				}else{//da ton tai ma chung khoan nay
					orderInfos.put(quoteid, soOrder);
				}*/
	        }
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}
	}
}
