package com.noname.itrust.gate.ws;

import javax.jws.WebService;

@WebService
public interface IFrontGateService {

	public String sendMessage(String inputString) ;

	
}
