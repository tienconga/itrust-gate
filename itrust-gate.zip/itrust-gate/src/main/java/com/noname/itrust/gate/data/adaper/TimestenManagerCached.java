package com.noname.itrust.gate.data.adaper;

import java.sql.SQLException;
import java.util.Map;

import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;

public class TimestenManagerCached {
	private TimesTenConnectionPool connPool;

	private String url;

	private String user;

	private String password;

	private int numConnections;

	private boolean enablefailover;

	public TimesTenPooledConnection getConnection() throws SQLException {
		return connPool.getConnectionWait();
	}

	public void init() throws SQLException {
		connPool = new TimesTenConnectionPool(getNumConnections());
		connPool.initialise(getUrl(), user, password, isEnablefailover());
		connPool.enable();
	}

	public void registerCallableStatement(String label, String sql) throws SQLException {
		connPool.addCallableStatement(label, sql);
	}

	/**
	 * 
	 * @param args arg[0]: label arg[1]: sql
	 * @throws SQLException
	 */
	public void setCallableStatements(Map<String, String> map) throws SQLException {
		for (String label : map.keySet()) {
			registerCallableStatement(label, map.get(label));
		}
	}

	public void registerPreparedStatement(String label, String sql) throws SQLException {
		connPool.addPreparedStatement(label, sql);
	}

	/**
	 * 
	 * @param args arg[0]: label arg[1]: sql
	 * @throws SQLException
	 */
	public void setPreparedStatements(Map<String, String> map) throws SQLException {
		for (String label : map.keySet()) {
			registerPreparedStatement(label, map.get(label));
		}
	}

	public void closeConnection(TimesTenPooledConnection connection) {
		try {
			connPool.releaseConnection(connection);
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this , e);
		}
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getNumConnections() {
		return numConnections;
	}

	public void setNumConnections(int numConnections) {
		this.numConnections = numConnections;
	}

	public boolean isEnablefailover() {
		return enablefailover;
	}

	public void setEnablefailover(boolean enablefailover) {
		this.enablefailover = enablefailover;
	}
}
