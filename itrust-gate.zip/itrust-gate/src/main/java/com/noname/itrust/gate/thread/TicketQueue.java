package com.noname.itrust.gate.thread;

import java.util.concurrent.LinkedBlockingQueue;
import org.apache.log4j.Logger;
import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;

public class TicketQueue extends Thread {

	final static Logger logger = Logger.getLogger(TicketQueue.class);

	public LinkedBlockingQueue<Quote> ticketqueue = new LinkedBlockingQueue<Quote>(); //orders send to exchange

	private static volatile TicketQueue ticketQueueThread = null;

	public static void init() {
		TicketQueue.getTicketQueueThread();
		ticketQueueThread.start();
	}

	public static TicketQueue getTicketQueueThread() {
		if (ticketQueueThread == null) {
			ticketQueueThread = new TicketQueue();
		}
		return ticketQueueThread;
	}

	public static void setTicketQueueThread(TicketQueue ticketQueueThreadArg) {
		ticketQueueThread = ticketQueueThreadArg;
	}

	public LinkedBlockingQueue<Quote> getTicketqueue() {
		return ticketqueue;
	}

	public void setTicketqueue(LinkedBlockingQueue<Quote> ticketqueue) {
		this.ticketqueue = ticketqueue;
	}

	public void run() {
		synchronized (ticketqueue) {
			try {
				while (true) {
					Quote ticket = (Quote) ticketqueue.take();
					logger.info("take========:" + ticket.getQuoteid());
					//OrderSending sender = new OrderSending();
					//sender.placeOrder(ticket);
					OrderThreadMgr threadMgr = OrderThreadMgr.getThreadMgr();
					threadMgr.fireEmptyThread(1, ticket, null);
				}

			} catch (Exception e) {
				SLF4JLoggerProxy.error(this, e);
			}
		}
	}
}
