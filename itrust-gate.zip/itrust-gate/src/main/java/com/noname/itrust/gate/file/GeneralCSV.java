package com.noname.itrust.gate.file;

import java.io.FileWriter;
import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fss.fo.mserver.exchange.MarketInforProtos.MarketInfor;
import com.fss.fo.mserver.exchange.StockInforProtos.StockInfor;
import com.fss.fo.mserver.exchange.TransLogProtos.TransLog;
import com.noname.itrust.gate.common.Properties;

@Service
public class GeneralCSV {

	@Autowired
	private Properties properties;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public void writeMarketInfor(MarketInfor mkt, String mode){
		if(properties.getWritingFileMode().equalsIgnoreCase("OFF")){
			return;
		}
		
		String fileName = "";
		if(mode.equalsIgnoreCase("BEFORE")){
			//fileName = "D:\\Working\\WorkSpace_MSBS\\newfo-tool\\data\\MarketInfor.csv";
			fileName = properties.getMarketInforFileName();
		}else if(mode.equalsIgnoreCase("AFTER")){
			//fileName = "D:\\Working\\WorkSpace_MSBS\\newfo-tool\\data\\MarketInfor_Filtered.csv";
			fileName = properties.getMarketInfoFileName_filterd();
		}
		
		try
		{
		    FileWriter writer = new FileWriter(fileName,true);
			 
		    writer.append(mkt.getMarketIndex());
		    writer.append(',');
		    writer.append(mkt.getTradingdate());
		    //writer.append(',');
		    //writer.append(mkt.getSequenceMsg());
		    writer.append(',');
		    writer.append(mkt.getIndexTime());
		    writer.append(',');
		    writer.append(mkt.getIndexColor());
		    writer.append(',');
		    writer.append(mkt.getIndexChange());
		    writer.append(',');
		    writer.append(mkt.getIndexPercentChange());
		    writer.append(',');
		    writer.append(mkt.getTotalTrade());
		    writer.append(',');
		    writer.append(mkt.getTotalVolume());
		    writer.append(',');
		    writer.append(mkt.getTotalValue());
		    writer.append(',');
		    writer.append(mkt.getMarketStatus());
		    writer.append(',');
		    writer.append(mkt.getAdvances());
		    writer.append(',');
		    writer.append(mkt.getDeclines());
		    writer.append(',');
		    writer.append(mkt.getNoChange());
		    writer.append(',');
		    writer.append(mkt.getAdvancesVolumn());
		    writer.append(',');
		    writer.append(mkt.getDeclinesVolumn());
		    writer.append(',');
		    writer.append(mkt.getNoChangeVolumn());
		    writer.append(',');
		    writer.append(mkt.getMarketId());
		    writer.append(',');
		    writer.append(mkt.getMarketCode());
		    
		    writer.append('\n');
								
		    writer.flush();
		    writer.close();
		}
		catch(IOException e){
			e.printStackTrace();
		} 
	
	}

	public void writeStockInfor(StockInfor stock, String mode){
		if(properties.getWritingFileMode().equalsIgnoreCase("OFF")){
			return;
		}
		
		String fileName = "";
		if(mode.equalsIgnoreCase("BEFORE")){
			//fileName = "D:\\Working\\WorkSpace_MSBS\\newfo-tool\\data\\StockInfor.csv";
			fileName = properties.getStockinforFileName();
		}else if(mode.equalsIgnoreCase("AFTER")){
			//fileName = "D:\\Working\\WorkSpace_MSBS\\newfo-tool\\data\\StockInfor_Filtered.csv";
			fileName = properties.getMarketInfoFileName_filterd();
		}
		
		try{		
		    FileWriter writer = new FileWriter(fileName,true);
			 
		    writer.append(stock.getSymbol());
		    writer.append(',');
		    writer.append(stock.getTradingdate());
		    writer.append(",");
		    writer.append(stock.getFloorCode());
		    writer.append(',');
		    writer.append(stock.getStockType());
		    writer.append(',');
		    writer.append(stock.getCeiling());
		    writer.append(',');
		    writer.append(stock.getFloor());
		    writer.append(',');
		    writer.append(stock.getReference());
		    writer.append(',');
		    writer.append(stock.getBidPrice3());
		    writer.append(',');
		    writer.append(stock.getBidVol3());
		    writer.append(',');
		    writer.append(stock.getBidPrice2());
		    writer.append(',');
		    writer.append(stock.getBidVol2());
		    writer.append(',');
		    writer.append(stock.getBidPrice1());
		    writer.append(',');
		    writer.append(stock.getBidVol1());
		    writer.append(',');
		    writer.append(stock.getClosePrice());
		    writer.append(',');
		    writer.append(stock.getCloseVol());
		    writer.append(',');
		    writer.append(stock.getChange());
		    writer.append(',');
		    writer.append(stock.getOfferPrice1());
		    writer.append(',');
		    writer.append(stock.getOfferVol1());
		    writer.append(',');
		    writer.append(stock.getOfferPrice2());
		    writer.append(',');
		    writer.append(stock.getOfferVol2());
		    writer.append(',');
		    writer.append(stock.getOfferPrice3());
		    writer.append(',');
		    writer.append(stock.getOfferVol3());

		    writer.append('\n');
								
		    writer.flush();
		    writer.close();
		}
		catch(IOException e){
		     e.printStackTrace();
		} 
	}

	public void writeTransLog(TransLog trans, String mode){
		if(properties.getWritingFileMode().equalsIgnoreCase("OFF")){
			return;
		}
		
		String fileName = "";
		if(mode.equalsIgnoreCase("BEFORE")){
			//fileName = "D:\\Working\\WorkSpace_MSBS\\newfo-tool\\data\\TransLog.csv";
			fileName = properties.getTranslogFileName();
		}else if(mode.equalsIgnoreCase("AFTER")){
			fileName = properties.getTranslogFileName_filterd();
		}
		
		try{
		    FileWriter writer = new FileWriter(fileName,true);
			 
		    writer.append(trans.getSymbol());
		    writer.append(',');
		    writer.append(trans.getTradingdate());
		    writer.append(",");
		    writer.append(trans.getFormattedTime());
		    writer.append(',');
		    writer.append(trans.getLastColor());
		    writer.append(',');
		    writer.append(trans.getFormattedMatchPrice());
		    writer.append(',');
		    writer.append(trans.getChangeColor());
		    writer.append(',');
		    writer.append(trans.getFormattedChangeValue());
		    writer.append(',');
		    writer.append(trans.getFormattedVol());
		    writer.append(',');
		    writer.append(trans.getFormattedAccVol());
		    writer.append(',');
		    writer.append(trans.getFormattedAccVal());
		   
		    writer.append('\n');
								
		    writer.flush();
		    writer.close();
		}
		catch(IOException e){
		     e.printStackTrace();
		} 
	
	}
}
