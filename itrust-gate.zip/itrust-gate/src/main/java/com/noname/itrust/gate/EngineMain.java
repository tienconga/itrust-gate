package com.noname.itrust.gate;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.fss.newfo.common.utility.StringUtils;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.ws.IFrontGateService;

public class EngineMain {

	final static Logger logger = Logger.getLogger(EngineMain.class);

	static final Logger debugLog = Logger.getLogger("BAR");
	static final Logger resultLog = Logger.getLogger("FOO");



	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			//debugLog.info("Hello BAR");
			//resultLog.info("Hello FOO");
			new EngineMain().start();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getStackTrace());
			System.exit(0);
		}
	}

	void start() throws SQLException, IOException {
		FileSystemXmlApplicationContext context =
				new FileSystemXmlApplicationContext(new String[] { "classpath:META-INF/spring/spring.xml" });
		context.registerShutdownHook();
		context.start();
		//ConfigLoader.loadJMSProperties("Market_JMS.properties", "MARKET");
		//MarketListenerTest.init();
		SLF4JLoggerProxy.info(this, "Start sucessful!");


		//load properties
		/*ConfigLoader.loadJMSProperties("Request_JMS.properties", "REQUEST");
		ConfigLoader.loadJMSProperties("Market_JMS.properties", "MARKET");
		ConfigLoader.loadJMSProperties("Trading_JMS.properties", "TRADING");

		ConfigLoader.loadProperties("default.properties");

		//init cache
		HandlerCacheData.initCache();

		//init sending order
		TicketQueue.init();

		//init timesten
		//TimestenManager.init();

		//init cache
		//CacheProcessing.initCache();

		//init request jms listener
		RequestsListener.init();
		MarketListener.init();*/

		//service = new FrontGateServiceService();
		//obj = service.getFrontGateServicePort();
		
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		String s;
		while ((s = in.readLine()) != null) {
			if(s.equalsIgnoreCase("refresh")){
				SLF4JLoggerProxy.info(this, "Refreshing...");
				context.close();
				context.start();
				SLF4JLoggerProxy.info(this, "Refreshed.");
			} else if (s.equalsIgnoreCase("quit")) {
				SLF4JLoggerProxy.info(this, "FOProcessor Exiting...");
				context.close();
				System.exit(0);
			} else if (s.equalsIgnoreCase("test")) {
				SLF4JLoggerProxy.info(this, "FOProcessor Testing. Input Msg:");
				
				//Create message from console line
				String message = in.readLine();
				
				//Create json string
				if(StringUtils.isEmpty(message)){
					//message = createIncreaseMoneyMSG(in);
					//message = createMessageTest(in);
				}
				
				IFrontGateService service = (IFrontGateService)context.getBean("foService");
				try {
					String result = service.sendMessage(message.toString());
					System.out.println("Test completed: " + result);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
}
