package com.noname.itrust.gate.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * 
 * @author tiendt
 *
 */
public class ConfigLoader {

	public static Properties senderProps;
	public static Properties jmsProps;
	public static Properties marketJMSProps;
	public static Properties gwSessionJMSProps;

	public static void loadProperties(String propertyFileName,String propsNam)
			throws java.io.FileNotFoundException {

		InputStream is = null;
		try {
			//String configPath = System.getProperty("configPath");

			//File file = new File(configPath + "/" + propertyFileName);
			File file = new File(propertyFileName);
			is = new FileInputStream(file);

			// load properties
			if(propsNam.equalsIgnoreCase("RequestsListener")){
				jmsProps = new Properties();
				jmsProps.load(is);
			}else if(propsNam.equalsIgnoreCase("MarketListenerTest")){
				marketJMSProps = new Properties();
				marketJMSProps.load(is);
			}else if(propsNam.equalsIgnoreCase("LocalSender")){
				senderProps = new Properties();
				senderProps.load(is);
			}
			

		} catch (Exception ignore) {
			ignore.printStackTrace();
			throw new java.io.FileNotFoundException(
					propertyFileName + " not found");
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static void loadJMSProperties(String propertyFileName, String type)
			throws java.io.FileNotFoundException {

		InputStream is = null;
		try {
			String configPath = System.getProperty("configPath");

			File file = new File(configPath + "/" + propertyFileName);
			is = new FileInputStream(file);

			// load properties
			if (type.equalsIgnoreCase("REQUEST")) {
				jmsProps = new Properties();
				jmsProps.load(is);
			} else if (type.equalsIgnoreCase("MARKET")) {
				marketJMSProps = new Properties();
				marketJMSProps.load(is);
			} else if (type.equalsIgnoreCase("SESSION")) {
				gwSessionJMSProps = new Properties();
				gwSessionJMSProps.load(is);
			}

		} catch (Exception ignore) {
			ignore.printStackTrace();
			throw new java.io.FileNotFoundException(
					propertyFileName + " not found");
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		//Properties pros = getProperties("");

	}
}
