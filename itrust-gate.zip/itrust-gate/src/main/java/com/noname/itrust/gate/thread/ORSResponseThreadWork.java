package com.noname.itrust.gate.thread;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.fss.newfo.common.model.ORSObject;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.ors.response.ORSResponse;

/**
 * 
 * @author do.tran.tien
 *
 */
@Component
public class ORSResponseThreadWork implements Runnable {

	final static Logger logger = Logger.getLogger(ORSResponseThreadWork.class);
	
	private ORSObject orsObject;
	private ORSResponse oRSResponse;
	
	public ORSResponseThreadWork(){}
	
	public ORSResponseThreadWork(ORSObject orsObject, ORSResponse oRSResponse) {
		this.orsObject = orsObject;
		this.oRSResponse = oRSResponse;
	}

	private void doMyTask() {
		//ORSResponse responseObj = new ORSResponse();
		oRSResponse.proces(orsObject);	
	}

	public void run() {
		try {
			doMyTask();
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}

	}

}
