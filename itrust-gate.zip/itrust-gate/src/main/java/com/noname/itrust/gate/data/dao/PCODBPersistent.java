package com.noname.itrust.gate.data.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.sql.SQLStatement;


public class PCODBPersistent {
	
	public void insertPCO(Quote quote, String status) {
		Connection conn = null;
		CallableStatement callableStatement = null; 
        ConnectionManager mgr = new ConnectionManager();
         
        String log = "";
        String p_err_code = "After execute:";
        try {
        	conn = mgr.getConnection();
			callableStatement = conn.prepareCall(ConnectionManager.sqlMap.get(SQLStatement.KEY_INSERT_PCO));
			callableStatement.registerOutParameter(1, Types.VARCHAR);// p_err_code
			callableStatement.setString(2, quote.getQuoteid()); // p_quoteid
			callableStatement.setString(3, quote.getAcctno());// p_acctno :
			callableStatement.setString(4, quote.getSymbol());// p_symbol
			callableStatement.setLong(5, quote.getQtty());// p_qtty
			callableStatement.setString(6, quote.getSide());// p_side
			
			callableStatement.setDate(7, new java.sql.Date(quote.getCreateddt().getTime()));// p_fromdate
			callableStatement.setDate(8, new java.sql.Date(quote.getExpireddt().getTime()));// p_todate
			
			callableStatement.setString(9, quote.getPricetype());// p_active_price
			callableStatement.setString(10, status);// p_status
			callableStatement.setString(11,quote.getBroker()); // p_broker
			
			log = "store parametter -|  CSPKS_HFT_SAVE_NEW.sp_create_pco_orders |  p_quoteid: " + quote.getQuoteid()
			+ "|  p_acctno: " + quote.getAcctno() + "|  p_symbol: " + quote.getSymbol()
			+ "|  p_qtty: " + quote.getQtty() + "|  p_side: " + quote.getSide()
			+ "|  p_fromdate: " + quote.getCreateddt() + "|  p_todate: " + quote.getExpireddt() 
			+ "| p_active_price:" + quote.getPricetype() + "| p_status:" + status
			+ "| p_broker:" + quote.getBroker();
			
			SLF4JLoggerProxy.info(this, log);
			callableStatement.execute();
			p_err_code = callableStatement.getString(1);
			conn.commit();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if (callableStatement != null) {
					callableStatement.clearParameters();
					callableStatement.close();
					callableStatement = null;
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
			
			SLF4JLoggerProxy.info(this, p_err_code);
		}
		
	}
	
	

}
