package com.noname.itrust.gate.aq;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import org.apache.activemq.command.ActiveMQTextMessage;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fss.newfo.common.constant.Fields;
import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.github.fge.jackson.JsonLoader;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.common.ConfigLoader;
import com.noname.itrust.gate.processing.AbstracRequestHandler;

public class RequestsListener implements MessageListener {

	private Context context = null;
	private QueueConnectionFactory queueConnectionFactory = null;
	private QueueConnection queueConnection = null;
	private QueueSession queueSession = null;
	private Queue queue = null;;
	private MessageConsumer consumer = null;
	private String queueName = "";
	private boolean connectStatus = true;

	/*public RequestsListener(String jmsProperties) {
		try {
			connect();
		} catch (Exception e) {
			logger.error(e.getStackTrace());
		}
	}*/

	public RequestsListener(String jmsProperties) {
		HandlerCacheData.initCache();
		
		try {
			if (ConfigLoader.jmsProps == null) {
				ConfigLoader.loadProperties(jmsProperties,"RequestsListener");
			}

			connect();
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}
	}
	
	public RequestsListener() {
		connect();
	}

	public static void init() {
		RequestsListener instance = new RequestsListener();
		instance.connect();
	}

	public void connect() {
		try {
			queueName = ConfigLoader.jmsProps.getProperty("queue.JMS_MESSAGE_ENGINE_REQUEST");
			context = new InitialContext(ConfigLoader.jmsProps);
			queueConnectionFactory = (QueueConnectionFactory) context.lookup("QueueConnectionFactory");
			queueConnection = queueConnectionFactory.createQueueConnection("karaf", "karaf");
			queueSession = queueConnection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			queue = queueSession.createQueue(queueName);
			consumer = queueSession.createConsumer(queue);
			consumer.setMessageListener(this);
			queueConnection.start();
		} catch (Exception e) {
			connectStatus = false;
			SLF4JLoggerProxy.info(this, e);
		}
	}

	public boolean connectStatus() {
		try {
			if ((connectStatus) && (queueConnection.getExceptionListener() != null))
				connectStatus = false;
		} catch (JMSException e) {
			connectStatus = false;
		}
		return connectStatus;
	}

	public void disconnect() {
		try {
			if (queueConnection != null) {
				queueConnection.stop();
				queueSession.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			queueConnection = null;
			queueSession = null;
		}
	}

	@Override
	public void onMessage(Message msg) {
		if (msg instanceof ActiveMQTextMessage) {
			try {
				String str = ((ActiveMQTextMessage) msg).getText();
				ObjectNode node;
				node = (ObjectNode) JsonLoader.fromString(str);
				node.put(Fields.OBJECT_TYPE,"Quote");
				node.remove("errorcode");
				ObjectMapper mapper = new ObjectMapper();				
				Quote message = mapper.readValue(node.traverse(), Quote.class);
				Quote quote = (Quote) message;
				//RequestHandler handler = HandlerCacheData.requestHandlerMap.get(quote.getClasscd().toUpperCase());
				AbstracRequestHandler handler = HandlerCacheData.requestHandlerMap.get(quote.getMsgtype());
				handler.execute(quote);
				
			} catch (Exception e) {
				SLF4JLoggerProxy.info(this, e);
			}
		}
	}
}
