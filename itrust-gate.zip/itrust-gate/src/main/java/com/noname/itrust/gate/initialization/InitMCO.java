package com.noname.itrust.gate.initialization;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import org.springframework.stereotype.Service;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.sql.SQLStatement;

@Service
public class InitMCO {

	/**
	 * init TSO orders
	 */
	public void initMCO(){/*
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
	        ps = conn.prepareStatement(ConnectionManager.sqlMap.get(SQLStatement.KEY_SEL_MCO));
	        rs = ps.executeQuery();
		   
	        while(rs.next()){
	        	String quoteid = rs.getString("QUOTEID");
	        	String acctno = rs.getString("ACCTNO");
	        	String symbol = rs.getString("SYMBOL");
	        	Long qtty = rs.getLong("QTTY");
	        	BigDecimal price =rs.getBigDecimal("PRICE");
	        	String side = rs.getString("SIDE");
	        	String status = rs.getString("STATUS");
	        	String condition1 = rs.getString("CONDITION1");
	        	String operation1 = rs.getString("OPERATION1");
	        	int value1 = rs.getInt("VALUE1");
	        	String condition2 = rs.getString("CONDITION2");
	        	String operation2 = rs.getString("OPERATION2");
	        	int value2 = rs.getInt("VALUE2");
	        	String condition3 = rs.getString("CONDITION3");
	        	String operation3 = rs.getString("OPERATION3");
	        	int value3 = rs.getInt("VALUE3");
	        	String condition4 = rs.getString("CONDITION4");
	        	String operation4 = rs.getString("OPERATION4");
	        	int value4 = rs.getInt("VALUE4");
	        	
	        	Date fromdate = rs.getDate("FROMDATE");
	        	Date todate = rs.getDate("TODATE");
	        	String userid = rs.getString("USERID");
	        	String typecd = rs.getString("TYPECD");
	        	
	        	Quote mcoOrder = new Quote();
	        	mcoOrder.setQuoteid(quoteid);
	        	mcoOrder.setAcctno(acctno);
	        	mcoOrder.setSymbol(symbol);
	        	mcoOrder.setQtty(qtty);
	        	mcoOrder.setPrice(price);
	        	mcoOrder.setSide(side);
	        	mcoOrder.setStatus(status);
	        	mcoOrder.setCondition1(condition1);
	        	mcoOrder.setOperation1(operation1);
	        	mcoOrder.setValue1(value1);
	        	mcoOrder.setCondition2(condition2);
	        	mcoOrder.setOperation2(operation2);
	        	mcoOrder.setValue2(value2);
	        	mcoOrder.setCondition3(condition3);
	        	mcoOrder.setOperation3(operation3);
	        	mcoOrder.setValue3(value3);
	        	mcoOrder.setCondition4(condition4);
	        	mcoOrder.setOperation4(operation4);
	        	mcoOrder.setValue4(value4);
	        	mcoOrder.setCreateddt(fromdate);
	        	mcoOrder.setExpireddt(todate);
	        	mcoOrder.setUserid(userid);
	        	mcoOrder.setTypecd(typecd);
	        	
	        	if(condition1 == null){
	        		mcoOrder.setConditionStatus1(true);
	        	}
	        	
	        	if(condition2 == null){
	        		mcoOrder.setConditionStatus2(true);
	        	}
	        	
	        	if(condition3 == null){
	        		mcoOrder.setConditionStatus3(true);
	        	}
	        	
	        	if(condition4 == null){
	        		mcoOrder.setConditionStatus4(true);
	        	}
	        	
	        	mcoOrder.setClasscd("MCO");
	        	
	        	HandlerCacheData.mcoMap.put(quoteid, mcoOrder);
	
	        }
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}
	*/}
}
