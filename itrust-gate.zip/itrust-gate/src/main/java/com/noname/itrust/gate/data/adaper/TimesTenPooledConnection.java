package com.noname.itrust.gate.data.adaper;
import java.util.*;
import java.sql.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;
import com.timesten.jdbc.*;

/**
 * Represents a pooled TimesTen database connection (JDBC).
 * This class implements the TimesTenConnection interface, plus a few 
 * additional methods.
 * <p><p>
 * This class should not be instantiated directly. Instances should 
 * be obtained via the various 'getConnection' methods provided by the 
 * TimesTenConnectionPool class. 
 * <p><p>
 * Any one instance of this class should not be shared amongst multiple 
 * threads; each thread should get its own connection from the pool.
 * <p><p>
 * If this connection has been invalidated due to a failover most methods will 
 * throw a TTCP_ERR_CONN_INVALID exception. The application needs to wait for
 * the failover to complete by using the waitForFailover() methods in the
 * owning connection pool before it can continue using connections from the
 * pool.
 */
public final class TimesTenPooledConnection 
	implements TimesTenConnection
{
    //////////////// CONSTANTS /////////////////
    //
    private static final String className = "TimesTenPooledConnection";

    // Default initial number of prepared statements
    private static final int INITIAL_NUMBER_OF_PREPARED_STMTS = 64;
    private static final int INITIAL_NUMBER_OF_CALLABLE_STMTS = 64;
    private static final int INITIAL_NUMBER_OF_STMTS = 8;

    //////////////// PRIVATE VARIABLES /////////////////

    // Lock for things that affect the connection
    private ReentrantLock connLock = null;   

    // The underlying TimesTenConnection for this
    private TimesTenConnection  conn = null;

    // Failover handler
    private ClientFailoverEventListener failoverHandler = null;

    // List of prepared statements for this TimesTenPooledConnection
    private HashMap<String,TimesTenPooledPreparedStatement> pStmt = null;

    // List of callable statements for this TimesTenPooledConnection
    private HashMap<String,TimesTenPooledCallableStatement> cStmt = null;

    // List of statements for this TimesTenPooledConnection
    private HashMap<String,TimesTenPooledStatement> sStmt = null;

    // The TimesTenConnectionPool that owns this connection
    private TimesTenConnectionPool pool = null;

    // Connection state flags
    private volatile boolean inUse = false; // currently checked out of pool?
    private volatile boolean inTxn = false; // open transaction
    private volatile boolean isDefunct = false; // invalid due to failover
    private volatile boolean isOpen = false; // Is connection open?

    // Unique ID used to identify connection internally
    // Assigned by TimesTenConnectionPool
    private Integer ID = null;

    //////////////// CONSTRUCTORS /////////////////

    protected TimesTenPooledConnection(TimesTenConnection ttconn, 
	                               TimesTenConnectionPool ttpool)
    {
        this.conn = ttconn;
	this.pStmt = 
	 new HashMap<String,TimesTenPooledPreparedStatement>(INITIAL_NUMBER_OF_PREPARED_STMTS);
	this.cStmt = 
	 new HashMap<String,TimesTenPooledCallableStatement>(INITIAL_NUMBER_OF_CALLABLE_STMTS);
	this.sStmt = 
	 new HashMap<String,TimesTenPooledStatement>(INITIAL_NUMBER_OF_STMTS);
	this.isOpen = true;
	ID = new Integer(0);
	this.pool = ttpool;
        connLock = new ReentrantLock(ttpool.getLockingFairness());
    }

    ////////////// FINALIZER /////////////

    protected void finalize()
	    throws Throwable
    {
        ID = null;
        pool = null;
        pStmt = null;
        sStmt = null;
        failoverHandler = null;
        connLock = null;
	if (  this.conn != null  )
	    try {
	       conn.close();
	    } catch ( SQLException e ) {
		// ignore it
	    }
	super.finalize();
    }

    //////////////// PRIVATE METHODS /////////////////

    // lock the connection
    private final void lockConn()
    {
	this.connLock.lock();
    }

    // unlock the connection
    private final void unlockConn()
    {
	this.connLock.unlock();
    }

    // Check if connection is locked
    private final boolean isConnLocked()
    {
	return this.connLock.isLocked();
    }

    // Checks if connection is defunct
    private void checkDefunct(String funcname)
	    throws SQLException
    {
	if (  this.isDefunct  )
	    throw new SQLException(
	        className + ":" + funcname + ":connection invalid due to failover",
		TimesTenConnectionPool.TTCP_SQLSTATE,
		TimesTenConnectionPool.TTCP_ERR_CONN_INVALID);
    }

    //////////////// PROTECTED METHODS /////////////////

    // Removes the failover handler
    protected final void removeFailoverHandler()
	    throws SQLException
    {
	lockConn();
	try {
	    if (  this.failoverHandler != null  )
	    {
                this.conn.removeConnectionEventListener(this.failoverHandler);
	        this.failoverHandler = null;
	    }
	} finally {
	    unlockConn();
	}
    }

    // Adds a failover handler
    protected final void addFailoverHandler(ClientFailoverEventListener handler)
	    throws SQLException
    {
	lockConn();
	try {
	    this.removeFailoverHandler();
	    if (  handler != null  )
	    {
                this.conn.addConnectionEventListener(handler);
	        this.failoverHandler = handler;
	    }
	}
	finally {
	    unlockConn();
	}
    }

    // Returns the encapsulated TimesTenConnection
    protected final TimesTenConnection getNativeConnection()
    {
	return this.conn;
    }
 
    // Returns an iterator for the set of prepared statements for this
    // connection
    protected final Iterator<TimesTenPooledPreparedStatement> 
	            getPreparedStmtIterator()
    {
	return pStmt.values().iterator();
    }

    // Returns an iterator for the set of callable statements for this
    // connection
    protected final Iterator<TimesTenPooledCallableStatement> 
	            getCallableStmtIterator()
    {
	return cStmt.values().iterator();
    }

    // Returns an iterator for the set of statements for this
    // connection
    protected final Iterator<TimesTenPooledStatement> 
	            getStmtIterator()
    {
	return sStmt.values().iterator();
    }

    // Sets/clears 'in use' (checked out from the pool) flag for the connection
    protected final void setInUse(boolean inuse)
    {
        lockConn();
	this.inUse = inuse;
	unlockConn();
    }

    // Returns the 'in use' flag for this connection
    protected final boolean inUse()
    {
	return this.inUse;
    }

    // Sets/clears the 'in transaction' flag for this connection
    protected final void setInTxn(boolean intxn)
    {
	lockConn();
	this.inTxn = intxn;
	unlockConn();
    }

    // Returns the 'in transaction' flag for this connection
    protected final boolean inTxn()
    {
	return this.inTxn;
    }

    // Sets/clears the 'is defunct' flag for this connection
    // and for all statemenst associated with the connection.
    protected final void setIsDefunct(boolean isdefunct)
    {
	Iterator<TimesTenPooledPreparedStatement> pstmtit;
	Iterator<TimesTenPooledCallableStatement> cstmtit;
	Iterator<TimesTenPooledStatement> stmtit;

	this.isDefunct = isdefunct;
	if (  this.isDefunct  )
	{
            pstmtit = this.pStmt.values().iterator();
	    while (  pstmtit.hasNext()  )
		pstmtit.next().setIsDefunct(isdefunct);
            cstmtit = this.cStmt.values().iterator();
	    while (  cstmtit.hasNext()  )
		cstmtit.next().setIsDefunct(isdefunct);
            stmtit = this.sStmt.values().iterator();
	    while (  stmtit.hasNext()  )
		stmtit.next().setIsDefunct(isdefunct);
	}
    }

    // Returns the 'is defunct' flag for this connection
    protected final boolean isDefunct()
    {
	return this.isDefunct;
    }

    // Sets the ID value for this connection (used by connection pool manager)
    protected final void setID(Integer id)
    {
	lockConn();
	this.ID = id;
	unlockConn();
    }

    // Returns the ID value for this connection
    protected final Integer getID()
    {
	return this.ID;
    }

    // Closes the connection and releases resources (e.g. prepared statements)
    protected final void realClose() 
	    throws SQLException
    {
	SQLException s = null;

	lockConn();
	try {
	    if (  this.isOpen  )
	    {
                if (  pStmt != null  )
	        {
	            Iterator<TimesTenPooledPreparedStatement> stmtit =
                        this.pStmt.values().iterator();
	            while (  stmtit.hasNext()  )
	            {
		        try {
		            stmtit.next().realClose();
		        } catch ( SQLException e ) {
			    if (  s == null  )
			        s = e;
			    else
			    {
			        e.setNextException(s);
			        s = e;
			    }
		        }
	                stmtit.remove();
	            }
	            this.pStmt = null;
	        }
                if (  cStmt != null  )
	        {
	            Iterator<TimesTenPooledCallableStatement> stmtit =
                        this.cStmt.values().iterator();
	            while (  stmtit.hasNext()  )
	            {
		        try {
		            stmtit.next().realClose();
		        } catch ( SQLException e ) {
			    if (  s == null  )
			        s = e;
			    else
			    {
			        e.setNextException(s);
			        s = e;
			    }
		        }
	                stmtit.remove();
	            }
	            this.cStmt = null;
	        }
                if (  sStmt != null  )
	        {
	            Iterator<TimesTenPooledStatement> stmtit =
                        this.sStmt.values().iterator();
	            while (  stmtit.hasNext()  )
	            {
		        try {
		            stmtit.next().realClose();
		        } catch ( SQLException e ) {
			    if (  s == null  )
			        s = e;
			    else
			    {
			        e.setNextException(s);
			        s = e;
			    }
		        }
	                stmtit.remove();
	            }
	            this.sStmt = null;
	        }
	        try {
		    if (  !this.isDefunct  )
	                this.conn.close();
	        } catch ( SQLException e ) {
		    if (  s == null  )
		        s = e;
		    else
		    {
		        e.setNextException(s);
		        s = e;
		    }
	        }
	        this.conn = null;
	        this.isOpen = false;
	        this.inUse = false;
	        this.inTxn = false;
	    }
        } finally {
	    unlockConn();
	    if (  s != null  )
	        throw s;
	}
    }

    // Controls AutoCommit mode
    protected final void setAutoCommitPool(boolean enable) 
	    throws SQLException
    {
	checkDefunct("setAutoCommitPool");

	this.conn.setAutoCommit(enable);
    }

    // Prepares a statement on the underlying native connection
    protected final TimesTenPreparedStatement nativePrepare(String sql) 
	    throws SQLException
    {
	checkDefunct("nativePrepare");

	return (TimesTenPreparedStatement)this.conn.prepareStatement(sql);
    }

    // Prepares a callable statement on the underlying native connection
    protected final TimesTenCallableStatement nativePrepareCall(String sql) 
	    throws SQLException
    {
	checkDefunct("nativePrepareCall");

	return (TimesTenCallableStatement)this.conn.prepareCall(sql);
    }

    // Prepares a statement and adds it to the set of prepared statements for
    // this connection
    protected final void createPreparedStmt(String label, String sql) 
	    throws SQLException
    {
	this.createPreparedStmt(label,sql,null);
    }

    // Prepares a statement, allowing optional optimiser hints,  and adds 
    // it to the set of prepared statements for this connection
    protected final void createPreparedStmt(String label, String sql, 
		                            String[] opthints)
	    throws SQLException
    {
	checkDefunct("createPreparedStmt");

	lockConn();
	try {
	    TimesTenPooledPreparedStatement stmt = getPreparedStmt(label);

            if (  stmt != null  )
	        stmt.realClose();	
	    stmt = new TimesTenPooledPreparedStatement(pool, this, label, 
			                             sql, opthints);
	    this.pStmt.put(label,stmt);
	} finally {
	    unlockConn();
	}
    }

    // Prepares a callable statement and adds it to the set of prepared callable
    // statements for this connection
    protected final void createCallableStmt(String label, String sql)
	    throws SQLException
    {
	checkDefunct("createCallableStmt");

	lockConn();
	try {
	    TimesTenPooledCallableStatement stmt = getCallableStmt(label);

            if (  stmt != null  )
	        stmt.realClose();	
	    stmt = new TimesTenPooledCallableStatement(pool, this, label, sql);
	    this.cStmt.put(label,stmt);
	} finally {
	    unlockConn();
	}
    }
    // Creates a statement and adds it to the set of statements for this 
    // connection
    protected final void createStmt(String label)
	    throws SQLException
    {
	checkDefunct("createStmt");

	lockConn();
	try {
	    TimesTenPooledStatement stmt = getStmt(label);

            if (  stmt != null  )
	        stmt.realClose();	
	    stmt = new TimesTenPooledStatement(pool, this, label);
	    this.sStmt.put(label,stmt);
	} finally {
	    unlockConn();
	}
    }

    // Closes a prepared statement and removes it from this connection's
    // set.
    protected final void closePreparedStmt(String label) 
	    throws SQLException
    {
	checkDefunct("closePreparedStmt");

	lockConn();
	try {
	    TimesTenPooledPreparedStatement stmt = getPreparedStmt(label);

	    if (  stmt != null  )
	    {
	        this.pStmt.remove(label);
	        stmt.realClose();
	    }
	} finally {
	    unlockConn();
	}
    }

    // Closes a callable statement and removes it from this connection's
    // set.
    protected final void closeCallableStmt(String label) 
	    throws SQLException
    {
	checkDefunct("closeCallableStmt");

	lockConn();
	try {
	    TimesTenPooledCallableStatement stmt = getCallableStmt(label);

	    if (  stmt != null  )
	    {
	        this.cStmt.remove(label);
	        stmt.realClose();
	    }
	} finally {
	    unlockConn();
	}
    }

    // Closes a statement and removes it from this connections
    // set.
    protected final void closeStmt(String label) 
	    throws SQLException
    {
	checkDefunct("closeStmt");

	lockConn();
	try {
	    TimesTenPooledStatement stmt = getStmt(label);

	    if (  stmt != null  )
	    {
	        this.sStmt.remove(label);
	        stmt.realClose();
	    }
	} finally {
	    unlockConn();
	}
    }

    //////////////// PUBLIC OVERRIDDEN METHODS /////////////////

    // These methods all have some degree of implementation that is 
    // specific to this class.

    /**
     * Returns this connection to the connection pool.
     * This is the same as calling the releaseConnection() method in 
     * the owning TimesTenConnectionPool object, passing it this 
     * connection.
     *
     * @exception   SQLException
     */
    public void close()
	    throws SQLException
    {
	    this.pool.releaseConnection(this);
    }

    /**
     * Adds failover event listener.
     * Throws a SQLException if called since failover is managed at 
     * the connection pool level.
     *
     * @param       listener   Event listener.
     *
     * @exception   SQLException
     */
    public final void addConnectionEventListener(ClientFailoverEventListener
		                                 listener)
	    throws SQLException
    {
	throw new SQLException(
	        className + ":addConnectionEventListener: not allowed",
		TimesTenConnectionPool.TTCP_SQLSTATE,
		TimesTenConnectionPool.TTCP_ERR_NOT_ALLOWED);
    }

    /**
     * Removes a failover event listener.
     * Throws a SQLException if called since failover is managed at 
     * the connection pool level.
     *
     * @param       listener   Event listener.
     *
     * @exception   SQLException
     */
    public final void removeConnectionEventListener(ClientFailoverEventListener
		                                    listener)
	    throws SQLException
    {
	throw new SQLException(
	        className + ":removeConnectionEventListener: not allowed",
		TimesTenConnectionPool.TTCP_SQLSTATE,
		TimesTenConnectionPool.TTCP_ERR_NOT_ALLOWED);
    }

    /**
     * Sets AutoCommit mode on or off.
     * Throws a SQLException if you try and enable AutoCommit since
     * pooled connections must always be in non-autocommit mode.
     *
     * @param       enable Turn autocommit on or off.
     *
     * @exception   SQLException
     */
    public final void setAutoCommit(boolean enable) 
	    throws SQLException
    {
	if (  enable  )
	    throw new SQLException(
		className + ":setAutoCommit(true): not allowed",
		TimesTenConnectionPool.TTCP_SQLSTATE,
		TimesTenConnectionPool.TTCP_ERR_NOT_ALLOWED);
    }

    /**
     * Tests if this database connection is open and usable.
     * It is recommended to use this method, rather than isDataStoreValid()
     * to test if the databse is available and accessible.
     *
     * @param     timeout   This is currently ignored.
     *
     * @return    True if connection is open and usable, false otherwise.
     *
     * @exception SQLException
     *
     * @see       #isDataStoreValid
     */
    public final boolean isValid(int timeout) 
	    throws SQLException
    {
	return !this.isDefunct && this.isOpen && this.conn.isDataStoreValid();
    }

    /**
     * Tests if this database connection is closed.
     *
     * @return    True if connection is closed.
     *
     * @exception SQLException
     */
    public final boolean isClosed()
    {
	return !this.isOpen;
    }

    /**
     * See java.sql.Connection.getMetaData()
     */
    public final DatabaseMetaData getMetaData() 
	    throws SQLException
    {
	checkDefunct("getMetaData");

	lockConn();
	this.inTxn = true;
	unlockConn();
        return this.conn.getMetaData();
    }

    /**
     * See java.sql.Connection.createStatement().
     * Not supported on a pooled connection, throws a SQLException if called. 
     * Use the addStatement() method in the owning TimesTenConnectionPool object
     * instead.
     */
    public final Statement createStatement() 
	    throws SQLException
    {
	throw new SQLException(
		className + ":createStatement: not allowed",
		TimesTenConnectionPool.TTCP_SQLSTATE,
		TimesTenConnectionPool.TTCP_ERR_NOT_ALLOWED);
    }

    /**
     * See java.sql.Connection.createStatement().
     * Not supported on a pooled connection, throws a SQLException if called.
     * Use the addStatement() method in the owning TimesTenConnectionPool object
     * instead.
     */
    public final Statement createStatement(int resultSetType,
		                           int resultSetConcurrency)
	    throws SQLException
    {
        return this.createStatement();
    }

    /**
     * See java.sql.Connection.createStatement().
     * Not supported on a pooled connection, throws a SQLException if called.
     * Use the addStatement() method in the owning TimesTenConnectionPool object
     * instead.
     */
    public final Statement createStatement(int resultSetType,
		                           int resultSetConcurrency,
					   int resultSetHoldability) 
	    throws SQLException
    {
        return this.createStatement();
    }

    /**
     * See java.sql.Connection.prepareStatement().
     * Not supported on a pooled connection, throws a SQLException if called.
     * All statement preparation must be performed via the addPreparedStatement()
     * method in the owning TimesTenConnectionPool object.
     */
    public final TimesTenPreparedStatement prepareStatement(String sql)
	    throws SQLException
    {
	throw new SQLException(
		className + ":prepareStatement: not allowed",
		TimesTenConnectionPool.TTCP_SQLSTATE,
		TimesTenConnectionPool.TTCP_ERR_NOT_ALLOWED);
    }

    /**
     * See java.sql.Connection.prepareStatement().
     * Not supported on a pooled connection, throws a SQLException if called.
     * All statement preparation must be performed via the addPreparedStatement()
     * method in the owning TimesTenConnectionPool object.
     */
    public final TimesTenPreparedStatement prepareStatement(String sql,
		                                    int resultSetType,
						    int resultSetConcurrency)
	    throws SQLException
    {
	return this.prepareStatement(sql);
    }

    /**
     * See java.sql.Connection.prepareStatement().
     * Not supported on a pooled connection, throws a SQLException if called.
     * All statement preparation must be performed via the 
     * addPreparedStatement() method in the owning TimesTenConnectionPool 
     * object.
     */
    public final PreparedStatement prepareStatement(String sql,
		                                    int resultSetType,
						    int resultSetConcurrency,
						    int resultSetHoldability)
	    throws SQLException
    {
	return this.prepareStatement(sql);
    }

    /**
     * See java.sql.Connection.prepareStatement().
     * Not supported on a pooled connection, throws a SQLException if called.
     * All statement preparation must be performed via the 
     * addPreparedStatement() method in the owning TimesTenConnectionPool 
     * object.
     */
    public final PreparedStatement prepareStatement(String sql,
						    int autoGeneratedKeys)
	    throws SQLException
    {
	return this.prepareStatement(sql);
    }

    /**
     * See java.sql.Connection.prepareStatement().
     * Not supported on a pooled connection, throws a SQLException if called.
     * All statement preparation must be performed via the 
     * addPreparedStatement() method in the owning TimesTenConnectionPool 
     * object.
     */
    public final PreparedStatement prepareStatement(String sql,
						    int[] columnIndexes)
	    throws SQLException
    {
	return this.prepareStatement(sql);
    }

    /**
     * See java.sql.Connection.prepareStatement().
     * Not supported on a pooled connection, throws a SQLException if called.
     * All statement preparation must be performed via the 
     * addPreparedStatement() method in the owning TimesTenConnectionPool 
     * object.
     */
    public final PreparedStatement prepareStatement(String sql,
						    String[] columnNames)
	    throws SQLException
    {
	return this.prepareStatement(sql);
    }

    /**
     * See java.sql.Connection.prepareCall().
     * Not supported on a pooled connection, throws a SQLException if called.
     * Use the addCallableStatement() method in the owning TimesTenConnectionPool 
     * object.
     */
    public final CallableStatement prepareCall(String sql)
	    throws SQLException
    {
	throw new SQLException(
		className + ":prepareCall: not allowed",
		TimesTenConnectionPool.TTCP_SQLSTATE,
		TimesTenConnectionPool.TTCP_ERR_NOT_ALLOWED);
    }

    /**
     * See java.sql.Connection.prepareCall().
     * Not supported on a pooled connection, throws a SQLException if called.
     * Use the addCallableStatement() method in the owning TimesTenConnectionPool 
     * object.
     */
    public final CallableStatement prepareCall(String sql,
		                               int resultSetType,
					       int resultSetConcurrency)
	    throws SQLException
    {
	return this.prepareCall(sql);
    }

    /**
     * See java.sql.Connection.prepareCall().
     * Not supported on a pooled connection, throws a SQLException if called.
     * Use the addCallableStatement() method in the owning TimesTenConnectionPool 
     * object.
     */
    public final CallableStatement prepareCall(String sql,
		                               int resultSetType,
					       int resultSetConcurrency,
					       int resultSetHoldability)
	    throws SQLException
    {
	return this.prepareCall(sql);
    }

    /**
     * See java.sql.Connection.rollback().
     * Allowed even on a 'defunct' connection.
     */
    public final void rollback() 
	    throws SQLException
    {
	lockConn();
	try {
	    this.conn.rollback();
	} finally {
	    this.inTxn = false;
	    unlockConn();
        }
    }

    /**
     * See java.sql.Connection.commit().
     */
    public final void commit() 
	    throws SQLException
    {
	checkDefunct("commit");

	lockConn();
	try {
	    this.conn.commit();
	} finally {
	    this.inTxn = false;
	    unlockConn();
        }
    }

    /**
     * See java.sql.Connection.getAutoCommit().
     */
    public final boolean getAutoCommit() 
	    throws SQLException
    {
	checkDefunct("getAutoCommit");

	return false;
    }

    //////////////// PUBLIC METHODS /////////////////

    // Methods special to this class
    
    /**
     * Returns the prepared statement corresponding to a label.
     * Used by applications to access the prepared statements associated
     * with a connection that they have obtained from the connection pool.
     * If no statement with the specified label exists, returns null.
     *
     * @param   label   Label value identifying the statement to be retrieved.
     *
     * @return  A TimesTenPooledPreparedStatement object which can be used to
     *          execute the associated SQL operation. If the label value
     *          is not found, returns null.
     */
    public final TimesTenPooledPreparedStatement getPreparedStmt(String label)
	    throws SQLException
    {
	checkDefunct("getPreparedStmt");

	return this.pStmt.get(label);
    }

    /**
     * Returns the callable statement corresponding to a label.
     * Used by applications to access the callable statements associated
     * with a connection that they have obtained from the connection pool.
     * If no statement with the specified label exists, returns null.
     *
     * @param   label   Label value identifying the statement to be retrieved.
     *
     * @return  A TimesTenPooledCallableStatement object which can be used to
     *          execute the associated SQL operation. If the label value
     *          is not found, returns null.
     */
    public final TimesTenPooledCallableStatement getCallableStmt(String label)
	    throws SQLException
    {
	checkDefunct("getCallableStmt");

	return this.cStmt.get(label);
    }

    /**
     * Returns the statement corresponding to a label.
     * Used by applications to access the statements associated
     * with a connection that they have obtained from the connection pool.
     * If no statement with the specified label exists, returns null.
     *
     * @param   label   Label value identifying the statement to be retrieved.
     *
     * @return  A TimesTenPooledStatement object which can be used to
     *          execute SQL operations. If the label value is not
     *          found, returns null.
     */
    public final TimesTenPooledStatement getStmt(String label)
	    throws SQLException
    {
	checkDefunct("getStmt");

	return this.sStmt.get(label);
    }

    // Methods from regular (TimesTen)Connection class
    // These methods pretty much just call the corresponding method in 
    // the underlying TimesTenConnection object.

    /**
     * See java.sql.Connection.createClob()
     */
    public final Clob createClob()
	    throws SQLException
    {
	checkDefunct("createClob");

	return this.conn.createClob();
    }

    /**
     * See java.sql.Connection.createBlob()
     */
    public final Blob createBlob()
	    throws SQLException
    {
	checkDefunct("createBlob");

	return this.conn.createBlob();
    }

    /**
     * See java.sql.Connection.createNClob()
     */
    public final NClob createNClob()
	    throws SQLException
    {
	checkDefunct("createNClob");

	return this.conn.createNClob();
    }

    /**
     * See java.sql.Connection.createSQLXML()
     */
    public final SQLXML createSQLXML()
	    throws SQLException
    {
	checkDefunct("createSQLXML");

	return this.conn.createSQLXML();
    }

    /**
     * See java.sql.Connection.createStruct()
     */
    public final Struct createStruct(String typeName,
		                     Object[] attributes)
	    throws SQLException
    {
	checkDefunct("createStruct");

	return this.conn.createStruct(typeName, attributes);
    }

    /**
     * See java.sql.Connection.createArrayOf()
     */
    public final Array createArrayOf(String typeName,
		                   Object[] elements)
	    throws SQLException
    {
	checkDefunct("createArrayOf");

        return this.conn.createArrayOf(typeName, elements);
    }

    /**
     * See java.sql.Connection.nativeSQL()
     */
    public final String nativeSQL(String sql)
	    throws SQLException
    {
	checkDefunct("nativeSQL");

	return this.conn.nativeSQL(sql);
    }

    /**
     * See java.sql.Connection.setReadOnly()
     */
    public final void setReadOnly(boolean readonly)
	    throws SQLException
    {
	checkDefunct("setReadOnly");

        this.conn.setReadOnly(readonly);
    }

    /**
     * See java.sql.Connection.isReadOnly()
     */
    public final boolean isReadOnly()
	    throws SQLException
    {
	checkDefunct("isReadOnly");

	return this.conn.isReadOnly();
    }

    /**
     * See java.sql.Connection.setCatalog()
     */
    public final void setCatalog(String catalog)
	    throws SQLException
    {
	checkDefunct("setCatalog");

	this.conn.setCatalog(catalog);
    }

    /**
     * See java.sql.Connection.getCatalog()
     */
    public final String getCatalog()
	    throws SQLException
    {
	checkDefunct("getCatalog");

	return this.conn.getCatalog();
    }

    /**
     * See java.sql.Connection.setHoldability()
     */
    public final void setHoldability(int holdability)
	    throws SQLException
    {
	checkDefunct("setHoldability");

	this.conn.setHoldability(holdability);
    }

    /**
     * See java.sql.Connection.getHoldability()
     */
    public final int getHoldability()
	    throws SQLException
    {
	checkDefunct("getHoldability");

	return this.conn.getHoldability();
    }

    /**
     * See java.sql.Connection.setSavepoint()
     */
    public final Savepoint setSavepoint()
	    throws SQLException
    {
	checkDefunct("setSavepoint");

	return this.conn.setSavepoint();
    }

    /**
     * See java.sql.Connection.setSavepoint()
     */
    public final Savepoint setSavepoint(String name)
	    throws SQLException
    {
	checkDefunct("setSavepoint");

	return this.conn.setSavepoint(name);
    }

    /**
     * See java.sql.Connection.rollback()
     */
    public void rollback(Savepoint savepoint)
	    throws SQLException
    {
	checkDefunct("setSavepoint");

	this.conn.rollback(savepoint);
    }

    /**
     * See java.sql.Connection.releaseSavepoint()
     */
    public void releaseSavepoint(Savepoint savepoint)
	    throws SQLException
    {
	checkDefunct("releaseSavepoint");

	this.conn.releaseSavepoint(savepoint);
    }

    /**
     * See java.sql.Connection.getClientInfo()
     */
    public final Properties getClientInfo()
	    throws SQLException
    {
	checkDefunct("getClientInfo");

	return this.conn.getClientInfo();
    }

    /**
     * See java.sql.Connection.getTypeMap()
     */
    public final Map<String,Class<?>> getTypeMap()
	    throws SQLException
    {
	checkDefunct("getTypeMap");

	return this.conn.getTypeMap();
    }

    /**
     * See java.sql.Connection.setTypeMap()
     */
    public final void setTypeMap(Map<String,Class<?>> map)
	    throws SQLException
    {
	checkDefunct("setTypeMap");

	this.conn.setTypeMap(map);
    }

    /**
     * See java.sql.Connection.getClientInfo()
     */
    public final String getClientInfo(String name)
	    throws SQLException
    {
	checkDefunct("getClientInfo");

	return this.conn.getClientInfo(name);
    }

    /**
     * See java.sql.Connection.setClientInfo()
     */
    public final void setClientInfo(String name, String value)
	    throws SQLClientInfoException
    {
	if (  !this.isDefunct  )
	    this.conn.setClientInfo(name, value);
    }

    /**
     * See java.sql.Connection.setClientInfo()
     */
    public final void setClientInfo(Properties properties)
	    throws SQLClientInfoException
    {
	if (  !this.isDefunct  )
	    this.conn.setClientInfo(properties);
    }

    /**
     * See com.timesten.jdbc.TimesTenConnection.isDataStoreValid().
     * It is recommended to use the isValid() method to test if the datastore
     * is available and accessible.
     */
    public final boolean isDataStoreValid()
	    throws SQLException
    {
	checkDefunct("isDataStorevalid");

	return this.conn.isDataStoreValid();
    }
   
    /**
     * See java.sql.Connection.getWarnings()
     */
    public final SQLWarning getWarnings() 
	    throws SQLException
    {
	checkDefunct("getWarnings");

	return this.conn.getWarnings();
    }

    /**
     * See java.sql.Connection.clearWarnings()
     */
    public final void clearWarnings() 
	    throws SQLException
    {
	checkDefunct("clearWarnings");

	this.conn.clearWarnings();
    }

    /**
     * See java.sql.Connection.getTransactionIsolation()
     */
    public final int getTransactionIsolation() 
	    throws SQLException
    {
	checkDefunct("getTransactionIsolation");

	return this.conn.getTransactionIsolation();
    }

    /**
     * See java.sql.Connection.setTransactionIsolation()
     */
    public final void setTransactionIsolation(int level) 
	    throws SQLException
    {
	checkDefunct("setTransactionIsolation");

	this.conn.setTransactionIsolation(level);
    }

    /**
     * See com.timesten.jdbc.TimesTenConnection.setTtPrefetchCount()
     */
    public final void setTtPrefetchCount(int count) 
	    throws SQLException
    {
	checkDefunct("setTtPrefetchCount");

	this.conn.setTtPrefetchCount(count);
    }

    /**
     * See com.timesten.jdbc.TimesTenConnection.setTtPrefetchClose()
     */
    public final void setTtPrefetchClose(boolean enable) 
	    throws SQLException
    {
	checkDefunct("setTtPrefetchClose");

	this.conn.setTtPrefetchClose(enable);
    }

    /**
     * See com.timesten.jdbc.TimesTenConnection.getTtPrefetchClose()
     */
    public final boolean getTtPrefetchClose() 
	    throws SQLException
    {
	checkDefunct("getTtPrefetchClose");

	return this.conn.getTtPrefetchClose();
    }

    /**
     * See com.timesten.jdbc.TimesTenConnection.getTtPrefetchCount()
     */
    public final int getTtPrefetchCount() 
	    throws SQLException
    {
	checkDefunct("getTtPrefetchCount");

	return this.conn.getTtPrefetchCount();
    }

    // Methods from Wrapper

    public final boolean isWrapperFor(Class<?> iface) 
	    throws SQLException
    {
	return this.conn.isWrapperFor(iface);
    }

    public final <T> T unwrap(Class <T> iface) 
	    throws SQLException
    {
	return this.conn.unwrap(iface);
    }

	@Override
	public void setSchema(String schema) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getSchema() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void abort(Executor executor) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setNetworkTimeout(Executor executor, int milliseconds)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getNetworkTimeout() throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public TimesTenBlob createBLOB() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TimesTenClob createCLOB() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getReplicationTrack() throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setReplicationTrack(int arg0) throws SQLException {
		// TODO Auto-generated method stub
		
	}
}

