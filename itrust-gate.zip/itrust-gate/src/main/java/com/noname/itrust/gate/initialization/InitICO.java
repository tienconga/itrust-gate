package com.noname.itrust.gate.initialization;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.sql.SQLStatement;

@Service
public class InitICO {

	/**
	 * init ICO orders
	 */
	public void initICO(){
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
	        ps = conn.prepareStatement(ConnectionManager.sqlMap.get(SQLStatement.KEY_SEL_ICO));
	        rs = ps.executeQuery();
		   
	        while(rs.next()){
	        	String quoteid = rs.getString("QUOTEID");
	        	String acctno = rs.getString("ACCTNO");
	        	String symbol = rs.getString("SYMBOL");
	        	Long qtty = rs.getLong("QTTY");
	        	String side = rs.getString("SIDE");
	        	BigDecimal price = rs.getBigDecimal("PRICE");
	        	String status = rs.getString("STATUS");
	        	String userid = rs.getString("USERID");
	        	String typecd = rs.getString("TYPECD");
	        	
	        	Quote icoOrder = new Quote();
	        	icoOrder.setQuoteid(quoteid);
	        	icoOrder.setAcctno(acctno);
	        	icoOrder.setSymbol(symbol);
	        	icoOrder.setQtty(qtty);
	        	icoOrder.setSide(side);
	        	icoOrder.setPrice(price);
	        	icoOrder.setStatus(status);
	        	icoOrder.setUserid(userid);
	        	icoOrder.setTypecd(typecd);
	        	
	        	icoOrder.setClasscd("ICO");
	        	
	        	Map<String, Quote> orderInfos = HandlerCacheData.icoMap.get(symbol);
				if(orderInfos == null){//chua co ma chung khoan nay trong he thong
					orderInfos = new HashMap<String, Quote>();
					orderInfos.put(quoteid, icoOrder);
					HandlerCacheData.icoMap.put(symbol, orderInfos);
				}else{//da ton tai ma chung khoan nay
					orderInfos.put(quoteid, icoOrder);
				}
	
				//TODO: init f(0)
				
	        }
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}
	}
}
