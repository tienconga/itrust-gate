package com.noname.itrust.gate.rules;

import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

import com.fss.newfo.common.model.MarketInfo;
import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.CacheProcessing;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.common.CommonConstants;
import com.noname.itrust.gate.data.dao.DAOCommon;
import com.noname.itrust.gate.model.ISignal;
import com.noname.itrust.gate.sending.CancelOrderSending;
import com.noname.itrust.gate.thread.TicketQueue;

public class PCORule implements IRules {

	private LinkedBlockingQueue<Quote> queue;
	
	@Override
	public void process(ISignal market,Quote quote) {
		String symbol = quote.getSymbol();
		String exchange = CacheProcessing.InstrumentMap.get(symbol).getBoard();
		
		if(exchange != null && exchange.equalsIgnoreCase("HSX")){
			if(HandlerCacheData.hsxSession.equalsIgnoreCase("BOPN") || 
					HandlerCacheData.hsxSession.equalsIgnoreCase("OPN") || 
					HandlerCacheData.hsxSession.equalsIgnoreCase("CNT") ||
					HandlerCacheData.hsxSession.equalsIgnoreCase("LB") ||//nghi trua
					HandlerCacheData.hsxSession.equalsIgnoreCase("CLS")){
				activeOrder(quote);
			}else{//cross, end
				//not acctive order
			}
		}else if(exchange != null && exchange.equalsIgnoreCase("HNX")){
			if(HandlerCacheData.hnxSession.equalsIgnoreCase("BCNT") || 
					HandlerCacheData.hnxSession.equalsIgnoreCase("CNT") ||
					HandlerCacheData.hnxSession.equalsIgnoreCase("CLS") ||
					HandlerCacheData.hnxSession.equalsIgnoreCase("L5M")){
				activeOrder(quote);
			}else{//cross, end
				//not acctive order
			}
		}else if(exchange != null && exchange.equalsIgnoreCase("UPCOM")){
			if(HandlerCacheData.upcomSession.equalsIgnoreCase("BCNT") || HandlerCacheData.upcomSession.equalsIgnoreCase("CNT")){
				activeOrder(quote);
			}
		}
	}

	@Override
	public void putRequest(Quote quote) {
		// TODO Auto-generated method stub

	}

	@Override
	public void load() {
		// TODO Auto-generated method stub

	}
	
	private void activeOrder(Quote quote){
		//kich hoat lenh
		SLF4JLoggerProxy.info(this,"Active PCO Order========quoteid:" + quote.getQuoteid());
		try {
			TicketQueue queThread = TicketQueue.getTicketQueueThread();
			queue = queThread.getTicketqueue();
			queue.put(quote);
		} catch (InterruptedException e) {
			SLF4JLoggerProxy.error(this, "Error when active PCO Order========quoteid:" + quote.getQuoteid() + "," + e);
		}
		
		//xoa khoi orders list
		Map<String,Quote> tsoOrders = HandlerCacheData.pcoMap.get(quote.getSymbol());
		tsoOrders.remove(quote.getQuoteid());
		
		//syn to DB
		DAOCommon obj = new DAOCommon();
		obj.updateStatus(quote.getQuoteid(), CommonConstants.ORDER_STATUS_ACTIVING,"PCO");		
	}
		
	public void processSession(MarketInfo marketinfo) throws CloneNotSupportedException {
		String session = marketinfo.getSessionex();
		String exchangeCode = marketinfo.getExchange();
		
		SLF4JLoggerProxy.info(this, "Current session=========================:HSX:" + HandlerCacheData.hsxSession
				+ ",HNX:" + HandlerCacheData.hsxSession + ", UPCOM:" + HandlerCacheData.upcomSession);
		SLF4JLoggerProxy.info(this, "New session=========================:" + session + ",exchangeCode:" + exchangeCode);
		if(session != null && exchangeCode != null && exchangeCode.equals("HSX") && session.equals("OPN")){
			SLF4JLoggerProxy.info(this, "session:" + session + ",exchangeCode:" + exchangeCode);
			//manual by SIMULATOR
			String oldSession = HandlerCacheData.hsxSession;
			if(oldSession.equalsIgnoreCase(session)){
				return;
			}
			
			HandlerCacheData.hsxSession = session;
			
			SORule rule = new SORule();
			rule.orderSession();
			
		}else if(session != null && exchangeCode != null && exchangeCode.equals("HSX") && session.equals("CNT")){
			SLF4JLoggerProxy.info(this, "session:" + session + ",exchangeCode:" + exchangeCode);
			
			//manual by SIMULATOR
			String oldSession = HandlerCacheData.hsxSession;
			if(oldSession.equalsIgnoreCase(session)){
				return;
			}
			HandlerCacheData.hsxSession = session;
			//Lay cac lenh CPO cua phien ATO khop khong het, classcd = PCO.DL
			//Day len so voi gia TRAN(Mua), gia SAN(Ban), Qtty = phan chua khop 
			
			//ICORule
			ICORule rule = new ICORule();
			rule.orderSession(exchangeCode, session);
			
			//OCO
			OCORule ocoRule = new OCORule();
			ocoRule.orderSession(session);
			
			//SO
			SORule sorule = new SORule();
			sorule.orderSession();
		}else if(session != null && exchangeCode != null && exchangeCode.equals("HSX") && session.equals("CLS")){
			SLF4JLoggerProxy.info(this, "session:" + session + ",exchangeCode:" + exchangeCode);
			
			//manual by SIMULATOR
			String oldSession = HandlerCacheData.hsxSession;
			if(oldSession.equalsIgnoreCase(session)){
				return;
			}
			
			HandlerCacheData.hsxSession = session;
			//Huy cac lenh CPO khong khop het cua phien CNT
			processATCSessionFlag();
			//Day len so voi gia ATC
		}else if(session != null && exchangeCode != null && exchangeCode.equals("HNX") && session.equals("CNT")){
			SLF4JLoggerProxy.info(this, "session:" + session + ",exchangeCode:" + exchangeCode);
			HandlerCacheData.hnxSession = session;
			//call store
			//Lay cac thong tin lenh dat truoc phien mo cua (substatus=NN)
			//Day len so voi gia ATO
			
			//ICORule
			ICORule rule = new ICORule();
			rule.orderSession(exchangeCode, session);
			
			//OCO
			OCORule ocoRule = new OCORule();
			ocoRule.orderSession(session);
			
			//SO
			SORule sorule = new SORule();
			sorule.orderSession();
			
		}else if(session != null && exchangeCode != null && exchangeCode.equals("HNX") && (session.equals("CLS") /* || session.equals("L5M")*/)){
			SLF4JLoggerProxy.info(this, "session:" + session + ",exchangeCode:" + exchangeCode);
			HandlerCacheData.hnxSession = session;
			processATCSessionFlag();
		}else if(session != null && exchangeCode != null && exchangeCode.equals("UPCOM") && session.equals("CNT")){
			SLF4JLoggerProxy.info(this, "session:" + session + ",exchangeCode:" + exchangeCode);
			HandlerCacheData.upcomSession = session;
			
			//ICORule
			ICORule rule = new ICORule();
			rule.orderSession(exchangeCode, session);
			
			//SO
			SORule sorule = new SORule();
			sorule.orderSession();
		}else if(session != null && exchangeCode != null){
			if(exchangeCode.equals("HSX")){
				//manual by SIMULATOR
				String oldSession = HandlerCacheData.hsxSession;
				if(oldSession.equalsIgnoreCase(session)){
					return;
				}
				
				HandlerCacheData.hsxSession = session;
			}else if(exchangeCode.equals("HNX")){
				HandlerCacheData.hnxSession = session;
			}else if(exchangeCode.equals("UPCOM")){
				HandlerCacheData.upcomSession = session;
			}
		}
	}
	
	public void generalNewOrder(String orderid, int qtty, String exchangecode) throws InterruptedException{
		Quote quote = DAOCommon.getOrderInfo(orderid);
		SLF4JLoggerProxy.info(this, "generalNewOrder qtty:" + qtty + ",quote.getQtty(): " + quote.getQtty());
		if(quote != null &&  qtty == quote.getQtty()){
			if(exchangecode.equalsIgnoreCase("HSX")){
				if(HandlerCacheData.hsxSession.equalsIgnoreCase("CNT")){
					quote.setTypecd("LO");
					quote.setSubtypecd("LO");
					if(quote.getSide().equals("B")){
						quote.setPrice(CacheProcessing.InstrumentMap.get(quote.getSymbol()).getPriceCE());
					}else if(quote.getSide().equals("S")){
						quote.setPrice(CacheProcessing.InstrumentMap.get(quote.getSymbol()).getPriceFL());
					}
				}else if(HandlerCacheData.hsxSession.equalsIgnoreCase("CLS")){
					quote.setTypecd("ATC");
					quote.setSubtypecd("ATC");
				}
			} else if(exchangecode.equalsIgnoreCase("HNX")){
				if(HandlerCacheData.hnxSession.equalsIgnoreCase("CLS") || HandlerCacheData.hnxSession.equalsIgnoreCase("L5M")){
					quote.setTypecd("ATC");
					quote.setSubtypecd("ATC");
				}
			}
			
			quote.setClasscd("PCO");
			//quote.setUserid("PCO");
			//active order
			activeOrder(quote);
		}else{//retry 1 lan
			//TODO turning by other process
			Thread.sleep(2000);
			SLF4JLoggerProxy.info(this, "(PCO)Retry get order:" + orderid);
			quote = DAOCommon.getOrderInfo(orderid);
			if(quote != null &&  qtty == quote.getQtty()){
				if(exchangecode.equalsIgnoreCase("HSX")){
					if(HandlerCacheData.hsxSession.equalsIgnoreCase("CNT")){
						quote.setTypecd("LO");
						quote.setSubtypecd("LO");
						if(quote.getSide().equals("B")){
							quote.setPrice(CacheProcessing.InstrumentMap.get(quote.getSymbol()).getPriceCE());
						}else if(quote.getSide().equals("S")){
							quote.setPrice(CacheProcessing.InstrumentMap.get(quote.getSymbol()).getPriceFL());
						}
					}else if(HandlerCacheData.hsxSession.equalsIgnoreCase("CLS")){
						quote.setTypecd("ATC");
						quote.setSubtypecd("ATC");
					}
				} else if(exchangecode.equalsIgnoreCase("HNX")){
					if(HandlerCacheData.hnxSession.equalsIgnoreCase("CLS") || HandlerCacheData.hnxSession.equalsIgnoreCase("L5M")){
						quote.setTypecd("ATC");
						quote.setSubtypecd("ATC");
					}
				}
				
				quote.setClasscd("PCO");
				//quote.setUserid("PCO");
				//active order
				activeOrder(quote);
			}
		}
	}
	
	private void processATCSessionFlag(){
		List<Quote> list = DAOCommon.getOrderList();
		if(list != null && list.size() > 0){
			for(int i = 0; i < list.size(); i++){
				Quote quote = list.get(i);
				CancelOrderSending cancelObj = new CancelOrderSending();
				cancelObj.cancelOrder(quote,"");
			}
		}
	}
}
