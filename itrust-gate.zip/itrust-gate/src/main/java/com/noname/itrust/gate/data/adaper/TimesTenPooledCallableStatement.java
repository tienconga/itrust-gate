package com.noname.itrust.gate.data.adaper;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Map;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;
import java.net.URL;
import java.sql.*;

import com.timesten.jdbc.*;

/**
 * Represents a TimesTen callable statement.
 *
 * This class should not be instantiated directly. Instances of this classs
 * are manipulated via methods in the associated TimesTenPooledConnection and
 * TimesTenConnectionPool classes.
 * <p><p>
 * This class implements the standard TimesTenCallableStatement interface, plus 
 * some additional methods.
 * <p><p>
 * Any methods which are not explicitly documented behave identically to
 * the corresponding method in TimesTenCallableStatement.
 * <p><p>
 * Any individual instance of this class should not be shared amongst multiple 
 * threads.
 * <p><p>
 * If the connection that owns this statement has been invalidated due to a 
 * failover most methods will throw a TTCP_ERR_STMT_INVALID exception.
 */
public final class TimesTenPooledCallableStatement 
	implements TimesTenCallableStatement
{
    ///////////////////// CONSTANTS //////////////////
    //
    // Classname
    private static final String className = "TimesTenPooledCallableStatement";

    ///////////////////// PRIVATE VARIABLES //////////////////

    // Lock for things that affect the connection
    private ReentrantLock stmtLock = null;   

    // The underlying prepared statement for this 
    // TimesTenPreparedStatement
    private TimesTenCallableStatement cStmt = null;

    // The 'label' for this statement
    private String stmtLabel = null;

    // The SQL statement that this represents
    private String sqlText = null;

    // The TimesTenPooledConnection that 'owns' this TimesTenPoolPreparedStatement
    private TimesTenPooledConnection stmtConn = null;

    // The TimesTenConnectionPool that ultimately 'owns' this TimesTenPoolPreparedStatement
    private TimesTenConnectionPool stmtPool = null;

    // Flags for state of statement
    private boolean isPrepared = false;

    // Is statement invalid due to failover
    private boolean isDefunct = false;

    ///////////////////// CONSTRUCTORS /////////////////////////
    
    // Create a prepared statement with the specified label on the given 
    // connection
    protected TimesTenPooledCallableStatement(
		                        TimesTenConnectionPool pool, 
		                        TimesTenPooledConnection conn, 
		                        String label, 
		                        String sql) 
	    throws SQLException
    {
	this.stmtConn = conn;
	this.stmtPool = pool;
	this.stmtLabel = label;
	this.sqlText = sql;
        stmtLock = new ReentrantLock(stmtPool.getLockingFairness());
	prepareSQL();
    }

    ////////////// FINALIZER /////////////

    protected void finalize()
	    throws Throwable
    {
        stmtLabel = null;
        sqlText = null;
        stmtConn = null;
        stmtPool = null;
	if (  this.cStmt != null  )
	    try {
	       cStmt.close();
	    } catch ( SQLException e ) {
		// ignore it
	    }
	super.finalize();
    }

    //////////////////// PRIVATE METHODS ///////////////////////
 
    // lock the statement
    private final void lockStmt()
    {
	this.stmtLock.lock();
    }

    // unlock the statement
    private final void unlockStmt()
    {
	this.stmtLock.unlock();
    }

    // Check if statement is locked
    private final boolean isStmtLocked()
    {
	return this.stmtLock.isLocked();
    }

    // Handle defunct statement
    private final void checkDefunct(String funcname)
	    throws SQLException
    {
	if (  this.isDefunct  )
	    throw new SQLException(
	        className + funcname + ":statement invalid due to failover",
		TimesTenConnectionPool.TTCP_SQLSTATE,
		TimesTenConnectionPool.TTCP_ERR_STMT_INVALID);
    }
    
    // Prepare a statement - only called from constructors
    private final void prepareSQL() 
	    throws SQLException
    {
	checkDefunct("prepareSQL");

	try {
	    this.cStmt = this.stmtConn.nativePrepareCall(this.sqlText);
	} finally {
	    this.stmtConn.commit();
	}
	this.isPrepared = true;
    }

    //////////////////// PROTECTED METHODS ///////////////////////
    
    // Close this prepared statement.
    protected final void realClose() 
	    throws SQLException
    {
	lockStmt();
	try {
	    if (  !this.isDefunct  )
	        try {
	            cStmt.close();
	        } finally {
	            this.isPrepared = false;
	        }
	} finally {
            unlockStmt();
        }
    }

    // Set the isDefunct flag
    protected final void setIsDefunct(boolean isdefunct)
    {
	this.isDefunct = isdefunct;
    }

    // Get the isDefunct flag
    protected final boolean isDefunct()
    {
	return this.isDefunct;
    }
 
    ////////////////// ADDITIONAL PUBLIC METHODS /////////////////////
    
    /**
     * Returns the textual label associated with this statement.
     * The label is defined when the statement is created. This
     * is done via the addCallableStatement() method in the
     * TimesTenPooledConnection class.
     */
    public final String getLabel()
    {
	return this.stmtLabel;
    }
    
    /**
     * Returns the SQL text for this prepared statement.
     * This can be useful for debugging or tracing.
     */
    public final String getSql()
    {
	return this.sqlText;
    }

    ////////////////// OVERRIDDEN METHODS //////////////////////////

    /**
     * Always returns false.
     * Statement pooling is not required and so is not supported.
     */
    public final boolean isPoolable() // from Statement
    {
	return false; // we don't support statement pooling (no need)
    }

    /**
     * Silently does nothing.
     * Statement pooling is not required and so is not supported.
     */
    public final void setPoolable(boolean poolable) // from Statement
    {
	// silently do nothing - we don't support statement pooling
    }

    /**
     * Returns the TimesTenPooledConnection (as a Connection) with
     * which this TimesTenPoolPreparedStatement is associated.
     */
    public final Connection getConnection() 
    {
	return this.stmtConn;
    }

    /**
     * Indicates if statement is 'closed'.
     * 'closed' means 'not prepared'.
     */
    public final boolean isClosed() 
    {
	return !this.isPrepared;
    }

    /**
     * Silently does nothing.
     * A TimesTenPoolPreparedStatement can only be closed by the owning
     * TimesTenPooledConnection object which in turn will only close
     * the statement when directed to by its owning TimestenConnectionPool
     * object, via the removeCallableStatement() method.
     */
    public final void close() 
    {
	// Silently do nothing.
	// Only the owning connection can close the statement
	// via the realClose() method.
    }
 
    ////////////////////////////////////////////////////////////////////////
    //               NOTHING INTERESTING BEYOND THIS POINT                //
    //                                                                    //
    // All the following methods pretty much just call the corresponding  //
    // method in the associated TimesTenPreparedStatement object.         //
    ////////////////////////////////////////////////////////////////////////

    // Methods from TimesTenCallableStatement
    
    /**
     * See com.timesten.jdbc.TimesTenCallableStatement.getCursor()
     */
    public final ResultSet getCursor(int parameterIndex)
	    throws SQLException
    {
	checkDefunct("getCursor");

	return cStmt.getCursor(parameterIndex);
    }

    /**
     * See com.timesten.jdbc.TimesTenCallableStatement.getCursor()
     */
    public final ResultSet getCursor(String parameterName)
	    throws SQLException
    {
	checkDefunct("getCursor");

	return cStmt.getCursor(parameterName);
    }
    
    /**
     * See com.timesten.jdbc.TimesTenCallableStatement.registerOutParameter()
     */
    public final void registerOutParameter(int paramIndex,
		                           int sqlType,
				           int ignore,
				           int maxLength)
	    throws SQLException
    {
	checkDefunct("registerOutParameter");

	cStmt.registerOutParameter(paramIndex, sqlType, ignore, maxLength);
    }
    
    // Methods from CallableStatement
    
    /**
     * See java.sql.CallableStatement.wasNull()
     */
    public final boolean wasNull()
	    throws SQLException
    {
	checkDefunct("wasNull");

	return cStmt.wasNull();
    }
    
    /**
     * See java.sql.CallableStatement.getRef()
     */
    public final Ref getRef(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getRef");

	return cStmt.getRef(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getRef()
     */
    public final Ref getRef(String paramName)
	    throws SQLException
    {
	checkDefunct("getRef");

	return cStmt.getRef(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getBoolean()
     */
    public final boolean getBoolean(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getBoolean");

	return cStmt.getBoolean(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getBoolean()
     */
    public final boolean getBoolean(String paramName)
	    throws SQLException
    {
	checkDefunct("getBoolean");

	return cStmt.getBoolean(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getByte()
     */
    public final byte getByte(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getByte");

	return cStmt.getByte(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getByte()
     */
    public final byte getByte(String paramName)
	    throws SQLException
    {
	checkDefunct("getByte");

	return cStmt.getByte(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getShort()
     */
    public final short getShort(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getShort");

	return cStmt.getShort(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getShort()
     */
    public final short getShort(String paramName)
	    throws SQLException
    {
	checkDefunct("getShort");

	return cStmt.getShort(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getInt()
     */
    public final int getInt(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getInt");

	return cStmt.getInt(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getInt()
     */
    public final int getInt(String paramName)
	    throws SQLException
    {
	checkDefunct("getInt");

	return cStmt.getInt(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getLong()
     */
    public final long getLong(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getLong");

	return cStmt.getLong(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getLong()
     */
    public final long getLong(String paramName)
	    throws SQLException
    {
	checkDefunct("getLong");

	return cStmt.getLong(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getFloat()
     */
    public final float getFloat(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getFloat");

	return cStmt.getFloat(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getFloat()
     */
    public final float getFloat(String paramName)
	    throws SQLException
    {
	checkDefunct("getFloat");

	return cStmt.getFloat(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getDouble()
     */
    public final double getDouble(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getDouble");

	return cStmt.getDouble(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getDouble()
     */
    public final double getDouble(String paramName)
	    throws SQLException
    {
	checkDefunct("getDouble");

	return cStmt.getDouble(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getBytes()
     */
    public final byte[] getBytes(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getBytes");

	return cStmt.getBytes(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getBytes()
     */
    public final byte[] getBytes(String paramName)
	    throws SQLException
    {
	checkDefunct("getBytes");

	return cStmt.getBytes(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getString()
     */
    public final String getString(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getString");

	return cStmt.getString(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getString()
     */
    public final String getString(String paramName)
	    throws SQLException
    {
	checkDefunct("getString");

	return cStmt.getString(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getArray()
     */
    public final Array getArray(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getArray");

	return cStmt.getArray(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getArray()
     */
    public final Array getArray(String paramName)
	    throws SQLException
    {
	checkDefunct("getArray");

	return cStmt.getArray(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getBlob()
     */
    public final Blob getBlob(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getBlob");

	return cStmt.getBlob(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getBlob()
     */
    public final Blob getBlob(String paramName)
	    throws SQLException
    {
	checkDefunct("getBlob");

	return cStmt.getBlob(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getClob()
     */
    public final Clob getClob(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getClob");

	return cStmt.getClob(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getClob()
     */
    public final Clob getClob(String paramName)
	    throws SQLException
    {
	checkDefunct("getClob");

	return cStmt.getClob(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getCharacterStream()
     */
    public final Reader getCharacterStream(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getCharacterStream");

	return cStmt.getCharacterStream(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getCharacterStream()
     */
    public final Reader getCharacterStream(String paramName)
	    throws SQLException
    {
	checkDefunct("getCharacterStream");

	return cStmt.getCharacterStream(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getNCharacterStream()
     */
    public final Reader getNCharacterStream(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getNCharacterStream");

	return cStmt.getNCharacterStream(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getNCharacterStream()
     */
    public final Reader getNCharacterStream(String paramName)
	    throws SQLException
    {
	checkDefunct("getNCharacterStream");

	return cStmt.getNCharacterStream(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getObject()
     */
    public final Object getObject(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getObject");

	return cStmt.getObject(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getObject()
     */
    public final Object getObject(int paramIndex, Map<String,Class<?>> map)
	    throws SQLException
    {
	checkDefunct("getObject");

	return cStmt.getObject(paramIndex, map);
    }
    
    /**
     * See java.sql.CallableStatement.getObject()
     */
    public final Object getObject(String paramName)
	    throws SQLException
    {
	checkDefunct("getObject");

	return cStmt.getObject(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getObject()
     */
    public final Object getObject(String paramName, Map<String,Class<?>> map)
	    throws SQLException
    {
	checkDefunct("getObject");

	return cStmt.getObject(paramName, map);
    }
    
    /**
     * See java.sql.CallableStatement.getBigDecimal()
     */
    public final BigDecimal getBigDecimal(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getBigDecimal");

	return cStmt.getBigDecimal(paramIndex);
    }
    
    // DEPRECATED
    /**
     * See java.sql.CallableStatement.getBigDecimal()
     */
    public final BigDecimal getBigDecimal(int paramIndex, int scale)
	    throws SQLException
    {
	checkDefunct("getBigDecimal");

	return cStmt.getBigDecimal(paramIndex, scale);
    }
    
    /**
     * See java.sql.CallableStatement.getBigDecimal()
     */
    public final BigDecimal getBigDecimal(String paramName)
	    throws SQLException
    {
	checkDefunct("getBigDecimal");

	return cStmt.getBigDecimal(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getDate()
     */
    public final Date getDate(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getDate");

	return cStmt.getDate(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getDate()
     */
    public final Date getDate(int paramIndex, Calendar cal)
	    throws SQLException
    {
	checkDefunct("getDate");

	return cStmt.getDate(paramIndex, cal);
    }
    
    /**
     * See java.sql.CallableStatement.getDate()
     */
    public final Date getDate(String paramName)
	    throws SQLException
    {
	checkDefunct("getDate");

	return cStmt.getDate(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getDate()
     */
    public final Date getDate(String paramName, Calendar cal)
	    throws SQLException
    {
	checkDefunct("getDate");

	return cStmt.getDate(paramName, cal);
    }
    
    /**
     * See java.sql.CallableStatement.getTime()
     */
    public final Time getTime(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getTime");

	return cStmt.getTime(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getTime()
     */
    public final Time getTime(int paramIndex, Calendar cal)
	    throws SQLException
    {
	checkDefunct("getTime");

	return cStmt.getTime(paramIndex, cal);
    }
    
    /**
     * See java.sql.CallableStatement.getTime()
     */
    public final Time getTime(String paramName)
	    throws SQLException
    {
	checkDefunct("getTime");

	return cStmt.getTime(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getTime()
     */
    public final Time getTime(String paramName, Calendar cal)
	    throws SQLException
    {
	checkDefunct("getTime");

	return cStmt.getTime(paramName, cal);
    }
    
    /**
     * See java.sql.CallableStatement.getTimestamp()
     */
    public final Timestamp getTimestamp(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getTimestamp");

	return cStmt.getTimestamp(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getTimestamp()
     */
    public final Timestamp getTimestamp(int paramIndex, Calendar cal)
	    throws SQLException
    {
	checkDefunct("getTimestamp");

	return cStmt.getTimestamp(paramIndex, cal);
    }
    
    /**
     * See java.sql.CallableStatement.getTimestamp()
     */
    public final Timestamp getTimestamp(String paramName)
	    throws SQLException
    {
	checkDefunct("getTimestamp");

	return cStmt.getTimestamp(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getTimestamp()
     */
    public final Timestamp getTimestamp(String paramName, Calendar cal)
	    throws SQLException
    {
	checkDefunct("getTimestamp");

	return cStmt.getTimestamp(paramName, cal);
    }
    
    /**
     * See java.sql.CallableStatement.getURL()
     */
    public final URL getURL(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getURL");

	return cStmt.getURL(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getURL()
     */
    public final URL getURL(String paramName)
	    throws SQLException
    {
	checkDefunct("getURL");

	return cStmt.getURL(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getRowId()
     */
    public final RowId getRowId(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getRowId");

	return cStmt.getRowId(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getRowId()
     */
    public final RowId getRowId(String paramName)
	    throws SQLException
    {
	checkDefunct("getRowId");

	return cStmt.getRowId(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getNClob()
     */
    public final NClob getNClob(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getNClob");

	return cStmt.getNClob(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getNClob()
     */
    public final NClob getNClob(String paramName)
	    throws SQLException
    {
	checkDefunct("getNClob");

	return cStmt.getNClob(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getNString()
     */
    public final String getNString(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getNString");

	return cStmt.getNString(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getNString()
     */
    public final String getNString(String paramName)
	    throws SQLException
    {
	checkDefunct("getNString");

	return cStmt.getNString(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.getSQLXML()
     */
    public final SQLXML getSQLXML(int paramIndex)
	    throws SQLException
    {
	checkDefunct("getSQLXML");

	return cStmt.getSQLXML(paramIndex);
    }
    
    /**
     * See java.sql.CallableStatement.getSQLXML()
     */
    public final SQLXML getSQLXML(String paramName)
	    throws SQLException
    {
	checkDefunct("getSQLXML");

	return cStmt.getSQLXML(paramName);
    }
    
    /**
     * See java.sql.CallableStatement.registerOutParameter()
     */
    public final void registerOutParameter(int paramIndex,
		                           int sqlType)
	    throws SQLException
    {
	checkDefunct("registerOutParameter");

	cStmt.registerOutParameter(paramIndex, sqlType);
    }
    
    /**
     * See java.sql.CallableStatement.registerOutParameter()
     */
    public final void registerOutParameter(int paramIndex,
		                           int sqlType,
					   int scale)
	    throws SQLException
    {
	checkDefunct("registerOutParameter");

	cStmt.registerOutParameter(paramIndex, sqlType, scale);
    }
    
    /**
     * See java.sql.CallableStatement.registerOutParameter()
     */
    public final void registerOutParameter(int paramIndex,
		                           int sqlType,
					   String typeName)
	    throws SQLException
    {
	checkDefunct("registerOutParameter");

	cStmt.registerOutParameter(paramIndex, sqlType, typeName);
    }

    /**
     * See java.sql.CallableStatement.registerOutParameter()
     */
    public final void registerOutParameter(String paramName,
		                           int sqlType)
	    throws SQLException
    {
	checkDefunct("registerOutParameter");

	cStmt.registerOutParameter(paramName, sqlType);
    }
    
    /**
     * See java.sql.CallableStatement.registerOutParameter()
     */
    public final void registerOutParameter(String paramName,
		                           int sqlType,
					   int scale)
	    throws SQLException
    {
	checkDefunct("registerOutParameter");

	cStmt.registerOutParameter(paramName, sqlType, scale);
    }
    
    /**
     * See java.sql.CallableStatement.registerOutParameter()
     */
    public final void registerOutParameter(String paramName,
		                           int sqlType,
					   String typeName)
	    throws SQLException
    {
	checkDefunct("registerOutParameter");

	cStmt.registerOutParameter(paramName, sqlType, typeName);
    }
    /**
     * See java.sql.CallableStatement.setAsciiStream()
     */
    public final void setAsciiStream(String parameterName, InputStream x) 
	    throws SQLException
    {
	checkDefunct("setAsciiStream");

	cStmt.setAsciiStream(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setAsciiStream()
     */
    public final void setAsciiStream(String parameterName, InputStream x, int length) 
	    throws SQLException
    {
	checkDefunct("setAsciiStream");

	cStmt.setAsciiStream(parameterName, x, length);
    }

    /**
     * See java.sql.CallableStatement.setAsciiStream()
     */
    public final void setAsciiStream(String parameterName, InputStream x, long length) 
	    throws SQLException
    {
	checkDefunct("setAsciiStream");

	cStmt.setAsciiStream(parameterName, x, length);
    }

    /**
     * See java.sql.CallableStatement.setBigDecimal()
     */
    public final void setBigDecimal(String parameterName, BigDecimal x) 
	    throws SQLException
    {
	checkDefunct("setBigDecimal");

	cStmt.setBigDecimal(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setBinaryStream()
     */
    public final void setBinaryStream(String parameterName, InputStream x) 
	    throws SQLException
    {
	checkDefunct("setBinaryStream");

	cStmt.setBinaryStream(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setBinaryStream()
     */
    public final void setBinaryStream(String parameterName, InputStream x, int length) 
	    throws SQLException
    {
	checkDefunct("setBinaryStream");

	cStmt.setBinaryStream(parameterName, x, length);
    }

    /**
     * See java.sql.CallableStatement.setBinaryStream()
     */
    public final void setBinaryStream(String parameterName, InputStream x, long length) 
	    throws SQLException
    {
	checkDefunct("setBinaryStream");

	cStmt.setBinaryStream(parameterName, x, length);
    }

    /**
     * See java.sql.CallableStatement.setBlob()
     */
    public final void setBlob(String parameterName, Blob x) 
	    throws SQLException
    {
	checkDefunct("setBlob");

	cStmt.setBlob(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setBlob()
     */
    public final void setBlob(String parameterName, InputStream x) 
	    throws SQLException
    {
	checkDefunct("setBlob");

	cStmt.setBlob(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setBlob()
     */
    public final void setBlob(String parameterName, InputStream x, long length) 
	    throws SQLException
    {
	checkDefunct("setBlob");

	cStmt.setBlob(parameterName, x, length);
    }

    /**
     * See java.sql.CallableStatement.setBoolean()
     */
    public final void setBoolean(String parameterName, boolean x) 
	    throws SQLException
    {
	checkDefunct("setBoolean");

	cStmt.setBoolean(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setByte()
     */
    public final void setByte(String parameterName, byte x) 
	    throws SQLException
    {
	checkDefunct("setByte");

	cStmt.setByte(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setBytes()
     */
    public final void setBytes(String parameterName, byte[] x) 
	    throws SQLException
    {
	checkDefunct("setBytes");

	cStmt.setBytes(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setCharacterStream()
     */
    public final void setCharacterStream(String parameterName, Reader x) 
	    throws SQLException
    {
	checkDefunct("setCharacterStream");

	cStmt.setCharacterStream(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setCharacterStream()
     */
    public final void setCharacterStream(String parameterName, Reader x, int length) 
	    throws SQLException
    {
	checkDefunct("setCharacterStream");

	cStmt.setCharacterStream(parameterName, x, length);
    }

    /**
     * See java.sql.CallableStatement.setCharacterStream()
     */
    public final void setCharacterStream(String parameterName, Reader x, long length) 
	    throws SQLException
    {
	checkDefunct("setCharacterStream");

	cStmt.setCharacterStream(parameterName, x, length);
    }

    /**
     * See java.sql.CallableStatement.setClob()
     */
    public final void setClob(String parameterName, Clob x) 
	    throws SQLException
    {
	checkDefunct("setClob");

	cStmt.setClob(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setClob()
     */
    public final void setClob(String parameterName, Reader x) 
	    throws SQLException
    {
	checkDefunct("setClob");

	cStmt.setClob(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setClob()
     */
    public final void setClob(String parameterName, Reader x, long length) 
	    throws SQLException
    {
	checkDefunct("setClob");

	cStmt.setClob(parameterName, x, length);
    }

    /**
     * See java.sql.CallableStatement.setDate()
     */
    public final void setDate(String parameterName, Date x) 
	    throws SQLException
    {
	checkDefunct("setDate");

	cStmt.setDate(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setDate()
     */
    public final void setDate(String parameterName, Date x, Calendar cal) 
	    throws SQLException
    {
	checkDefunct("setDate");

	cStmt.setDate(parameterName, x, cal);
    }

    /**
     * See java.sql.CallableStatement.setDouble()
     */
    public final void setDouble(String parameterName, double x) 
	    throws SQLException
    {
	checkDefunct("setDouble");

	cStmt.setDouble(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setFloat()
     */
    public final void setFloat(String parameterName, float x) 
	    throws SQLException
    {
	checkDefunct("setFloat");

	cStmt.setFloat(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setInt()
     */
    public final void setInt(String parameterName, int x) 
	    throws SQLException
    {
	checkDefunct("setInt");

	cStmt.setInt(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setLong()
     */
    public final void setLong(String parameterName, long x) 
	    throws SQLException
    {
	checkDefunct("setLong");

	cStmt.setLong(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setNCharacterStream()
     */
    public final void setNCharacterStream(String parameterName, Reader x) 
	    throws SQLException
    {
	checkDefunct("setNCharacterStream");

	cStmt.setNCharacterStream(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setNCharacterStream()
     */
    public final void setNCharacterStream(String parameterName, Reader x, long length) 
	    throws SQLException
    {
	checkDefunct("setNCharacterStream");

	cStmt.setNCharacterStream(parameterName, x, length);
    }

    /**
     * See java.sql.CallableStatement.setNClob()
     */
    public final void setNClob(String parameterName, NClob x) 
	    throws SQLException
    {
	checkDefunct("setNClob");

	cStmt.setNClob(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setNClob()
     */
    public final void setNClob(String parameterName, Reader x) 
	    throws SQLException
    {
	checkDefunct("setNClob");

	cStmt.setNClob(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setNClob()
     */
    public final void setNClob(String parameterName, Reader x, long length) 
	    throws SQLException
    {
	checkDefunct("setNClob");

	cStmt.setNClob(parameterName, x, length);
    }

    /**
     * See java.sql.CallableStatement.setNString()
     */
    public final void setNString(String parameterName, String x) 
	    throws SQLException
    {
	checkDefunct("setNString");

	cStmt.setNString(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setNull()
     */
    public final void setNull(String parameterName, int sqlType) 
	    throws SQLException
    {
	checkDefunct("setNull");

	cStmt.setNull(parameterName, sqlType);
    }

    /**
     * See java.sql.CallableStatement.setNull()
     */
    public final void setNull(String parameterName, int sqlType, String typeName) 
	    throws SQLException
    {
	checkDefunct("setNull");

	cStmt.setNull(parameterName, sqlType, typeName);
    }

    /**
     * See java.sql.CallableStatement.setObject()
     */
    public final void setObject(String parameterName, Object x) 
	    throws SQLException
    {
	checkDefunct("setObject");

	cStmt.setObject(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setObject()
     */
    public final void setObject(String parameterName, Object x, int targetSqlType) 
	    throws SQLException
    {
	checkDefunct("setObject");

	cStmt.setObject(parameterName, x, targetSqlType);
    }

    /**
     * See java.sql.CallableStatement.setObject()
     */
    public final void setObject(String parameterName, Object x, int targetSqlType,
		          int scaleOrLength) 
	    throws SQLException
    {
	checkDefunct("setObject");

	cStmt.setObject(parameterName, x, targetSqlType, scaleOrLength);
    }

    /**
     * See java.sql.CallableStatement.setRowid()
     */
    public final void setRowId(String parameterName, RowId x) 
	    throws SQLException
    {
	checkDefunct("setRowId");

	cStmt.setRowId(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setShort()
     */
    public final void setShort(String parameterName, short x) 
	    throws SQLException
    {
	checkDefunct("setShort");

	cStmt.setShort(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setSQLXML()
     */
    public final void setSQLXML(String parameterName, SQLXML x) 
	    throws SQLException
    {
	checkDefunct("setSQLXML");

	cStmt.setSQLXML(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setString()
     */
    public final void setString(String parameterName, String x) 
	    throws SQLException
    {
	checkDefunct("setString");

	cStmt.setString(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setTime()
     */
    public final void setTime(String parameterName, Time x) 
	    throws SQLException
    {
	checkDefunct("setTime");

	cStmt.setTime(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setTime()
     */
    public final void setTime(String parameterName, Time x, Calendar cal) 
	    throws SQLException
    {
	checkDefunct("setTime");

	cStmt.setTime(parameterName, x, cal);
    }

    /**
     * See java.sql.CallableStatement.setTimestamp()
     */
    public final void setTimestamp(String parameterName, Timestamp x) 
	    throws SQLException
    {
	checkDefunct("setTimestamp");

	cStmt.setTimestamp(parameterName, x);
    }

    /**
     * See java.sql.CallableStatement.setTimestamp()
     */
    public final void setTimestamp(String parameterName, Timestamp x, Calendar cal) 
	    throws SQLException
    {
	checkDefunct("setTimestamp");

	cStmt.setTimestamp(parameterName, x, cal);
    }

    /**
     * See java.sql.CallableStatement.setURL()
     */
    public final void setURL(String parameterName, URL x) 
	    throws SQLException
    {
	checkDefunct("setURL");

	cStmt.setURL(parameterName, x);
    }
    
    // Methods from PreparedStatement
    
    /**
     * See java.sql.PreparedStatement.getResultSet()
     */
    public final ResultSet getResultSet() 
	    throws SQLException
    {
	checkDefunct("getResultSet");

	return cStmt.getResultSet();
    }
    
    /**
     * See java.sql.PreparedStatement.execute()
     */
    public final boolean execute() 
	    throws SQLException
    {
	checkDefunct("execute");

	this.stmtConn.setInTxn(true);
	return cStmt.execute();
    }

    /**
     * See java.sql.PreparedStatement.executeQuery()
     */
    public final ResultSet executeQuery() 
	    throws SQLException
    {
	checkDefunct("executeQuery");

	this.stmtConn.setInTxn(true);
	return cStmt.executeQuery();
    }

    /**
     * See java.sql.PreparedStatement.executeUpdate()
     */
    public final int executeUpdate() 
	    throws SQLException
    {
	checkDefunct("executeUpdate");

	this.stmtConn.setInTxn(true);
	return cStmt.executeUpdate();
    }

    /**
     * See java.sql.PreparedStatement.addbatch()
     */
    public final void addBatch() 
	    throws SQLException
    {
	checkDefunct("addBatch");

	cStmt.addBatch();
    }

    /**
     * See java.sql.PreparedStatement.clearParameters()
     */
    public final void clearParameters() 
	    throws SQLException
    {
	checkDefunct("clearParameters");

	cStmt.clearParameters();
    }

    /**
     * See java.sql.PreparedStatement.getMetaData()
     */
    public final ResultSetMetaData getMetaData() 
	    throws SQLException
    {
	checkDefunct("getMetaData");

	return cStmt.getMetaData();
    }

    /**
     * See java.sql.PreparedStatement.getParameterMetaData()
     */
    public final ParameterMetaData getParameterMetaData() 
	    throws SQLException
    {
	checkDefunct("getParameterMetaData");

	return cStmt.getParameterMetaData();
    }

    /**
     * See java.sql.PreparedStatement.setArray()
     */
    public final void setArray(int parameterIndex, Array x) 
	    throws SQLException
    {
	checkDefunct("setArray");

	cStmt.setArray(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setAsciiStream()
     */
    public final void setAsciiStream(int parameterIndex, InputStream x) 
	    throws SQLException
    {
	checkDefunct("setAsciiStream");

	cStmt.setAsciiStream(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setAsciiStream()
     */
    public final void setAsciiStream(int parameterIndex, InputStream x, int length) 
	    throws SQLException
    {
	checkDefunct("setAsciiStream");

	cStmt.setAsciiStream(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setAsciiStream()
     */
    public final void setAsciiStream(int parameterIndex, InputStream x, long length) 
	    throws SQLException
    {
	checkDefunct("setAsciiStream");

	cStmt.setAsciiStream(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setBigDecimal()
     */
    public final void setBigDecimal(int parameterIndex, BigDecimal x) 
	    throws SQLException
    {
	checkDefunct("setBigDecimal");

	cStmt.setBigDecimal(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setBinaryStream()
     */
    public final void setBinaryStream(int parameterIndex, InputStream x) 
	    throws SQLException
    {
	checkDefunct("setBinaryStream");

	cStmt.setBinaryStream(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setBinaryStream()
     */
    public final void setBinaryStream(int parameterIndex, InputStream x, int length) 
	    throws SQLException
    {
	checkDefunct("setBinaryStream");

	cStmt.setBinaryStream(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setBinaryStream()
     */
    public final void setBinaryStream(int parameterIndex, InputStream x, long length) 
	    throws SQLException
    {
	checkDefunct("setBinaryStream");

	cStmt.setBinaryStream(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setBlob()
     */
    public final void setBlob(int parameterIndex, Blob x) 
	    throws SQLException
    {
	checkDefunct("setBlob");

	cStmt.setBlob(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setBlob()
     */
    public final void setBlob(int parameterIndex, InputStream x) 
	    throws SQLException
    {
	checkDefunct("setBlob");

	cStmt.setBlob(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setBlob()
     */
    public final void setBlob(int parameterIndex, InputStream x, long length) 
	    throws SQLException
    {
	checkDefunct("setBlob");

	cStmt.setBlob(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setBoolean()
     */
    public final void setBoolean(int parameterIndex, boolean x) 
	    throws SQLException
    {
	checkDefunct("setBoolean");

	cStmt.setBoolean(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setByte()
     */
    public final void setByte(int parameterIndex, byte x) 
	    throws SQLException
    {
	checkDefunct("setByte");

	cStmt.setByte(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setBytes()
     */
    public final void setBytes(int parameterIndex, byte[] x) 
	    throws SQLException
    {
	checkDefunct("setBytes");

	cStmt.setBytes(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setCharacterStream()
     */
    public final void setCharacterStream(int parameterIndex, Reader x) 
	    throws SQLException
    {
	checkDefunct("setCharacterStream");

	cStmt.setCharacterStream(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setCharacterStream()
     */
    public final void setCharacterStream(int parameterIndex, Reader x, int length) 
	    throws SQLException
    {
	checkDefunct("setCharacterStream");

	cStmt.setCharacterStream(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setCharacterStream()
     */
    public final void setCharacterStream(int parameterIndex, Reader x, long length) 
	    throws SQLException
    {
	checkDefunct("setCharacterStream");

	cStmt.setCharacterStream(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setClob()
     */
    public final void setClob(int parameterIndex, Clob x) 
	    throws SQLException
    {
	checkDefunct("setClob");

	cStmt.setClob(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setClob()
     */
    public final void setClob(int parameterIndex, Reader x) 
	    throws SQLException
    {
	checkDefunct("setClob");

	cStmt.setClob(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setClob()
     */
    public final void setClob(int parameterIndex, Reader x, long length) 
	    throws SQLException
    {
	checkDefunct("setClob");

	cStmt.setClob(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setDate()
     */
    public final void setDate(int parameterIndex, Date x) 
	    throws SQLException
    {
	checkDefunct("setDate");

	cStmt.setDate(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setDate()
     */
    public final void setDate(int parameterIndex, Date x, Calendar cal) 
	    throws SQLException
    {
	checkDefunct("setDate");

	cStmt.setDate(parameterIndex, x, cal);
    }

    /**
     * See java.sql.PreparedStatement.setDouble()
     */
    public final void setDouble(int parameterIndex, double x) 
	    throws SQLException
    {
	checkDefunct("setDouble");

	cStmt.setDouble(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setFloat()
     */
    public final void setFloat(int parameterIndex, float x) 
	    throws SQLException
    {
	checkDefunct("setFloat");

	cStmt.setFloat(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setInt()
     */
    public final void setInt(int parameterIndex, int x) 
	    throws SQLException
    {
	checkDefunct("setInt");

	cStmt.setInt(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setLong()
     */
    public final void setLong(int parameterIndex, long x) 
	    throws SQLException
    {
	checkDefunct("setLong");

	cStmt.setLong(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setNCharacterStream()
     */
    public final void setNCharacterStream(int parameterIndex, Reader x) 
	    throws SQLException
    {
	checkDefunct("setNCharacterStream");

	cStmt.setNCharacterStream(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setNCharacterStream()
     */
    public final void setNCharacterStream(int parameterIndex, Reader x, long length) 
	    throws SQLException
    {
	checkDefunct("setNCharacterStream");

	cStmt.setNCharacterStream(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setNClob()
     */
    public final void setNClob(int parameterIndex, NClob x) 
	    throws SQLException
    {
	checkDefunct("setNClob");

	cStmt.setNClob(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setNClob()
     */
    public final void setNClob(int parameterIndex, Reader x) 
	    throws SQLException
    {
	checkDefunct("setNClob");

	cStmt.setNClob(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setNClob()
     */
    public final void setNClob(int parameterIndex, Reader x, long length) 
	    throws SQLException
    {
	checkDefunct("setNClob");

	cStmt.setNClob(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setNString()
     */
    public final void setNString(int parameterIndex, String x) 
	    throws SQLException
    {
	checkDefunct("setNString");

	cStmt.setNString(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setNull()
     */
    public final void setNull(int parameterIndex, int sqlType) 
	    throws SQLException
    {
	checkDefunct("setNull");

	cStmt.setNull(parameterIndex, sqlType);
    }

    /**
     * See java.sql.PreparedStatement.setNull()
     */
    public final void setNull(int parameterIndex, int sqlType, String typeName) 
	    throws SQLException
    {
	checkDefunct("setNull");

	cStmt.setNull(parameterIndex, sqlType, typeName);
    }

    /**
     * See java.sql.PreparedStatement.setObject()
     */
    public final void setObject(int parameterIndex, Object x) 
	    throws SQLException
    {
	checkDefunct("setObject");

	cStmt.setObject(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setObject()
     */
    public final void setObject(int parameterIndex, Object x, int targetSqlType) 
	    throws SQLException
    {
	checkDefunct("setObject");

	cStmt.setObject(parameterIndex, x, targetSqlType);
    }

    /**
     * See java.sql.PreparedStatement.setObject()
     */
    public final void setObject(int parameterIndex, Object x, int targetSqlType,
		          int scaleOrLength) 
	    throws SQLException
    {
	checkDefunct("setObject");

	cStmt.setObject(parameterIndex, x, targetSqlType, scaleOrLength);
    }

    /**
     * See java.sql.PreparedStatement.setRef()
     */
    public final void setRef(int parameterIndex, Ref x) 
	    throws SQLException
    {
	checkDefunct("setRef");

	cStmt.setRef(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setRowid()
     */
    public final void setRowId(int parameterIndex, RowId x) 
	    throws SQLException
    {
	checkDefunct("setRowId");

	cStmt.setRowId(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setShort()
     */
    public final void setShort(int parameterIndex, short x) 
	    throws SQLException
    {
	checkDefunct("setShort");

	cStmt.setShort(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setSQLXML()
     */
    public final void setSQLXML(int parameterIndex, SQLXML x) 
	    throws SQLException
    {
	checkDefunct("setSQLXML");

	cStmt.setSQLXML(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setString()
     */
    public final void setString(int parameterIndex, String x) 
	    throws SQLException
    {
	checkDefunct("setString");

	cStmt.setString(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setTime()
     */
    public final void setTime(int parameterIndex, Time x) 
	    throws SQLException
    {
	checkDefunct("setTime");

	cStmt.setTime(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setTime()
     */
    public final void setTime(int parameterIndex, Time x, Calendar cal) 
	    throws SQLException
    {
	checkDefunct("setTime");

	cStmt.setTime(parameterIndex, x, cal);
    }

    /**
     * See java.sql.PreparedStatement.setTimestamp()
     */
    public final void setTimestamp(int parameterIndex, Timestamp x) 
	    throws SQLException
    {
	checkDefunct("setTimestamp");

	cStmt.setTimestamp(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setTimestamp()
     */
    public final void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) 
	    throws SQLException
    {
	checkDefunct("setTimestamp");

	cStmt.setTimestamp(parameterIndex, x, cal);
    }

    /**
     * See java.sql.PreparedStatement.setURL()
     */
    public final void setURL(int parameterIndex, URL x) 
	    throws SQLException
    {
	checkDefunct("setURL");

	cStmt.setURL(parameterIndex, x);
    }

    // Deprecated
    /**
     * See java.sql.PreparedStatement.setUnicodeStream() - DEPRECATED
     */
    public final void setUnicodeStream(int parameterIndex, InputStream x, int length) 
	    throws SQLException
    {
	checkDefunct("setUnicodeStream");

	cStmt.setUnicodeStream(parameterIndex, x, length);
    }

    // Methods from Statement

    /**
     * See java.sql.Statement.addBatch()
     */
    public final void addBatch(String sql) 
	    throws SQLException
    {
	checkDefunct("addBatch");

	cStmt.addBatch(sql);
    }

    /**
     * See java.sql.Statement.cancel()
     */
    public final void cancel() 
	    throws SQLException
    {
	checkDefunct("cancel");

	cStmt.cancel();
    }

    /**
     * See java.sql.Statement.clearBatch()
     */
    public final void clearBatch() 
	    throws SQLException
    {
	checkDefunct("clearBatch");

	cStmt.clearBatch();
    }

    /**
     * See java.sql.Statement.clearWarnings()
     */
    public final void clearWarnings() 
	    throws SQLException
    {
	checkDefunct("clearWarnings");

	cStmt.clearWarnings();
    }

    /**
     * See java.sql.Statement.execute()
     */
    public final boolean execute(String sql) 
	    throws SQLException
    {
	checkDefunct("execute");

	this.stmtConn.setInTxn(true);
	return cStmt.execute(sql);
    }
 
    /**
     * See java.sql.Statement.execute()
     */
    public final boolean execute(String sql, int autoGeneratedKeys) 
	    throws SQLException
    {
	checkDefunct("execute");

	this.stmtConn.setInTxn(true);
	return cStmt.execute(sql, autoGeneratedKeys);
    }
 
    /**
     * See java.sql.Statement.execute()
     */
    public final boolean execute(String sql, int[] columnIndexes) 
	    throws SQLException
    {
	checkDefunct("execute");

	this.stmtConn.setInTxn(true);
	return cStmt.execute(sql, columnIndexes);
    }
 
    /**
     * See java.sql.Statement.execute()
     */
    public final boolean execute(String sql, String[] columnNames) 
	    throws SQLException
    {
	checkDefunct("execute");

	this.stmtConn.setInTxn(true);
	return cStmt.execute(sql, columnNames);
    }

    /**
     * See java.sql.Statement.executeBatch()
     */
    public final int[] executeBatch() 
	    throws SQLException
    {
	checkDefunct("executeBatch");

	this.stmtConn.setInTxn(true);
	return cStmt.executeBatch();
    }
 
    /**
     * See java.sql.Statement.executeQuery()
     */
    public final ResultSet executeQuery(String sql) 
	    throws SQLException
    {
	checkDefunct("executeQuery");

	this.stmtConn.setInTxn(true);
	return cStmt.executeQuery(sql);
    }
 
    /**
     * See java.sql.Statement.executeUpdate()
     */
    public final int executeUpdate(String sql) 
	    throws SQLException
    {
	checkDefunct("executeUpdate");

	this.stmtConn.setInTxn(true);
	return cStmt.executeUpdate(sql);
    }
 
    /**
     * See java.sql.Statement.executeUpdate()
     */
    public final int executeUpdate(String sql, int autoGeneratedKeys) 
	    throws SQLException
    {
	checkDefunct("executeUpdate");

	this.stmtConn.setInTxn(true);
	return cStmt.executeUpdate(sql, autoGeneratedKeys);
    }
 
    /**
     * See java.sql.Statement.executeUpdate()
     */
    public final int executeUpdate(String sql, int[] columnIndexes) 
	    throws SQLException
    {
	checkDefunct("executeUpdate");

	this.stmtConn.setInTxn(true);
	return cStmt.executeUpdate(sql, columnIndexes);
    }
 
    /**
     * See java.sql.Statement.executeUpdate()
     */
    public final int executeUpdate(String sql, String[] columnNames) 
	    throws SQLException
    {
	checkDefunct("executeUpdate");

	this.stmtConn.setInTxn(true);
	return cStmt.executeUpdate(sql, columnNames);
    }
 
    /**
     * See java.sql.Statement.getFetchDirection()
     */
    public final int getFetchDirection() 
	    throws SQLException
    {
	return cStmt.getFetchDirection();
    }
 
    /**
     * See java.sql.Statement.getFetchSize()
     */
    public final int getFetchSize() 
	    throws SQLException
    {
	checkDefunct("getFetchSize");

	return cStmt.getFetchSize();
    }
 
    /**
     * See java.sql.Statement.getGeneratedKeys()
     */
    public final ResultSet getGeneratedKeys() 
	    throws SQLException
    {
	checkDefunct("getFetchSize");

	return cStmt.getGeneratedKeys();
    }
 
    /**
     * See java.sql.Statement.getMaxFieldSize()
     */
    public final int getMaxFieldSize() 
	    throws SQLException
    {
	checkDefunct("getMaxFieldSize");

	return cStmt.getMaxFieldSize();
    }
 
    /**
     * See java.sql.Statement.getMaxRows()
     */
    public final int getMaxRows() 
	    throws SQLException
    {
	checkDefunct("getMaxRows");

	return cStmt.getMaxRows();
    }
 
    /**
     * See java.sql.Statement.getMoreResults()
     */
    public final boolean getMoreResults() 
	    throws SQLException
    {
	checkDefunct("getMoreResults");

	return cStmt.getMoreResults();
    }

    /**
     * See java.sql.Statement.getMoreResults()
     */
    public final boolean getMoreResults(int current) 
	    throws SQLException
    {
	checkDefunct("getMoreResults");

	return cStmt.getMoreResults(current);
    }
 
    /**
     * See java.sql.Statement.getQueryTimeout()
     */
    public final int getQueryTimeout() 
	    throws SQLException
    {
	checkDefunct("getQueryTimeout");

	return cStmt.getQueryTimeout();
    }
 
    /**
     * See java.sql.Statement.getResultSetConcurrency()
     */
    public final int getResultSetConcurrency() 
	    throws SQLException
    {
	checkDefunct("getResultSetConcurrency");

	return cStmt.getResultSetConcurrency();
    }
 
    /**
     * See java.sql.Statement.getResultSetHoldability()
     */
    public final int getResultSetHoldability() 
	    throws SQLException
    {
	checkDefunct("getResultSetHoldability");

	return cStmt.getResultSetHoldability();
    }
 
    /**
     * See java.sql.Statement.getResultSetType()
     */
    public final int getResultSetType() 
	    throws SQLException
    {
	checkDefunct("getResultSetType");

	return cStmt.getResultSetType();
    }
 
    /**
     * See java.sql.Statement.getUpdateCount()
     */
    public final int getUpdateCount() 
	    throws SQLException
    {
	checkDefunct("getUpdateCount");

	return cStmt.getUpdateCount();
    }

    /**
     * See java.sql.Statement.getWarnings()
     */
    public final SQLWarning getWarnings() 
	    throws SQLException
    {
	checkDefunct("getWarnings");

	return cStmt.getWarnings();
    }

    /**
     * See java.sql.Statement.setCursorName()
     */
    public final void setCursorName(String name) 
	    throws SQLException
    {
	checkDefunct("setCursorName");

	cStmt.setCursorName(name);
    }

    /**
     * See java.sql.Statement.setEscapeProcessing()
     */
    public final void setEscapeProcessing(boolean enable) 
	    throws SQLException
    {
	checkDefunct("setEscapeProcessing");

	cStmt.setEscapeProcessing(enable);
    }

    /**
     * See java.sql.Statement.setFetchDirection()
     */
    public final void setFetchDirection(int direction) 
	    throws SQLException
    {
	checkDefunct("setFetchDirection");

	cStmt.setFetchDirection(direction);
    }

    /**
     * See java.sql.Statement.setFetchSize()
     */
    public final void setFetchSize(int rows) 
	    throws SQLException
    {
	checkDefunct("setFetchSize");

	cStmt.setFetchSize(rows);
    }

    /**
     * See java.sql.Statement.setMaxFieldSize()
     */
    public final void setMaxFieldSize(int max) 
	    throws SQLException
    {
	checkDefunct("setMaxFieldSize");

	cStmt.setMaxFieldSize(max);
    }

    /**
     * See java.sql.Statement.setMaxRows()
     */
    public final void setMaxRows(int rows) 
	    throws SQLException
    {
	checkDefunct("setMaxRows");

	cStmt.setMaxRows(rows);
    }

    /**
     * See java.sql.Statement.setQueryTimeout()
     */
    public final void setQueryTimeout(int seconds) 
	    throws SQLException
    {
	checkDefunct("setQueryTimeout");

	cStmt.setQueryTimeout(seconds);
    }

    // Methods from Wrapper

    public final boolean isWrapperFor(Class<?> iface) 
	    throws SQLException
    {
	return cStmt.isWrapperFor(iface);
    }

    public final <T> T unwrap(Class <T> iface) 
	    throws SQLException
    {
	return cStmt.unwrap(iface);
    }

	@Override
	public <T> T getObject(int parameterIndex, Class<T> type)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> T getObject(String parameterName, Class<T> type)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void closeOnCompletion() throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isCloseOnCompletion() throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ResultSet getReturnResultSet() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void registerReturnParameter(int arg0, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void registerReturnParameter(int arg0, int arg1, int arg2)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setPlsqlIndexTable(int arg0, Object arg1, int arg2, int arg3,
			int arg4, int arg5) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getLobPrefetchSize() throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getQueryTimeThreshold() throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setLobPrefetchSize(int arg0) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setQueryTimeThreshold(int arg0) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getPlsqlIndexTable(int arg0) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getPlsqlIndexTable(int arg0, Class<?> arg1)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void registerIndexTableOutParameter(int arg0, int arg1, int arg2,
			int arg3) throws SQLException {
		// TODO Auto-generated method stub
		
	}
}

