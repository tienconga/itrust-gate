package com.noname.itrust.gate.thread;

import java.sql.SQLException;
import org.springframework.stereotype.Service;

import com.noname.itrust.gate.rules.SORule;

@Service
public class ScanSOOrderScheduledProcessor {
	
	/**
	 * 
	 * @throws SQLException
	 */
	public synchronized void process() {
		SORule rule = new SORule();
		rule.divideOrder_type_T();
	}
}
