package com.noname.itrust.gate;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ItrustGateProperties {
	@Value("${foplus.bpsj.service.processor}")
	private String processorQueue;

/*	@Value("${foplus.bpsj.service.processor.trans}")
	private String transProcessorQueue;*/

	@Value("${foplus.message.timeout}")
	private String timeout;

	/**
	 * @return the timeout
	 */
	public String getTimeout() {
		return timeout;
	}

	public String getProcessorQueue() {
		return processorQueue;
	}

/*	public String getTransProcessorQueue() {
		return transProcessorQueue;
	}*/
}
