package com.noname.itrust.gate.filter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import org.springframework.stereotype.Service;

import com.fss.fo.mserver.exchange.StockInforProtos.StockInfor;
import com.fss.fo.mserver.exchange.TransLogProtos.TransLog;
import com.noname.itrust.gate.caching.CacheProcessing;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.model.FilterMsg;
import com.noname.itrust.gate.model.Market;
import com.noname.itrust.gate.sql.SQLStatement;

@Service
public class MarketFilter {
	
	private static HashMap<String,String> stockInfoList = new HashMap<String,String>();
	private static HashMap<String,String> transLogList = new HashMap<String,String>();
	//chua danh sach cac ma chung khoan se filter theo luat thoi gian hoac so luong messsage
	private static HashMap<String,FilterMsg> counttimeList = new HashMap<String,FilterMsg>();
	
	/**
	 * init filter conditions
	 */
	public void initFilter(){
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
	        ps = conn.prepareStatement(ConnectionManager.sqlMap.get(SQLStatement.KEY_SEL_MARKETFILTER));
	        rs = ps.executeQuery();
		   
	        while(rs.next()){
	        	String symbol = rs.getString("SYMBOL");
	        	String stockinfor = rs.getString("STOCKINFOR");
	        	String translog = rs.getString("TRANSLOG");
	        	String counttime = rs.getString("COUNTTIME");
	        	int counttimeval = rs.getInt("COUNTTIMEVAL");
	        	
	        	//filter theo danh sach ma chung khoan
	        	if(symbol != null && !symbol.equalsIgnoreCase("")){
	        		if(stockinfor != null && stockinfor.equalsIgnoreCase("Y")){
	        			stockInfoList.put(symbol, symbol);
	        		}
	        		
	        		if(translog != null && translog.equalsIgnoreCase("Y")){
	        			transLogList.put(symbol, symbol);
	        		}	
	        	}
	        	
	        	//filter theo so luong message hoac thoi gian
	        	if(counttime != null && !counttime.equalsIgnoreCase("NONE")){
	        		FilterMsg filtermsg = new FilterMsg();
	        		filtermsg.setSymbol(symbol);
	        		filtermsg.setCounttime(counttime);
	        		filtermsg.setCounttimeval(counttimeval);
	        		counttimeList.put(symbol, filtermsg);
	        	}	        	
	        }
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * 
	 * @param StockInfor
	 * @return
	 */
	public StockInfor filter(StockInfor stock){
		String key = stock.getSymbol();
		
		//filter symbol list
		if(key != null && !key.equalsIgnoreCase("")){
			//filter symbol list
			String temp = stockInfoList.get(key);
			if(temp != null && temp.equalsIgnoreCase(key)){
				//System.out.println("============Push to engine core:" + key);
			}else{
				//System.out.println("============Reject symbol:" + key);
				return null;
			}
		}
		
		return stock;
	}
	

	/**
	 * 
	 * @param TransLog
	 * @return
	 */
	public TransLog filter(TransLog trans){
		String key = trans.getSymbol();
		//filter symbol list
		if(key != null && !key.equalsIgnoreCase("")){
			String temp = transLogList.get(key);
			if(temp != null && temp.equalsIgnoreCase(key)){
				//System.out.println("============Push to engine core:" + key);
				return trans;
			}else{
				//System.out.println("============Reject symbol:" + key);
				return null;
			}
		}
		
		return null;
	}
	
	public Market filter(Market market) {
		//logger.info("====" + market.getSymbol());

		Market calRate = CacheProcessing.calMarket.get(market.getSymbol());
		Date oldDate = calRate.getDate();
		Date newDate = market.getDate();

		long seconds = (newDate.getTime() - oldDate.getTime()) / 1000;

		if (seconds >= 3) {
			return market;
		} else {
			return null;
		}
	}
	
	public static void registerStockInfo(String symbol) {
		stockInfoList.put(symbol, symbol);
	}
	
	public static void registerTransLogInfo(String symbol) {
		transLogList.put(symbol, symbol);
	}
}
