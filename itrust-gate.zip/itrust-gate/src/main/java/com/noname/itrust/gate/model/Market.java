package com.noname.itrust.gate.model;

import java.math.BigDecimal;
import java.util.Date;

public class Market implements ISignal, java.io.Serializable {

	static final long serialVersionUID = 1L; //assign a long value

	private String symbol;
	private String cFICode;
	private String exchange;
	private String board;
	private BigDecimal priceCE;
	private BigDecimal priceFL;
	private BigDecimal priceRF;
	private String halt;
	private BigDecimal latestPrice;
	private Date date;

	public Market(String symbol, String exchange, String board,
			BigDecimal priceCE, BigDecimal priceFL, BigDecimal priceRF, String halt) {
		super();
		this.symbol = symbol;
		this.exchange = exchange;
		this.board = board;
		this.priceCE = priceCE;
		this.priceFL = priceFL;
		this.priceRF = priceRF;
		this.halt = halt;
	}

	public Market() {
	};

	public Market(String exchange, String board) {
		this.exchange = exchange;
		this.board = board;
	}

	/**
	 * @return the symbol
	 */
	public String getSymbol() {
		return symbol;
	}

	/**
	 * @param symbol the symbol to set
	 */
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	/**
	 * @return the cFICode
	 */
	public String getcFICode() {
		return cFICode;
	}

	/**
	 * @param cFICode the cFICode to set
	 */
	public void setcFICode(String cFICode) {
		this.cFICode = cFICode;
	}

	/**
	 * @return the exchange
	 */
	public String getExchange() {
		return exchange;
	}

	/**
	 * @param exchange the exchange to set
	 */
	public void setExchange(String exchange) {
		this.exchange = exchange;
	}

	/**
	 * @return the board
	 */
	public String getBoard() {
		return board;
	}

	/**
	 * @param board the board to set
	 */
	public void setBoard(String board) {
		this.board = board;
	}

	/**
	 * @return the priceCE
	 */
	public BigDecimal getPriceCE() {
		return priceCE;
	}

	/**
	 * @param priceCE the priceCE to set
	 */
	public void setPriceCE(BigDecimal priceCE) {
		this.priceCE = priceCE;
	}

	/**
	 * @return the priceFL
	 */
	public BigDecimal getPriceFL() {
		return priceFL;
	}

	/**
	 * @param priceFL the priceFL to set
	 */
	public void setPriceFL(BigDecimal priceFL) {
		this.priceFL = priceFL;
	}

	/**
	 * @return the priceRF
	 */
	public BigDecimal getPriceRF() {
		return priceRF;
	}

	/**
	 * @param priceRF the priceRF to set
	 */
	public void setPriceRF(BigDecimal priceRF) {
		this.priceRF = priceRF;
	}

	/**
	 * @return the halt
	 */
	public String getHalt() {
		return halt;
	}

	/**
	 * @param halt the halt to set
	 */
	public void setHalt(String halt) {
		this.halt = halt;
	}

	public BigDecimal getLatestPrice() {
		return latestPrice;
	}

	public void setLatestPrice(BigDecimal latestPrice) {
		this.latestPrice = latestPrice;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
