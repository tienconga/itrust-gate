package com.noname.itrust.gate.processing;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import oracle.jdbc.OracleTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fss.newfo.common.model.Message;
import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.model.Result;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.aq.MessageSender;
import com.noname.itrust.gate.caching.CacheProcessing;
import com.noname.itrust.gate.converter.Converter;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.data.dao.DAOCommon;
import com.noname.itrust.gate.sending.CancelOrderSending;
import com.noname.itrust.gate.sql.SQLStatement;

@Component
public class CancelRequestHandler extends AbstracRequestHandler{
	
	//@Autowired
	//private MessageSender messageSender;
	
	public  Result execute(Message message){
		
		Quote quote = (Quote) message;
		quote.setStatus("C"); //dang huy
		
		//checking status && type of order in DB
		Connection conn = null; 
        ConnectionManager mgr = new ConnectionManager();
        CallableStatement callableStatement = null;
        ResultSet rs = null;
        
        String log = "";
        String p_err_code = "After execute:";
        try {
        	conn = mgr.getConnection();
        	
        	String quoteid = quote.getOrderid();
			callableStatement = conn.prepareCall(ConnectionManager.sqlMap.get(SQLStatement.KEY_CANCEL_ORDER));
			callableStatement.registerOutParameter(1, Types.VARCHAR);// p_err_code
			callableStatement.registerOutParameter(2, Types.VARCHAR);// p_out_message
			callableStatement.registerOutParameter(3, Types.VARCHAR);// p_out_result
			callableStatement.registerOutParameter(4, Types.VARCHAR);// p_out_symbol
			callableStatement.registerOutParameter(5, OracleTypes.CURSOR); // p_out_recordset
			callableStatement.setString(6, quoteid); // p_orderid = TSO.quoteid
			callableStatement.setString(7, quote.getClasscd());// p_classcd :
			callableStatement.setString(8, quote.getQuoteid());// p_quoteid
			callableStatement.setString(9, quote.getAcctno());// p_acctno
							
			log = "store parametter -|  CSPKS_HFT_CANCEL_ORDER.sp_cancel_orde |  p_orderid: " + quote.getOrderid()
			+ "|  p_classcd: " + quote.getClasscd() + "|  cancel quotei: " + quote.getQuoteid() + "| p_acctno: " + quote.getAcctno();
			
			SLF4JLoggerProxy.info(this, log);
			callableStatement.execute();
			p_err_code = callableStatement.getString(1);
			if(!p_err_code.equalsIgnoreCase("0") ){
				SLF4JLoggerProxy.error(this, "Could not cance order:" + quote.getOrderid() + ",p_err_code:" + p_err_code);
				// Convert data
				quote.setErrorCode(p_err_code);
				//messageSender.send(Converter.convertQuote2String(quote));
				conn.commit();
				return null;
			}
			
			String p_out_result = callableStatement.getString(3);
			String symbol = callableStatement.getString(4);
			
			if(p_err_code.equalsIgnoreCase("0") && p_out_result != null && p_out_result.equalsIgnoreCase("A")){//lenh da active va da sinh lenh con
				rs = (ResultSet) callableStatement.getObject(5); //list suborder that will cancel
				while (rs.next()) {
					String cancel_orderid = rs.getString("ORDERID");
					String substatus = rs.getString("SUBSTATUS");
					//String orderType = rs.getString("ORDERTYPE");
					
					SLF4JLoggerProxy.info(this, "Cancel order info, cancel_orderid:" + cancel_orderid +
							",substatus" + substatus + ", orderType:" + quote.getClasscd());
					
					CancelOrderSending cancelObj = new CancelOrderSending();
					quote.setOrderid(cancel_orderid);
					quote.setReftype("D");//D: con nguoi huy, C: engine huy
					
					DAOCommon obj = new DAOCommon();
					obj.updateStatus(quoteid, "C" , quote.getClasscd());//dang doi huy
					
					//cancel order
					String errorCode = cancelObj.cancelOrder(quote,"");
					if(substatus != null && errorCode != null && substatus.equalsIgnoreCase("NN") && errorCode.equalsIgnoreCase("0")){
						obj.updateStatus(quoteid, "E" , quote.getClasscd());
					}
				}
				
				//TODO: remove cache
			}else if(p_err_code.equalsIgnoreCase("0") && p_out_result != null && p_out_result.equalsIgnoreCase("B")){ //lenh chua kich hoat -> chi can huy lenh cha
				//TODO: check object, neu dang kich hoat thì không hủy, trả ra msg queue
				CacheProcessing obj = new CacheProcessing();
				obj.removeCache(symbol, quote.getOrderid(), quote.getClasscd());
				quote.setStatus("B"); //da huy
				
				DAOCommon objCommon = new DAOCommon();
				objCommon.updateStatus(quoteid, "E" , quote.getClasscd());//cap nhat trang thai lenh cha
			}

			conn.commit();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {				
				if (rs != null) {
					rs.close();
				}
				if (callableStatement != null) {
					callableStatement.clearParameters();
					callableStatement.close();
					callableStatement = null;
				}
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
			
			SLF4JLoggerProxy.info(this, p_err_code);
		}
		return null;
	}

}
