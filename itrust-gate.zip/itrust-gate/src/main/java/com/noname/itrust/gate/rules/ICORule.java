package com.noname.itrust.gate.rules;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.CacheProcessing;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.common.CommonConstants;
import com.noname.itrust.gate.data.dao.DAOCommon;
import com.noname.itrust.gate.model.ISignal;
import com.noname.itrust.gate.sending.CancelOrderSending;
import com.noname.itrust.gate.thread.TicketQueue;

public class ICORule implements IRules {

	private LinkedBlockingQueue<Quote> queue;
	
	@Override
	public void process(ISignal market,Quote quote) {
		// TODO Auto-generated method stub
	}

	@Override
	public void putRequest(Quote quote) {
		// TODO Auto-generated method stub

	}

	@Override
	public void load() {
		// TODO Auto-generated method stub

	}
	
	public void placeOrder(Quote quote) {
		String board = CacheProcessing.InstrumentMap.get(quote.getSymbol()).getBoard();
		if(board != null && board.equalsIgnoreCase("HSX") && HandlerCacheData.hsxSession.equalsIgnoreCase("CNT")){
			activeOrder(quote, true);
		}else if(board != null && board.equalsIgnoreCase("HNX") && HandlerCacheData.hnxSession.equalsIgnoreCase("CNT")){
			activeOrder(quote, true);
		}else if(board != null && board.equalsIgnoreCase("UPCOM") && HandlerCacheData.upcomSession.equalsIgnoreCase("CNT")){
			activeOrder(quote, true);
		}else if((board != null && board.equalsIgnoreCase("HSX") && ((HandlerCacheData.hsxSession.equalsIgnoreCase("BOPN")) ||
				(HandlerCacheData.hsxSession.equalsIgnoreCase("OPN")) ||
				(HandlerCacheData.hsxSession.equalsIgnoreCase("LB")))) ||
				(board != null && board.equalsIgnoreCase("HNX") && HandlerCacheData.hnxSession.equalsIgnoreCase("BCNT")) ||
				(board != null && board.equalsIgnoreCase("UPCOM") && HandlerCacheData.upcomSession.equalsIgnoreCase("BCNT"))){
			//wait session flag
			quote.setStatus("P");
			DAOCommon obj = new DAOCommon();
			obj.updateStatus(quote.getQuoteid(), "P","ICO");
		}else{		
			String requestid = DAOCommon.getSequence();
			if(requestid == null){
				long time = System.currentTimeMillis();
				requestid = String.valueOf(time);
				requestid = quote.getClasscd() + requestid;
			}
			
			DAOCommon persistentObj = new DAOCommon();
			persistentObj.saveExecuteOrder(quote, requestid, null,"-95015", null, "N");
			
			persistentObj.updateStatus(quote.getQuoteid(), CommonConstants.ORDER_STATUS_ACTIVING,"ICO");
		}
	}
	
	private void activeOrder(Quote quote, boolean removeFlag){
		//kich hoat lenh
		SLF4JLoggerProxy.info(this,"Active ICO Order ***** quoteid:" + quote.getQuoteid());
		
		try {
			TicketQueue queThread = TicketQueue.getTicketQueueThread();
			queue = queThread.getTicketqueue();
			queue.put(quote);
		} catch (InterruptedException e) {
			SLF4JLoggerProxy.error(this, "Error when active ICO Order ***** quoteid:" + quote.getQuoteid() + "," + e);
		}
		
		if(removeFlag){
			//xoa khoi orders list
			Map<String,Quote> icoOrders = HandlerCacheData.icoMap.get(quote.getSymbol());
			icoOrders.remove(quote.getQuoteid());
		}

		//syn to DB
		DAOCommon obj = new DAOCommon();
		obj.updateStatus(quote.getQuoteid(), CommonConstants.ORDER_STATUS_ACTIVING,"ICO");
	}
	
	
	public void cancelOrder(Quote quote, String errorcode, String orderid){
		if(orderid != null){
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				SLF4JLoggerProxy.error(this, "Error when cancel ICO Order ***** quoteid:" + quote.getQuoteid() + "," + e);
			}
			CancelOrderSending cancelObject = new CancelOrderSending();
			quote.setOrderid(orderid);
			cancelObject.cancelOrder(quote,"");
		}
	}
	
	public synchronized void orderSession(String exchangeCode, String session){
		Set<Entry<String, Map<String, Quote>>> set1 =  HandlerCacheData.icoMap.entrySet();
		Iterator<Entry<String, Map<String, Quote>>> it1 = set1.iterator();

		List<String> removeList = new ArrayList<String>();
		List<String> removeSymbolList = new ArrayList<String>();
		while (it1.hasNext()) {		
			Entry<String, Map<String, Quote>> entry1 = it1.next();
			String symbol = entry1.getKey();//symbol
			String board = CacheProcessing.InstrumentMap.get(symbol).getBoard();
			if(board != null && board.equalsIgnoreCase(exchangeCode)){
				removeSymbolList.add(symbol);
				Map<String, Quote> map2 = entry1.getValue();
				Set<Entry<String,Quote>> set2 = map2.entrySet();
				Iterator<Entry<String,Quote>> it2 = set2.iterator();
				while(it2.hasNext()){
					 Entry<String,Quote> entry2 = it2.next();
					 Quote quoteObj = entry2.getValue();
					 activeOrder(quoteObj, false); 
					 removeList.add(quoteObj.getQuoteid());
				}
			}
		}
		
		for(int i = 0; i < removeSymbolList.size(); i++){
			String symbol = removeSymbolList.get(i);
			Map<String,Quote> icoOrders = HandlerCacheData.icoMap.get(symbol);
			for(int j = 0; j < removeList.size(); j ++){
				String quoteid = removeList.get(j);
				icoOrders.remove(quoteid);
			}
			
		}
		
	}

}
