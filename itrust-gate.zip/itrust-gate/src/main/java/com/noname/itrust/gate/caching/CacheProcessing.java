package com.noname.itrust.gate.caching;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.collections4.map.MultiValueMap;
import org.apache.log4j.Logger;

import com.fss.newfo.common.model.Instrument;
import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.model.Market;
import com.noname.itrust.gate.model.TickSize;
import com.noname.itrust.gate.sending.NewOrderSending;
import com.noname.itrust.gate.sql.SQLStatement;


public class CacheProcessing {

	final static Logger logger = Logger.getLogger(CacheProcessing.class);

	public static Map<String, Market> latestMarket = new HashMap<String, Market>();
	public static Map<String, Market> calMarket = new HashMap<String, Market>();
	public static Map<String, Instrument> InstrumentMap = new HashMap<String, Instrument>();
	public static Map<String, Long> maxQttyMap = new HashMap<String, Long>();
	public static MultiValueMap<String, TickSize> ticksizeMap =  new MultiValueMap<String, TickSize >();
	
	public static void putQuote(Quote quote) {
		/*IRules handler = HandlerCacheData.requestHandlerMap.get(quote.getClasscd());
		if (null == handler) {
			logger.error("quote input is not correct format");
		}
		handler.putRequest(quote);*/
	}

	public static void putMarket(Market market) {
		latestMarket.put(market.getSymbol(), market);		
	}

	public static void initCache() {
		loadRateCache();
		loadTickSize();
		loadActiveOrder();
	}

	private static void loadRateCache() {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
        
		try {
			conn = mgr.getConnection();
	        ps = conn.prepareStatement(ConnectionManager.sqlMap.get(SQLStatement.KEY_SEL_INSTRUMENTS));
	        rs = ps.executeQuery();
	        
			while (rs.next()) {
				String symbol = rs.getString("SYMBOL");
				BigDecimal priceRF = rs.getBigDecimal("PRICE_RF");
				BigDecimal priceCE = rs.getBigDecimal("PRICE_CE");
				BigDecimal priceFL = rs.getBigDecimal("PRICE_FL");
				String exchange = rs.getString("EXCHANGE");
				String board = rs.getString("BOARD");
				
				Market market = new Market();
				market.setSymbol(symbol);
				market.setPriceRF(priceRF);
				market.setDate(new Date());
				calMarket.put(market.getSymbol(), market);
				
				//init instrument cache
				Instrument obj = InstrumentMap.get(symbol);
				if(obj == null){
					obj = new Instrument();
					obj.setSymbol(symbol);
					obj.setExchange(exchange);
					obj.setBoard(board);
					obj.setPriceCE(priceCE);
					obj.setPriceRF(priceRF);
					obj.setPriceFL(priceFL);
					InstrumentMap.put(symbol, obj);
				}else{
					obj.setSymbol(symbol);
					obj.setExchange(exchange);
					obj.setBoard(board);
					obj.setPriceCE(priceCE);
					obj.setPriceRF(priceRF);
					obj.setPriceFL(priceFL);
				}
			}

			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(CacheProcessing.class, e);
			}
		}
	}
	
	
	private static void loadTickSize() {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
        
		try {
			conn = mgr.getConnection();
	        ps = conn.prepareStatement(ConnectionManager.sqlMap.get(SQLStatement.KEY_SEL_TICKSIZE));
	        rs = ps.executeQuery();
	        
			while (rs.next()) {
				String refcode = rs.getString("REFCODE");
				Long tickSize = rs.getLong("TICKSIZE");
				BigDecimal fromPrice = rs.getBigDecimal("FROMPRICE");
				BigDecimal toPrice = rs.getBigDecimal("TOPRICE");
				
				TickSize ticksizeObj = new TickSize();
				ticksizeObj.setTickSize(tickSize);
				ticksizeObj.setFromPrice(fromPrice);
				ticksizeObj.setToPrice(toPrice);
				
				ticksizeMap.put(refcode, ticksizeObj);
			}

			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(CacheProcessing.class, e);
			}
		}
	}
	
	
	private static void loadActiveOrder() {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
        
		try {
			conn = mgr.getConnection();
	        ps = conn.prepareStatement(ConnectionManager.sqlMap.get(SQLStatement.KEY_SEL_ACTIVE_ORDER));
	        rs = ps.executeQuery();
	        
			while (rs.next()) {
				String orderid = rs.getString("ORDERID");
				String orderytype = rs.getString("ORDERTYPE");
				
				NewOrderSending.activeOrderMap.put(orderid, orderytype);
			}

			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(CacheProcessing.class, e);
			}
		}
	}
	
	
	public void removeCache(String symbol, String quoteid, String classcd){
		if(classcd != null && classcd.equalsIgnoreCase("TSO")){
			synchronized (HandlerCacheData.tsoMap) {
				Map<String,Quote> orderInfos = HandlerCacheData.tsoMap.get(symbol);
				orderInfos.remove(quoteid);
			}
			
		}else if(classcd != null && classcd.equalsIgnoreCase("STO")){
			Map<String,Quote> orderInfos = HandlerCacheData.stoMap.get(symbol);
			orderInfos.remove(quoteid);
		}else if(classcd != null && classcd.equalsIgnoreCase("SEO")){
			Map<String,Quote> orderInfos = HandlerCacheData.seoMap.get(symbol);
			orderInfos.remove(quoteid);
		}else if(classcd != null && classcd.equalsIgnoreCase("PCO")){
			Map<String,Quote> orderInfos = HandlerCacheData.pcoMap.get(symbol);
			orderInfos.remove(quoteid);
		}else if(classcd != null && classcd.equalsIgnoreCase("SO")){
			//Map<String,Quote> orderInfos = HandlerCacheData.soMap.get(symbol);
			//orderInfos.remove(quoteid);
		}else if(classcd != null && classcd.equalsIgnoreCase("ICO")){
			Map<String,Quote> orderInfos = HandlerCacheData.icoMap.get(symbol);
			orderInfos.remove(quoteid);
		}else if(classcd != null && classcd.equalsIgnoreCase("CPO")){
			//Map<String,Quote> orderInfos = HandlerCacheData.cpoMap.get(symbol);
			//orderInfos.remove(quoteid);
		}else if(classcd != null && classcd.equalsIgnoreCase("OCO")){
			/*Map<String,Quote> orderInfos = HandlerCacheData.ocoMap.get(symbol);
			orderInfos.remove(quoteid);*/
		}else if(classcd != null && classcd.equalsIgnoreCase("OTO")){
			Map<String,Quote> orderInfos = HandlerCacheData.otoMap.get(symbol);
			orderInfos.remove(quoteid);
		}else if(classcd != null && classcd.equalsIgnoreCase("MCO")){
			//Map<String,Quote> orderInfos = HandlerCacheData.mcoMap.get(symbol);
			//orderInfos.remove(quoteid);
		}
	}
}
