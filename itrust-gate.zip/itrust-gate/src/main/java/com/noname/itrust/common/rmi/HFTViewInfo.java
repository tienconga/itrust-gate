package com.noname.itrust.common.rmi;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonProperty;


public class HFTViewInfo implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;

	private String quoteid;
	private Date createddt;
	private Date expireddt;
	private String userid;
	private String classcd;
	private String subclass;
	private String via;
	private String status;
	private String substatus;
	private Serializable timeQuote;
	private Serializable timeSend;
	private String typecd;
	private String subtypecd;
	private String side;
	private String refquoteid;
	private String symbol;
	private Long qtty;
	@JsonProperty(value = "qtty_based")
	private Long qttyBased;
	@JsonProperty(value = "qtty_delta")
	private Long qttyDelta;
	private Long qttyCancel;
	private Long qttyAdmend;
	private Character distributecd;
	private String acctno;
	private BigDecimal price;
	private BigDecimal priceRf;
	private BigDecimal priceCe;
	private BigDecimal priceFl;
	private BigDecimal pricedelta;
	private BigDecimal execAmt;
	private BigDecimal execQtty;
	private Serializable lastchange;
	private String reforderid;
	private String sessionex;
	private String refSessionex;
	private String reftype;
	private String book;
	private String orderid;
	private String subside;
	private String firm;
	private String text;
	private String traderid;
	private String contraacctno;
	private String buyacctno;
	private String sellacctno;
	private String crossnumber;
	private String advFlag;
	private String requestid;
	private int clearday = 0;
	
	private String ordertype;//TSO
	private String deltatype;//TSO
	private BigDecimal pricestep;//TSO
	private BigDecimal minmaxprice;//TSO
	private BigDecimal deltavalue;//TSO
	private BigDecimal orderprice;//STO
	private String pricetype;//SEO
	private String devide_type;//SO
	private Long qtty_size;//SO
	private int time_period;//SO
	private int time_delta;//SO
	private String side2;//voi lenh OTO, P: take profit, L : cut loss
	private Long qtty2;
	private BigDecimal price2;
	private String symbol2;
	private long divideTime; //cho lenh SO
	private String broker; //Y: cho phep broker nhin duoc lenh. N: khong cho phep
	
	//voi lenh MCO,
	private String condition1;
	private String operation1;
	private int value1;
	private boolean conditionStatus1 = false;
	private String condition2;
	private String operation2;
	private int value2;
	private boolean conditionStatus2 = false;
	private String condition3;
	private String operation3;
	private int value3;
	private boolean conditionStatus3 = false;
	private String condition4;
	private String operation4;
	private int value4;
	private boolean conditionStatus4 = false;
	
	public String getQuoteid() {
		return quoteid;
	}
	public void setQuoteid(String quoteid) {
		this.quoteid = quoteid;
	}
	public Date getCreateddt() {
		return createddt;
	}
	public void setCreateddt(Date createddt) {
		this.createddt = createddt;
	}
	public Date getExpireddt() {
		return expireddt;
	}
	public void setExpireddt(Date expireddt) {
		this.expireddt = expireddt;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getClasscd() {
		return classcd;
	}
	public void setClasscd(String classcd) {
		this.classcd = classcd;
	}
	public String getSubclass() {
		return subclass;
	}
	public void setSubclass(String subclass) {
		this.subclass = subclass;
	}
	public String getVia() {
		return via;
	}
	public void setVia(String via) {
		this.via = via;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSubstatus() {
		return substatus;
	}
	public void setSubstatus(String substatus) {
		this.substatus = substatus;
	}
	public Serializable getTimeQuote() {
		return timeQuote;
	}
	public void setTimeQuote(Serializable timeQuote) {
		this.timeQuote = timeQuote;
	}
	public Serializable getTimeSend() {
		return timeSend;
	}
	public void setTimeSend(Serializable timeSend) {
		this.timeSend = timeSend;
	}
	public String getTypecd() {
		return typecd;
	}
	public void setTypecd(String typecd) {
		this.typecd = typecd;
	}
	public String getSubtypecd() {
		return subtypecd;
	}
	public void setSubtypecd(String subtypecd) {
		this.subtypecd = subtypecd;
	}
	public String getSide() {
		return side;
	}
	public void setSide(String side) {
		this.side = side;
	}
	public String getRefquoteid() {
		return refquoteid;
	}
	public void setRefquoteid(String refquoteid) {
		this.refquoteid = refquoteid;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public Long getQtty() {
		return qtty;
	}
	public void setQtty(Long qtty) {
		this.qtty = qtty;
	}
	public Long getQttyBased() {
		return qttyBased;
	}
	public void setQttyBased(Long qttyBased) {
		this.qttyBased = qttyBased;
	}
	public Long getQttyDelta() {
		return qttyDelta;
	}
	public void setQttyDelta(Long qttyDelta) {
		this.qttyDelta = qttyDelta;
	}
	public Long getQttyCancel() {
		return qttyCancel;
	}
	public void setQttyCancel(Long qttyCancel) {
		this.qttyCancel = qttyCancel;
	}
	public Long getQttyAdmend() {
		return qttyAdmend;
	}
	public void setQttyAdmend(Long qttyAdmend) {
		this.qttyAdmend = qttyAdmend;
	}
	public Character getDistributecd() {
		return distributecd;
	}
	public void setDistributecd(Character distributecd) {
		this.distributecd = distributecd;
	}
	public String getAcctno() {
		return acctno;
	}
	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	public BigDecimal getPriceRf() {
		return priceRf;
	}
	public void setPriceRf(BigDecimal priceRf) {
		this.priceRf = priceRf;
	}
	public BigDecimal getPriceCe() {
		return priceCe;
	}
	public void setPriceCe(BigDecimal priceCe) {
		this.priceCe = priceCe;
	}
	public BigDecimal getPriceFl() {
		return priceFl;
	}
	public void setPriceFl(BigDecimal priceFl) {
		this.priceFl = priceFl;
	}
	public BigDecimal getPricedelta() {
		return pricedelta;
	}
	public void setPricedelta(BigDecimal pricedelta) {
		this.pricedelta = pricedelta;
	}
	public BigDecimal getExecAmt() {
		return execAmt;
	}
	public void setExecAmt(BigDecimal execAmt) {
		this.execAmt = execAmt;
	}
	public BigDecimal getExecQtty() {
		return execQtty;
	}
	public void setExecQtty(BigDecimal execQtty) {
		this.execQtty = execQtty;
	}
	public Serializable getLastchange() {
		return lastchange;
	}
	public void setLastchange(Serializable lastchange) {
		this.lastchange = lastchange;
	}
	public String getReforderid() {
		return reforderid;
	}
	public void setReforderid(String reforderid) {
		this.reforderid = reforderid;
	}
	public String getSessionex() {
		return sessionex;
	}
	public void setSessionex(String sessionex) {
		this.sessionex = sessionex;
	}
	public String getRefSessionex() {
		return refSessionex;
	}
	public void setRefSessionex(String refSessionex) {
		this.refSessionex = refSessionex;
	}
	public String getReftype() {
		return reftype;
	}
	public void setReftype(String reftype) {
		this.reftype = reftype;
	}
	public String getBook() {
		return book;
	}
	public void setBook(String book) {
		this.book = book;
	}
	public String getOrderid() {
		return orderid;
	}
	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}
	public String getSubside() {
		return subside;
	}
	public void setSubside(String subside) {
		this.subside = subside;
	}
	public String getFirm() {
		return firm;
	}
	public void setFirm(String firm) {
		this.firm = firm;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getTraderid() {
		return traderid;
	}
	public void setTraderid(String traderid) {
		this.traderid = traderid;
	}
	public String getContraacctno() {
		return contraacctno;
	}
	public void setContraacctno(String contraacctno) {
		this.contraacctno = contraacctno;
	}
	public String getBuyacctno() {
		return buyacctno;
	}
	public void setBuyacctno(String buyacctno) {
		this.buyacctno = buyacctno;
	}
	public String getSellacctno() {
		return sellacctno;
	}
	public void setSellacctno(String sellacctno) {
		this.sellacctno = sellacctno;
	}
	public String getCrossnumber() {
		return crossnumber;
	}
	public void setCrossnumber(String crossnumber) {
		this.crossnumber = crossnumber;
	}
	public String getAdvFlag() {
		return advFlag;
	}
	public void setAdvFlag(String advFlag) {
		this.advFlag = advFlag;
	}
	public String getRequestid() {
		return requestid;
	}
	public void setRequestid(String requestid) {
		this.requestid = requestid;
	}
	public int getClearday() {
		return clearday;
	}
	public void setClearday(int clearday) {
		this.clearday = clearday;
	}
	public String getOrdertype() {
		return ordertype;
	}
	public void setOrdertype(String ordertype) {
		this.ordertype = ordertype;
	}
	
	public BigDecimal getOrderprice() {
		return orderprice;
	}
	public void setOrderprice(BigDecimal orderprice) {
		this.orderprice = orderprice;
	}
	public String getPricetype() {
		return pricetype;
	}
	public void setPricetype(String pricetype) {
		this.pricetype = pricetype;
	}
	public String getDevide_type() {
		return devide_type;
	}
	public void setDevide_type(String devide_type) {
		this.devide_type = devide_type;
	}
	public Long getQtty_size() {
		return qtty_size;
	}
	public void setQtty_size(Long qtty_size) {
		this.qtty_size = qtty_size;
	}
	public int getTime_period() {
		return time_period;
	}
	public void setTime_period(int time_period) {
		this.time_period = time_period;
	}
	public int getTime_delta() {
		return time_delta;
	}
	public void setTime_delta(int time_delta) {
		this.time_delta = time_delta;
	}
	public String getSide2() {
		return side2;
	}
	public void setSide2(String side2) {
		this.side2 = side2;
	}
	public Long getQtty2() {
		return qtty2;
	}
	public void setQtty2(Long qtty2) {
		this.qtty2 = qtty2;
	}
	public BigDecimal getPrice2() {
		return price2;
	}
	public void setPrice2(BigDecimal price2) {
		this.price2 = price2;
	}
	public String getSymbol2() {
		return symbol2;
	}
	public void setSymbol2(String symbol2) {
		this.symbol2 = symbol2;
	}
	public long getDivideTime() {
		return divideTime;
	}
	public void setDivideTime(long divideTime) {
		this.divideTime = divideTime;
	}
	public String getDeltatype() {
		return deltatype;
	}
	public void setDeltatype(String deltatype) {
		this.deltatype = deltatype;
	}
	public BigDecimal getPricestep() {
		return pricestep;
	}
	public void setPricestep(BigDecimal pricestep) {
		this.pricestep = pricestep;
	}
	public BigDecimal getMinmaxprice() {
		return minmaxprice;
	}
	public void setMinmaxprice(BigDecimal minmaxprice) {
		this.minmaxprice = minmaxprice;
	}
	public BigDecimal getDeltavalue() {
		return deltavalue;
	}
	public void setDeltavalue(BigDecimal deltavalue) {
		this.deltavalue = deltavalue;
	}
	public String getBroker() {
		return broker;
	}
	public void setBroker(String broker) {
		this.broker = broker;
	}
	public String getCondition1() {
		return condition1;
	}
	public void setCondition1(String condition1) {
		this.condition1 = condition1;
	}
	public String getOperation1() {
		return operation1;
	}
	public void setOperation1(String operation1) {
		this.operation1 = operation1;
	}
	public int getValue1() {
		return value1;
	}
	public void setValue1(int value1) {
		this.value1 = value1;
	}
	public String getCondition2() {
		return condition2;
	}
	public void setCondition2(String condition2) {
		this.condition2 = condition2;
	}
	public String getOperation2() {
		return operation2;
	}
	public void setOperation2(String operation2) {
		this.operation2 = operation2;
	}
	public int getValue2() {
		return value2;
	}
	public void setValue2(int value2) {
		this.value2 = value2;
	}
	public String getCondition3() {
		return condition3;
	}
	public void setCondition3(String condition3) {
		this.condition3 = condition3;
	}
	public String getOperation3() {
		return operation3;
	}
	public void setOperation3(String operation3) {
		this.operation3 = operation3;
	}
	public int getValue3() {
		return value3;
	}
	public void setValue3(int value3) {
		this.value3 = value3;
	}
	public String getCondition4() {
		return condition4;
	}
	public void setCondition4(String condition4) {
		this.condition4 = condition4;
	}
	public String getOperation4() {
		return operation4;
	}
	public void setOperation4(String operation4) {
		this.operation4 = operation4;
	}
	public int getValue4() {
		return value4;
	}
	public void setValue4(int value4) {
		this.value4 = value4;
	}

	
	public boolean isConditionStatus1() {
		return conditionStatus1;
	}
	public void setConditionStatus1(boolean conditionStatus1) {
		this.conditionStatus1 = conditionStatus1;
	}
	public boolean isConditionStatus2() {
		return conditionStatus2;
	}
	public void setConditionStatus2(boolean conditionStatus2) {
		this.conditionStatus2 = conditionStatus2;
	}
	public boolean isConditionStatus3() {
		return conditionStatus3;
	}
	public void setConditionStatus3(boolean conditionStatus3) {
		this.conditionStatus3 = conditionStatus3;
	}
	public boolean isConditionStatus4() {
		return conditionStatus4;
	}
	public void setConditionStatus4(boolean conditionStatus4) {
		this.conditionStatus4 = conditionStatus4;
	}
	@Override
	public String toString() {
		return "Quote [quoteid=" + quoteid + ", createddt=" + createddt + ", expireddt=" + expireddt + ", userid=" + userid + ", classcd=" + classcd + ", via=" + via + ", status=" + status + ", substatus=" + substatus + ", typecd=" + typecd + ", subtypecd=" + subtypecd + ", side=" + side + ", symbol=" + symbol + ", qtty=" + qtty
				+ ", acctno=" + acctno + ", price=" + price + ", pricedelta=" + pricedelta + ", book=" + book
				+ ", orderid=" + orderid + ", subside=" + subside + ", requestid=" + requestid + "]";
	}
	
	
}
