package com.noname.itrust.gate.common;

public class CommonConstants {

	public static final String JMS_MESSAGE_NAME = "topic.JMS_MESSAGE";
	public static final String JMS_MESSAGE_REQUEST_NAME = "queue.JMS_MESSAGE_REQUEST";
	public static final String JMS_MESSAGE_RESPONSE_NAME = "queue.JMS_MESSAGE_RESPONSE";
	
	public static final String ORDER_STATUS_ACTIVING = "I";
	public static final String ORDER_STATUS_ACTIVED = "F";
	public static final String ORDER_STATUS_EXPIRE = "E";
	public static final String ORDER_STATUS_NEW = "N";

}
