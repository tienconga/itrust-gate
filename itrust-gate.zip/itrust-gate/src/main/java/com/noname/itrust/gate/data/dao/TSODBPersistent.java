package com.noname.itrust.gate.data.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.sql.SQLStatement;


public class TSODBPersistent {
	
	public void updateTSOOrder(Quote quote, String status, BigDecimal activePrice) {
		Connection conn = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
        	String sql = "UPDATE TSO SET STATUS = 'F',ACTIVEPRICE=? WHERE QUOTEID=?"; 
        	ps = conn.prepareStatement(sql);
        	ps.setBigDecimal(1, activePrice);
        	ps.setString(2, quote.getQuoteid());
        	
        	SLF4JLoggerProxy.info(this, "UPDATE TSO SET STATUS = 'F',ACTIVEPRICE="+quote.getPrice()+" WHERE QUOTEID="+quote.getQuoteid()+"");
        	ps.executeUpdate();
			
        	if(status != null && status.equalsIgnoreCase("F")){
        		String sqlQuote = "UPDATE QUOTES SET STATUS = '" + status + "',  SUBSTATUS = '" + status + "' WHERE QUOTEID=?";
        		ps = conn.prepareStatement(sqlQuote);
            	ps.setString(1, quote.getQuoteid());
            	ps.executeUpdate();
        	}
        	
			conn.commit();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
				
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}

	}
	
	public void insertTSO(Quote quote, BigDecimal fx1price, String status) {
		Connection conn = null;   
        ConnectionManager mgr = new ConnectionManager();
        CallableStatement callableStatement = null; 
        String log = "";
        String p_err_code = "After execute:";
        try {
        	conn = mgr.getConnection();
			callableStatement = conn.prepareCall(ConnectionManager.sqlMap.get(SQLStatement.KEY_INSERT_TSO));
			callableStatement.registerOutParameter(1, Types.VARCHAR);// p_err_code
			callableStatement.setString(2, quote.getQuoteid()); // p_quoteid
			callableStatement.setString(3, quote.getAcctno());// p_acctno :
			callableStatement.setString(4, quote.getSymbol());// p_symbol
			callableStatement.setString(5, quote.getOrdertype());// p_ordertype
			callableStatement.setBigDecimal(6, quote.getDeltavalue());// /p_deltavalue
			callableStatement.setBigDecimal(7, quote.getMinmaxprice());// /p_minmaxprice
			
			callableStatement.setDate(8, new java.sql.Date(quote.getCreateddt().getTime()));// p_fromdate
			callableStatement.setDate(9, new java.sql.Date(quote.getExpireddt().getTime()));// p_todate
			callableStatement.setBigDecimal(10, fx1price);//p_fx1price
			callableStatement.setString(11, status); // p_status
			callableStatement.setBigDecimal(12, quote.getPricestep());//p_pricestep
			callableStatement.setString(13, quote.getDeltatype()); // p_deltatype
			callableStatement.setString(14,quote.getBroker()); // p_broker

			log = "store parametter -|  CSPKS_HFT_SAVE_NEW.sp_create_tso_orders |  p_quoteid: " + quote.getQuoteid()
			+ "|  p_acctno: " + quote.getAcctno() + "|  p_symbol: " + quote.getSymbol()
			+ "|  p_ordertype: " + quote.getOrdertype() + " |  p_deltavalue: " + quote.getDeltavalue()
			+ "|  p_minmaxprice: " + quote.getMinmaxprice() + " |  p_fromdate: " + quote.getCreateddt()
			+ "|  p_todate: " + quote.getExpireddt() + "|  p_fx1price: " + fx1price + "|  p_status: " + status
			+ "|  p_pricestep: " + quote.getPricestep() + "|  p_deltatype: " + quote.getDeltatype()
			+ "|  p_broker: " + quote.getBroker();
			
			SLF4JLoggerProxy.info(this, log);
			callableStatement.execute();
			p_err_code = callableStatement.getString(1);
			conn.commit();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if (callableStatement != null) {
					callableStatement.clearParameters();
					callableStatement.close();
					callableStatement = null;
				}
			} catch (SQLException e) {
				SLF4JLoggerProxy.info(this,e);
			}
			mgr.closeConnection(conn);			
			SLF4JLoggerProxy.info(this, p_err_code);
		}
	}
	
	
	public void updateFX1TSO(String quoteid, BigDecimal price) {
		Connection conn = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
        	String sql = "UPDATE TSO SET FX1PRICE = ? WHERE QUOTEID=?"; 
        	ps = conn.prepareStatement(sql);
        	ps.setBigDecimal(1, price);
        	ps.setString(2, quoteid);
        	
        	ps.executeUpdate();
			SLF4JLoggerProxy.info(this, "UPDATE TSO SET FX1PRICE = " + price + " WHERE QUOTEID="+quoteid+"");
			
			conn.commit();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
				
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}
	}
}
