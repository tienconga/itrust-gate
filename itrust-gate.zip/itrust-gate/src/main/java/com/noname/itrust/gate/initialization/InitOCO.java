package com.noname.itrust.gate.initialization;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import org.springframework.stereotype.Service;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.sql.SQLStatement;

@Service
public class InitOCO {

	/**
	 * init OCO orders
	 */
	public void initOCO(){
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
	        ps = conn.prepareStatement(ConnectionManager.sqlMap.get(SQLStatement.KEY_SEL_OCO));
	        rs = ps.executeQuery();
		   
	        while(rs.next()){
	        	String quoteid = rs.getString("QUOTEID");
	        	String acctno = rs.getString("ACCTNO");
	        	String symbol = rs.getString("SYMBOL1");
	        	Long qtty = rs.getLong("QTTY1");
	        	BigDecimal price = rs.getBigDecimal("PRICE1");
	        	String side = rs.getString("SIDE1");
	        	String symbol2 = rs.getString("SYMBOL2");
	        	Long qtty2 = rs.getLong("QTTY2");
	        	BigDecimal price2 = rs.getBigDecimal("PRICE2");
	        	String side2 = rs.getString("SIDE2");
	        	String status = rs.getString("STATUS");
	        	Date fromdate = rs.getDate("FROMDATE");
	        	Date todate = rs.getDate("TODATE");
	        	String userid = rs.getString("USERID");
	        	String typecd = rs.getString("TYPECD");
	        	
	        	Quote ocoOrder = new Quote();
	        	ocoOrder.setQuoteid(quoteid);
	        	ocoOrder.setAcctno(acctno);
	        	ocoOrder.setSymbol(symbol);
	        	ocoOrder.setQtty(qtty);
	        	ocoOrder.setPrice(price);
	        	ocoOrder.setSide(side);
	        	ocoOrder.setSymbol2(symbol2);
	        	ocoOrder.setQtty2(qtty2);
	        	ocoOrder.setPrice2(price2);
	        	ocoOrder.setSide2(side2);
	        	ocoOrder.setStatus(status);
	        	ocoOrder.setCreateddt(fromdate);
	        	ocoOrder.setExpireddt(todate);
	        	ocoOrder.setUserid(userid);
	        	ocoOrder.setTypecd(typecd);
	        	
	        	ocoOrder.setClasscd("OCO");
	        	
	        	HandlerCacheData.ocoMap.put(quoteid, ocoOrder);
	        					
	        }
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}
	}
}
