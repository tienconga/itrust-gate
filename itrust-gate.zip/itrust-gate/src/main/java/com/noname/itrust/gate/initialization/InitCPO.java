package com.noname.itrust.gate.initialization;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.stereotype.Service;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.sql.SQLStatement;

@Service
public class InitCPO {

	/**
	 * init CPO orders
	 */
	public void initCPO(){
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
	        ps = conn.prepareStatement(ConnectionManager.sqlMap.get(SQLStatement.KEY_SEL_CPO));
	        rs = ps.executeQuery();
		   
	        while(rs.next()){
	        	
	        	String quoteid = rs.getString("QUOTEID");
	        	String acctno = rs.getString("ACCTNO");
	        	String reforderid = rs.getString("REFORDERID");
	        	String symbol = rs.getString("SYMBOL");
	        	Long qtty = rs.getLong("QTTY");
	        	String side = rs.getString("SIDE");
	        	BigDecimal price = rs.getBigDecimal("PRICE");
	        	String status = rs.getString("STATUS");
	        	String userid = rs.getString("USERID");
	        	String typecd = rs.getString("TYPECD");
	        	
	        	Quote cpoOrder = new Quote();
	        	cpoOrder.setQuoteid(quoteid);
	        	cpoOrder.setAcctno(acctno);
	        	cpoOrder.setReforderid(reforderid);
	        	cpoOrder.setSymbol(symbol);
	        	cpoOrder.setQtty(qtty);
	        	cpoOrder.setSide(side);
	        	cpoOrder.setPrice(price);
	        	cpoOrder.setStatus(status);
	        	cpoOrder.setUserid(userid);
	        	cpoOrder.setTypecd(typecd);

	        	cpoOrder.setClasscd("CPO");
	        	
	        	HandlerCacheData.cpoMap.put(quoteid, cpoOrder);
	        	/*Map<String, Quote> orderInfos = HandlerCacheData.cpoMap.get(symbol);
				if(orderInfos == null){//chua co ma chung khoan nay trong he thong
					orderInfos = new HashMap<String, Quote>();
					orderInfos.put(quoteid, cpoOrder);
					HandlerCacheData.cpoMap.put(symbol, orderInfos);
				}else{//da ton tai ma chung khoan nay
					orderInfos.put(quoteid, cpoOrder);
				}*/				
	        }
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}
	}
}
