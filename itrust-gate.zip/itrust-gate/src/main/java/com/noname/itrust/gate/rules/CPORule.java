package com.noname.itrust.gate.rules;

import java.util.concurrent.LinkedBlockingQueue;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.common.CommonConstants;
import com.noname.itrust.gate.data.dao.DAOCommon;
import com.noname.itrust.gate.model.ISignal;
import com.noname.itrust.gate.sending.CancelOrderSending;
import com.noname.itrust.gate.thread.TicketQueue;

public class CPORule implements IRules {

	private LinkedBlockingQueue<Quote> queue;
	
	@Override
	public void process(ISignal market,Quote quote) {
		// TODO Auto-generated method stub
	}

	@Override
	public void putRequest(Quote quote) {
		// TODO Auto-generated method stub

	}

	@Override
	public void load() {
		// TODO Auto-generated method stub

	}

	
	public void cancelOrder(Quote quote){
		CancelOrderSending cancelObj = new CancelOrderSending();
		
		Quote newquote = new Quote();
		newquote.setQuoteid(quote.getQuoteid());
		newquote.setMsgtype(quote.getMsgtype());
		newquote.setRequestid(quote.getRequestid());
		newquote.setAcctno(quote.getAcctno());
		newquote.setOrderid(quote.getReforderid());
		newquote.setUserid(quote.getUserid());
		newquote.setVia(quote.getVia());
		newquote.setClasscd(quote.getClasscd());
		
		cancelObj.cancelOrder(newquote,"");
	}
	
	public void placeNewOrder(String quoteid){
		Quote quote = HandlerCacheData.cpoMap.get(quoteid);
		
		if(null != quote){
			//active order
			activeOrder(quote);
		}
	}
	
	
	private void activeOrder(Quote quote){
		//kich hoat lenh
		SLF4JLoggerProxy.info(this,"Active CPO Order ***** quoteid:" + quote.getQuoteid());
		try {
			TicketQueue queThread = TicketQueue.getTicketQueueThread();
			queue = queThread.getTicketqueue();
			queue.put(quote);
		} catch (InterruptedException e) {
			SLF4JLoggerProxy.error(this, "Error when active CPO Order ***** quoteid:" + quote.getQuoteid() + "," + e);
		}
		
		//xoa khoi orders list
		HandlerCacheData.cpoMap.remove(quote.getQuoteid());
		
		//syn to DB
		DAOCommon obj = new DAOCommon();
		obj.updateStatus(quote.getQuoteid(), CommonConstants.ORDER_STATUS_ACTIVING,"CPO");
	}
}
