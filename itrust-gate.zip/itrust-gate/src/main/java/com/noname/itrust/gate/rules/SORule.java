package com.noname.itrust.gate.rules;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.CacheProcessing;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.common.CommonConstants;
import com.noname.itrust.gate.common.SessionChecker;
import com.noname.itrust.gate.data.dao.DAOCommon;
import com.noname.itrust.gate.model.ISignal;
import com.noname.itrust.gate.thread.TicketQueue;

public class SORule implements IRules {

	private LinkedBlockingQueue<Quote> queue;
	
	@Override
	public void process(ISignal market,Quote quote) {
		// TODO Auto-generated method stub

	}

	@Override
	public void putRequest(Quote quote) {
		// TODO Auto-generated method stub

	}

	@Override
	public void load() {
		// TODO Auto-generated method stub

	}

	
	public void placeOrder(Quote quote, boolean removeFlag){	
		try{
			String sessionFlag = SessionChecker.checkSessionSOOrder(quote.getSymbol());
			if(sessionFlag != null && sessionFlag.equalsIgnoreCase("E")){//phien thoa thuan va ket thuc phien
				DAOCommon obj = new DAOCommon();
				obj.updateStatus(quote.getQuoteid(), "E","SO");
				SLF4JLoggerProxy.error(this,"SO Order Error, Sesion invalid ========quoteid:" + quote.getQuoteid());
				return;
			}else if(sessionFlag != null && sessionFlag.equalsIgnoreCase("W")){//truoc phien
				if(quote.getDevide_type() != null && quote.getDevide_type().equalsIgnoreCase("A")){
					HandlerCacheData.soMap.put(quote.getQuoteid(), quote);
				}else if(quote.getDevide_type() != null && quote.getDevide_type().equalsIgnoreCase("T")){
					splitOrder2(quote,"W");
				}else if(quote.getDevide_type() != null && quote.getDevide_type().equalsIgnoreCase("D")){
					HandlerCacheData.soMap.put(quote.getQuoteid(), quote);
				}
			}else {//trong phien
				if(quote.getDevide_type() != null && quote.getDevide_type().equalsIgnoreCase("A")){
					HandlerCacheData.soMap.put(quote.getQuoteid(), quote);
					splitOrder1(quote, removeFlag);
				}else if(quote.getDevide_type() != null && quote.getDevide_type().equalsIgnoreCase("T")){
					splitOrder2(quote, "N");
				}else if(quote.getDevide_type() != null && quote.getDevide_type().equalsIgnoreCase("D")){
					HandlerCacheData.soMap.put(quote.getQuoteid(), quote);
					splitOrder3(quote, removeFlag, true);
				}
			}
		}catch (CloneNotSupportedException e) {
			SLF4JLoggerProxy.error(this,"Devide  SO Order Error ========quoteid:" + quote.getQuoteid());
		}
	}
	
	/**
	 * @decription chia tat ca 1 lan
	 * @param quote
	 * @throws CloneNotSupportedException 
	 */
	private void splitOrder1(Quote quote, boolean removeFlag) throws CloneNotSupportedException{
		long qttySum = quote.getQtty();
		long qtty_size = quote.getQtty_size();
		long qtty_delta = quote.getQttyDelta();
		BigDecimal price_delta = quote.getPricedelta();
		
		if(qtty_size == 0 ||  qttySum <= qtty_size){
			activeOrder(quote);
			DAOCommon obj = new DAOCommon();
			obj.updateStatus(quote.getQuoteid(), CommonConstants.ORDER_STATUS_ACTIVING,"SO");
			
			//remove from orders list
			if(removeFlag){
				HandlerCacheData.soMap.remove(quote.getQuoteid());
			} 	
		}else{
			while(qttySum > 0){
				//1.tinh khoi luong dat lenh
				long newQtty = getNewQtty(qttySum,qtty_size,qtty_delta);	
														
				if(newQtty <= qttySum){
					qttySum = qttySum - newQtty;
				}else {
					newQtty = qttySum;
					qttySum = 0;			
				}
				
				if(newQtty > 0){
					//2.tinh gia dat lenh
					BigDecimal newPrice = getNewPrice(quote.getSymbol(), quote.getPrice(), price_delta);
									
					//dat lenh
					Quote newQuote = new Quote();
					newQuote = (Quote) quote.clone();
					newQuote.setQtty(newQtty);
					if(newPrice.compareTo(new BigDecimal(0)) == 1){
						newQuote.setPrice(newPrice);
					}
					
					activeOrder(newQuote);
				}
				
				
				if(qttySum == 0){
					//syn to DB
					DAOCommon obj = new DAOCommon();
					obj.updateStatus(quote.getQuoteid(), CommonConstants.ORDER_STATUS_ACTIVING,"SO");
					
					//remove from orders list
					if(removeFlag){
						HandlerCacheData.soMap.remove(quote.getQuoteid());
					} 
				}
			}
		}
	}
	
	/**
	 * 
	 * @decription chia lenh sau khoang thoi gian
	 * @param quote
	 * @throws CloneNotSupportedException 
	 */
	private void splitOrder2(Quote quote, String firstFlag) throws CloneNotSupportedException{
		synchronized (HandlerCacheData.soTypeTMap) {
			
			if(firstFlag.equalsIgnoreCase("W")){//chua dung phien
				long begintime = System.currentTimeMillis();
				quote.setDivideTime(begintime);
				HandlerCacheData.soTypeTMap.put(quote.getQuoteid(), quote);
			}else{//vao phien chia ngay
				//active immediate (first)
				Quote firtsQuote = (Quote) quote.clone();
				long qtty_size = firtsQuote.getQtty_size();
				long qtty_sum = firtsQuote.getQtty();
				qtty_sum = qtty_sum - qtty_size;
				firtsQuote.setQtty(qtty_size);
				activeOrder(firtsQuote);
				
				//remain
				long begintime = System.currentTimeMillis();
				quote.setDivideTime(begintime);
				quote.setQtty(qtty_sum);
				HandlerCacheData.soTypeTMap.put(quote.getQuoteid(), quote);
			}
			
		}		
	}
		
	/**
	 * 
	 * @decription sau khi khop ve
	 * @param quote
	 */
	private void splitOrder3(Quote quote, boolean removeFlag, boolean updateFlag) throws CloneNotSupportedException{
		//active lenh dau tien
		long qtty_size = quote.getQtty_size();
		Quote newQuote = new Quote();
		newQuote = (Quote) quote.clone();
		
		Quote oldQuote = HandlerCacheData.soMap.get(quote.getQuoteid());
		
		if(oldQuote.getQtty() <= 0){
			SLF4JLoggerProxy.info(this,"Finnished divide SO order:==========quoteid:" + quote.getQuoteid());
			if(removeFlag){
				HandlerCacheData.soMap.remove(quote.getQuoteid());
			} 
		}else{
			if(quote.getQtty() - qtty_size >= 0){
				long qttySum = quote.getQtty();
				long qtty_delta = quote.getQttyDelta();
				BigDecimal price_delta = quote.getPricedelta();
				
				//1.tinh khoi luong dat lenh
				long newQtty = getNewQtty(qttySum,qtty_size,qtty_delta);	
														
				//2.tinh gia dat lenh
				BigDecimal newPrice = getNewPrice(quote.getSymbol(), quote.getPrice(), price_delta);
						
				newQuote.setPrice(newPrice);
				newQuote.setQtty(newQtty);
								
				//update quote
				oldQuote.setQtty(quote.getQtty() - newQtty);
			}else{
				oldQuote.setQtty(new Long(0)); //phan con lai cua lenh
			}
			
			activeOrder(newQuote);
			
			//syn to DB
			if(updateFlag){
				DAOCommon obj = new DAOCommon();
				obj.updateStatus(quote.getQuoteid(), CommonConstants.ORDER_STATUS_ACTIVING,"SO");
			}
			
			if(oldQuote.getQtty() == 0){
				//remove from orders list
				if(removeFlag){
					HandlerCacheData.soMap.remove(quote.getQuoteid());
				} 				
			}
		}
		
	}
	
	public void divideOrder_type_D(String quoteid) throws CloneNotSupportedException{
		Quote quote = HandlerCacheData.soMap.get(quoteid);
		if(quote != null){
			splitOrder3(quote, true, false);
		}else{
			SLF4JLoggerProxy.info(this,"Counld not active null order========quoteid:" + quoteid);
		}
		
	}
	
	public void divideOrder_type_T() {
		try {
			List<String> removelist = new ArrayList<String>();
			synchronized (HandlerCacheData.soTypeTMap) {
				Set<Entry<String,Quote>> set = HandlerCacheData.soTypeTMap.entrySet();
				Iterator<Entry<String,Quote>> it = set.iterator();
				while(it.hasNext()){
					 Entry<String,Quote> entry = it.next();
					 Quote quote = entry.getValue();
					 
					 String symbol = quote.getSymbol();
					 if(!SessionChecker.checkSessionSOOrder_T(symbol)){ //check session
						 SLF4JLoggerProxy.info(this,"Pending Divide SO order, orderid: " + quote.getOrderid() + "," +
						 		" HSX Session:" + HandlerCacheData.hsxSession + "," +
						 		" HNX Session:" + HandlerCacheData.hnxSession + "," +
						 		" UPCOM Session:" + HandlerCacheData.upcomSession);
						 continue;
					 }
					 
					 long divideTime = quote.getDivideTime();
					 long begintime = System.currentTimeMillis();
					 int time_period = quote.getTime_period();
					 int time_delta = quote.getTime_delta();
					 
					 int newPeriod = getPeriod(time_period,time_delta);
					 
					 long seconds = TimeUnit.MILLISECONDS.toSeconds(begintime - divideTime);
					 if(seconds - newPeriod >= 0){
						//chia lenh
						SLF4JLoggerProxy.info(this,"Divide SO order, orderid: " + quote.getOrderid() + ", qttySum:" + quote.getQtty());
						Quote newQuote = new Quote();
						newQuote = (Quote) quote.clone();
						 
						long qtty_size = quote.getQtty_size();
						 
						if(quote.getQtty() <= 0){
							SLF4JLoggerProxy.info(this,"Finnished divide SO order:==========quoteid:" + quote.getQuoteid());							 
							removelist.add(quote.getQuoteid());
						}else{
							if(quote.getQtty() - qtty_size >= 0){
								long qttySum = quote.getQtty();
								long qtty_delta = quote.getQttyDelta();
								BigDecimal price_delta = quote.getPricedelta();
																		
								//1.tinh khoi luong dat lenh
								long newQtty = getNewQtty(qttySum,qtty_size,qtty_delta);	
																		
								//2.tinh gia dat lenh
								BigDecimal newPrice = getNewPrice(quote.getSymbol(), quote.getPrice(), price_delta);
																
								newQuote.setPrice(newPrice);
								newQuote.setQtty(newQtty);
								
								//update quote
								quote.setQtty(quote.getQtty() - newQtty);
							}else{
								quote.setQtty(new Long(0)); //phan con lai cua lenh
								//syn to DB
								//DAOCommon obj = new DAOCommon();
								//obj.updateStatus(quote.getQuoteid(), CommonConstants.ORDER_STATUS_ACTIVING,"SO");	
							}
							
							activeOrder(newQuote);
							 //reset time
							 quote.setDivideTime(begintime);
						}
					 }
				}
			}	
						
			//remove
			for(int i = 0; i < removelist.size(); i++){
				String quoteid = removelist.get(i);
				HandlerCacheData.soTypeTMap.remove(quoteid);
			}
		} catch (CloneNotSupportedException e) {
			SLF4JLoggerProxy.error(this, e);
		}
	}
	
	private void activeOrder(Quote quote){
		//kich hoat lenh
		SLF4JLoggerProxy.info(this,"Active SO Order========quoteid:" + quote.getQuoteid());
		try {
			TicketQueue queThread = TicketQueue.getTicketQueueThread();
			queue = queThread.getTicketqueue();
			queue.put(quote);
		} catch (InterruptedException e) {
			SLF4JLoggerProxy.error(this, "Error when active SO Order========quoteid:" + quote.getQuoteid() + "," + e);
		}
	}
	
	private long getNewQtty(long qttySum, long qtty_size, long qtty_delta){
		Random rand = new Random();
		int randomNum = rand.nextInt((2 - 0) + 1) + 0;
		
		//1.tinh khoi luong dat lenh
		long newQtty = 0;
		if(randomNum == 0){
			newQtty = qtty_size + qtty_delta;
		}else if(randomNum == 1 ){
			newQtty = qtty_size - qtty_delta;
		}else{
			newQtty = qtty_size;
		}
		
		if(newQtty >= qttySum || newQtty < 0){
			newQtty = qttySum;	
		}
		
		return newQtty;
	}
	
	private BigDecimal getNewPrice(String symbol, BigDecimal price, BigDecimal price_delta){
		BigDecimal newPrice = new BigDecimal(0);
		BigDecimal price_ce = CacheProcessing.InstrumentMap.get(symbol).getPriceCE();
		BigDecimal price_fl = CacheProcessing.InstrumentMap.get(symbol).getPriceFL();
		
		if(price_delta != null){
			Random rand2 = new Random();
			int randomNum2 = rand2.nextInt((2 - 0) + 1) + 0;
			if(randomNum2 == 0){
				newPrice = price.add(price_delta);
				if(newPrice.compareTo(price_ce) == 1){//lon hon gia tran
					newPrice = price_ce;
				}
			}else if(randomNum2 == 1){
				newPrice = price.subtract((price_delta));
				if(newPrice.compareTo(price_fl) == -1){//nho hon gia san
					newPrice = price_fl;
				}
			}else{
				newPrice =  price;
			}
		}
		
		return newPrice;
	}
	
	private int getPeriod(int time_period, int time_delta){		
		int newPeriod = 0;
		Random rand = new Random();
		int randomNum = rand.nextInt((2 - 0) + 1) + 0;
		if(randomNum == 0){
			newPeriod = time_period + time_delta;
		}else if(randomNum == 1){
			newPeriod = time_period - time_delta;
		}else{
			newPeriod =  time_period;
		}

		return newPeriod;
	}
	
	public synchronized void orderSession(){
		List<String> removeList = new ArrayList<String>();
		
		Set<Entry<String,Quote>> set2 = HandlerCacheData.soMap.entrySet();
		Iterator<Entry<String,Quote>> it2 = set2.iterator();
		while(it2.hasNext()){
			 Entry<String,Quote> entry2 = it2.next();
			 Quote quoteObj = entry2.getValue();
			 placeOrder(quoteObj, false); 
			 removeList.add(quoteObj.getQuoteid());
		}
		
		
		for(int i = 0; i < removeList.size(); i ++){
			String quoteid = removeList.get(i);
			HandlerCacheData.soMap.remove(quoteid);
		}
		
	}
	
}
