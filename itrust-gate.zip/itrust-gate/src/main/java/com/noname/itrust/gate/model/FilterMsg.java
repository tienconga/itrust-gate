package com.noname.itrust.gate.model;

public class FilterMsg {
	private String symbol;
	private String counttime;
	private int counttimeval;
	
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getCounttime() {
		return counttime;
	}
	public void setCounttime(String counttime) {
		this.counttime = counttime;
	}
	public int getCounttimeval() {
		return counttimeval;
	}
	public void setCounttimeval(int counttimeval) {
		this.counttimeval = counttimeval;
	}
	
	
}
