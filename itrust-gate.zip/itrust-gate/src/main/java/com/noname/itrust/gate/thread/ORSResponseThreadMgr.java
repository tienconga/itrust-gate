package com.noname.itrust.gate.thread;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.Logger;

import com.fss.newfo.common.model.ORSObject;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.ors.response.ORSResponse;

public class ORSResponseThreadMgr {

	final static Logger logger = Logger.getLogger(ORSResponseThreadMgr.class);

	private static volatile ORSResponseThreadMgr threadMgr;

	private ThreadPoolExecutor executor;

	public static final int DEFAULT_QUEUE_SIZE = 100000;

	public static void initThreadMgr(int size, long timeout, int queueSize) {
		threadMgr = new ORSResponseThreadMgr(size, timeout, queueSize);
	}

	public static ORSResponseThreadMgr getThreadMgr() {

		if (threadMgr == null) {
			threadMgr = new ORSResponseThreadMgr(5, 100, DEFAULT_QUEUE_SIZE);
		} else {
		}

		return threadMgr;
	}

	public ORSResponseThreadMgr(int size, long timeout, int queueSize) {
		BlockingQueue<Runnable> queue = (BlockingQueue<Runnable>) new ArrayBlockingQueue<Runnable>(queueSize);
		this.executor = new ThreadPoolExecutor(size, size, timeout, TimeUnit.MILLISECONDS, queue);
	}

	public int fireEmptyThread(ORSObject orsObject, ORSResponse oRSResponse) {

		try {
			ORSResponseThreadWork bWork = new ORSResponseThreadWork(orsObject, oRSResponse);
			this.executor.execute(bWork);
			return -1;
		} catch (RejectedExecutionException e) {
			SLF4JLoggerProxy.error(this, e);
			return 0;
		}
	}

}
