package com.noname.itrust.gate.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateTime {

	private static Date systemDate;
	
	
	public static Date getSystemDate() {
		return systemDate;
	}


	public static void setSystemDate(Date systemDate) {
		DateTime.systemDate = systemDate;
	}


	public static boolean isActive(Date fromDate){
		//SimpleDateFormat formatter1 = new SimpleDateFormat("dd/MM/yyyy");
		//SimpleDateFormat formatter2 = new SimpleDateFormat("dd/MM/yyyy"); //yyyy-MM-dd
		//Date date1 = formatter1.parse(fromDate.toString());
		//Date date2 = formatter2.parse(systemDate);
		
		if(fromDate == null || systemDate == null){
			return true;
		}
		
		Calendar fromCalendar = Calendar.getInstance();
		Calendar sysCalendar = Calendar.getInstance();

		fromCalendar.setTime(fromDate);
		fromCalendar.set(Calendar.HOUR_OF_DAY, 0);
		fromCalendar.set(Calendar.MINUTE, 0);
		fromCalendar.set(Calendar.SECOND, 0);
		fromCalendar.set(Calendar.MILLISECOND, 0);

		sysCalendar.setTime(systemDate);
		sysCalendar.set(Calendar.HOUR_OF_DAY, 0);
		sysCalendar.set(Calendar.MINUTE, 0);
		sysCalendar.set(Calendar.SECOND, 0);
		sysCalendar.set(Calendar.MILLISECOND, 0);
		
		if(fromCalendar.after(sysCalendar)){
    		return false;
    	}else{
    		return true;
    	}
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String dateInString = "29/04/2016";
		try {

			Date date = formatter.parse(dateInString);
			System.out.println(date);
			System.out.println(formatter.format(date));

		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		//isActive("2016-05-28");
		
	}

}
