package com.noname.itrust.gate.aq;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import org.apache.activemq.command.ActiveMQObjectMessage;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.fss.newfo.common.model.MarketInfo;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.common.ConfigLoader;
import com.noname.itrust.gate.rules.PCORule;

@Component
public class GWSessionListener implements MessageListener {

	final static Logger logger = Logger.getLogger(GWSessionListener.class);

	private Context context = null;
	private QueueConnectionFactory queueConnectionFactory = null;
	private QueueConnection queueConnection = null;
	private QueueSession queueSession = null;
	private Queue queue = null;;
	private MessageConsumer consumer = null;
	private String queueName = "";

	private boolean connectStatus = true;
	
	public GWSessionListener(String jmsProperties) {
		try {
			if (ConfigLoader.jmsProps == null) {
				ConfigLoader.loadProperties(jmsProperties,"RequestsListener");
			}
			
			connect();
		} catch (Exception e) {
			logger.error(e.getStackTrace());
		}
	}

	public GWSessionListener() {
	}

	public static void init() {
		GWSessionListener instance = new GWSessionListener();
		instance.connect();
	}

	/**
	 * 
	 * @throws JMSException
	 * @throws NamingException
	 */
	public void connect() {
		try {
			queueName = ConfigLoader.jmsProps.getProperty("queue.JMS_MESSAGE_ENGINE_EXCHANGE_SESSION");
			context = new InitialContext(ConfigLoader.jmsProps);
			queueConnectionFactory = (QueueConnectionFactory) context.lookup("QueueConnectionFactory");
			queueConnection = queueConnectionFactory.createQueueConnection("karaf", "karaf");
			queueSession = queueConnection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			queue = queueSession.createQueue(queueName);
			consumer = queueSession.createConsumer(queue);
			consumer.setMessageListener(this);
			queueConnection.start();
		} catch (Exception e) {
			connectStatus = false;
			e.printStackTrace();
			System.exit(1);
		}
	}

	public boolean connectStatus() {
		try {
			if ((connectStatus) && (queueConnection.getExceptionListener() != null))
				connectStatus = false;
		} catch (JMSException e) {
			connectStatus = false;
		}
		return connectStatus;
	}

	public void disconnect() {
		try {
			if (queueConnection != null) {
				queueConnection.stop();
				queueSession.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			queueConnection = null;
			queueSession = null;
		}
	}

	@Override
	public void onMessage(Message message) {
		if (message instanceof ActiveMQObjectMessage) {
			ActiveMQObjectMessage objMsg = (ActiveMQObjectMessage) message;
			try {
				Object obj = objMsg.getObject();
				if (obj instanceof MarketInfo) {
					MarketInfo marketinfo = (MarketInfo) obj;
					PCORule rule = new PCORule();
					rule.processSession(marketinfo);
				}
			
			} catch (Exception e) {
				SLF4JLoggerProxy.error(this, e);
			}
		}
	}
}
