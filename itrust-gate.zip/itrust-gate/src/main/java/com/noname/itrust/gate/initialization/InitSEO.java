package com.noname.itrust.gate.initialization;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.sql.SQLStatement;

@Service
public class InitSEO {

	/**
	 * init SEO orders
	 */
	public void initSEO(){
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
	        ps = conn.prepareStatement(ConnectionManager.sqlMap.get(SQLStatement.KEY_SEL_SEO));
	        rs = ps.executeQuery();
		   
	        while(rs.next()){
	        	String quoteid = rs.getString("QUOTEID");
	        	String acctno = rs.getString("ACCTNO");
	        	String symbol = rs.getString("SYMBOL");
	        	Long qtty = rs.getLong("QTTY");
	        	String side = rs.getString("SIDE");
	        	String pricetype = rs.getString("PRICETYPE");
	        	BigDecimal orderprice = rs.getBigDecimal("ORDERPRICE");
	        	BigDecimal price_delta = rs.getBigDecimal("PRICE_DELTA");
	        	String status = rs.getString("STATUS");
	        	Date fromdate = rs.getDate("FROMDATE");
	        	Date todate = rs.getDate("TODATE");
	        	String userid = rs.getString("USERID");
	        	String typecd = rs.getString("TYPECD");
	        	
	        	Quote seoOrder = new Quote();
	        	seoOrder.setQuoteid(quoteid);
	        	seoOrder.setAcctno(acctno);
	        	seoOrder.setSymbol(symbol);
	        	seoOrder.setQtty(qtty);
	        	seoOrder.setSide(side);
	        	seoOrder.setPricetype(pricetype);
	        	seoOrder.setOrderprice(orderprice);
	        	seoOrder.setPricedelta(price_delta);
	        	seoOrder.setStatus(status);
	        	seoOrder.setCreateddt(fromdate);
	        	seoOrder.setExpireddt(todate);
	        	seoOrder.setUserid(userid);
	        	seoOrder.setTypecd(typecd);
	        	
	        	seoOrder.setClasscd("SEO");
	        	
	        	Map<String, Quote> orderInfos = HandlerCacheData.seoMap.get(symbol);
				if(orderInfos == null){//chua co ma chung khoan nay trong he thong
					orderInfos = new HashMap<String, Quote>();
					orderInfos.put(quoteid, seoOrder);
					HandlerCacheData.seoMap.put(symbol, orderInfos);
				}else{//da ton tai ma chung khoan nay
					orderInfos.put(quoteid, seoOrder);
				}
	
				//TODO: init f(0)
				
	        }
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}
	}
}
