package com.noname.itrust.gate.caching;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fss.newfo.common.model.Quote;
import com.noname.itrust.gate.processing.AbstracRequestHandler;
import com.noname.itrust.gate.rules.IRules;
import com.noname.itrust.gate.rules.MCORule;
import com.noname.itrust.gate.rules.OTORule;
import com.noname.itrust.gate.rules.SEORule;
import com.noname.itrust.gate.rules.STORule;
import com.noname.itrust.gate.rules.TSORule;

public class HandlerCacheData {

	public static Map<String, IRules> marketHandlerMap = new HashMap<String, IRules>(); //map contains market rules Handler

	public static Map<String, IRules> tradingHandlerMap = new HashMap<String, IRules>(); //map contains trading rules Handler

	public static Map<String, AbstracRequestHandler> requestHandlerMap = new HashMap<String, AbstracRequestHandler>(); //map contains process request Handler

	public static Map<String, List<Object>> translog_symbol = new HashMap<String, List<Object>>(); 
	
	public static String hsxSession = "BOPN";//TODO: khoi tao lay tu DB
	public static String hnxSession = "BCNT";//TODO: khoi tao lay tu DB
	public static String upcomSession = "BCNT";//TODO: khoi tao lay tu DB
	
	public static void initCache() {

		//request handler
		initRequestHandler();

		//market
		initMarketRule();

		//trading
		initTradingRule();
	}

	private static void initMarketRule() {
		marketHandlerMap.put("TSO", new TSORule()); //trail order
		marketHandlerMap.put("STO", new STORule()); //Stop loss order
		marketHandlerMap.put("SEO", new SEORule()); //Stop entry order
		marketHandlerMap.put("OTO", new OTORule()); //Stop entry order
		marketHandlerMap.put("MCO", new MCORule()); //Stop entry order

		//TODO: other add here
	}

	private static void initTradingRule() {
		tradingHandlerMap.put("TSO", new TSORule()); //trail order
		tradingHandlerMap.put("STO", new STORule()); //Stop loss order
		tradingHandlerMap.put("SEO", new SEORule()); //Stop entry order
		//TODO: other add here
	}

	private static void initRequestHandler() {
		/*requestHandlerMap.put("tx1001", new TSORequestHandler()); //trail order
		requestHandlerMap.put("tx1002", new STORequestHandler()); //Stop loss order
		requestHandlerMap.put("tx1003", new SEORequestHandler()); //Stop entry order
		requestHandlerMap.put("tx1004", new PCORequestHandler()); //ProCompetitive Order
		requestHandlerMap.put("tx1005", new SORequestHandler()); //Split Order
		requestHandlerMap.put("tx1006", new ICORequestHandler()); //Immediate Or Cancel Order
		requestHandlerMap.put("tx1007", new CPORequestHandler()); //Cancel to place other
		requestHandlerMap.put("tx1008", new OCORequestHandler()); //Once Cancels the other
		requestHandlerMap.put("tx1009", new OTORequestHandler()); //Once triggers the other
		requestHandlerMap.put("tx1010", new MCORequestHandler()); //Multi Contingent Order
		requestHandlerMap.put("tx3001", new CancelRequestHandler()); //Cancel orders
*/	}
	
	//Map<symbol, Map<orderid,Quote>>
	public static Map<String,Map<String,Quote>> stockInfoSignalMap = new HashMap<String, Map<String,Quote>>(); //map contains orders that listen StockInfo
	public static Map<String,Map<String,Quote>> marketSignalMap = new HashMap<String, Map<String,Quote>>(); //map contains orders that listen MarketInfo
	public static Map<String,Map<String,Quote>> transLogSignalMap = new HashMap<String, Map<String,Quote>>(); //map contains orders that listen TransLog
	
	//Map<symbol, Map<orderid,Quote>>
	public static Map<String,Map<String,Quote>> tsoMap = new HashMap<String, Map<String,Quote>>();
	public static Map<String,Map<String,Quote>> stoMap = new HashMap<String, Map<String,Quote>>();
	public static Map<String,Map<String,Quote>> seoMap = new HashMap<String, Map<String,Quote>>();
	public static Map<String,Map<String,Quote>> pcoMap = new HashMap<String, Map<String,Quote>>();
	//public static Map<String,Map<String,Quote>> soMap = new HashMap<String, Map<String,Quote>>();
	public static Map<String,Quote> soMap = new HashMap<String,Quote>();
	public static Map<String,Quote> soTypeTMap = new HashMap<String,Quote>();
	
	public static Map<String,Map<String,Quote>> icoMap = new HashMap<String, Map<String,Quote>>();
	//public static Map<String,Map<String,Quote>> cpoMap = new HashMap<String, Map<String,Quote>>();
	public static Map<String,Quote> cpoMap = new HashMap<String, Quote>();
	public static Map<String,Quote> ocoMap = new HashMap<String,Quote>();
	public static Map<String,Map<String,Quote>> otoMap = new HashMap<String, Map<String,Quote>>();
	//Map<orderid,Quote>
	public static Map<String,Quote> mcoMap = new HashMap<String,Quote>();	
	
	/**
	 * Register msgtype and handlers for request processing
	 * @param args
	 * arg[0]: msgtype
	 * arg[1]: receiving handler
	 * @return
	 * @throws Exception
	 */
	public static boolean registerReceivingHandler(String msgtype, AbstracRequestHandler abstractHandler) throws Exception {
		requestHandlerMap.put(msgtype, abstractHandler);
		return true;
	}
	
	
	/**
	 * Register a list of msgtype and handlers for request processing
	 * @param args
	 * arg[0]: msgtype
	 * arg[1]: receiving handler
	 * @return
	 * @throws Exception
	 */
	public static boolean registerReceivingHandler(List<Object[]> args) throws Exception {
		for (Object[] arg : args) {
			registerReceivingHandler((String)arg[0], (AbstracRequestHandler)arg[1]);
		}
		return true;
	}
	
}
