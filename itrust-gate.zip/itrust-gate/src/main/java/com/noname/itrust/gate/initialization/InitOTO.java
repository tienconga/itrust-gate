package com.noname.itrust.gate.initialization;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.sql.SQLStatement;

@Service
public class InitOTO {

	/**
	 * init OTO orders
	 */
	public void initOTO(){
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
	        ps = conn.prepareStatement(ConnectionManager.sqlMap.get(SQLStatement.KEY_SEL_OTO));
	        rs = ps.executeQuery();
		   
	        while(rs.next()){
	        	String quoteid = rs.getString("QUOTEID");
	        	String acctno = rs.getString("ACCTNO");
	        	String symbol = rs.getString("SYMBOL");
	        	Long qtty = rs.getLong("QTTY");
	        	Long qtty2 = rs.getLong("QTTY2");
	        	String side = rs.getString("SIDE");
	        	String buyorderid = rs.getString("BUYORDERID");
	        	String pricetype = rs.getString("PRICETYPE");
	        	BigDecimal price = rs.getBigDecimal("PRICE");
	        	BigDecimal orderprice = rs.getBigDecimal("ORDERPRICE");
	        	String status = rs.getString("STATUS");
	        	String userid = rs.getString("USERID");
	        	String typecd = rs.getString("TYPECD");
	        	
	        	Quote otoOrder = new Quote();
	        	otoOrder.setQuoteid(quoteid);
	        	otoOrder.setAcctno(acctno);
	        	otoOrder.setSymbol(symbol);
	        	otoOrder.setQtty(qtty);
	        	otoOrder.setQtty2(qtty2);
	        	otoOrder.setSide2(side);
	        	otoOrder.setUserid(userid);
	        	otoOrder.setTypecd(typecd);
	        	
	        	if(buyorderid == null){
	        		otoOrder.setSide("B"); //lenh mua chua day vao ORS
	        	}else{
	        		otoOrder.setSide("S"); //Lenh mua da day vao ORS, lenh ban cho kich hoat
	        	}
	        	
	        	otoOrder.setPrice(price);
	        	otoOrder.setSubtypecd(pricetype);
	        	otoOrder.setOrderprice(orderprice);
	        	otoOrder.setStatus(status);
	        	
	        	otoOrder.setClasscd("OTO");
	        	
	        	Map<String, Quote> orderInfos = HandlerCacheData.otoMap.get(symbol);
				if(orderInfos == null){//chua co ma chung khoan nay trong he thong
					orderInfos = new HashMap<String, Quote>();
					orderInfos.put(quoteid, otoOrder);
					HandlerCacheData.otoMap.put(symbol, orderInfos);
				}else{//da ton tai ma chung khoan nay
					orderInfos.put(quoteid, otoOrder);
				}
	
				//TODO: init f(0)
				
	        }
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}
	}
}
