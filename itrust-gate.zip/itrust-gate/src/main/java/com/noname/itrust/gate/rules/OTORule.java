package com.noname.itrust.gate.rules;

import java.math.BigDecimal;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.CacheProcessing;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.common.CommonConstants;
import com.noname.itrust.gate.data.dao.DAOCommon;
import com.noname.itrust.gate.model.ISignal;
import com.noname.itrust.gate.model.TradeInfo;
import com.noname.itrust.gate.thread.TicketQueue;

public class OTORule implements IRules {

	private LinkedBlockingQueue<Quote> queue;
	
	@Override
	public void process(ISignal market,Quote quote) {
		if(quote.getStatus().equalsIgnoreCase("P")){ //chi xu ly tin hieu voi cac lenh dang o trang thai P
			
			TradeInfo marketObj = (TradeInfo) market;
			SLF4JLoggerProxy.info(this,"process OTO Order ***** quoteid:" + quote.getQuoteid() + ",symbol:"+ marketObj.getSymbol() + ", market:" + marketObj.getFormattedmatchprice());
			BigDecimal latestPrice = marketObj.getFormattedmatchprice();//gia khop lenh moi nhat tu so
			BigDecimal activePrice = quote.getOrderprice();
			String side2 = quote.getSide2(); //P: take profit, L: cut loss
			if(side2 != null && side2.equalsIgnoreCase("P")){
				if(latestPrice.compareTo(activePrice) == 1 || latestPrice.compareTo(activePrice) == 0){
					quote.setQtty(quote.getQtty2());
					activeOrder(quote,"S");
				}
			}else if(side2 != null && side2.equalsIgnoreCase("L")){
				if(latestPrice.compareTo(activePrice) == -1 || latestPrice.compareTo(activePrice) == 0){
					quote.setQtty(quote.getQtty2());
					activeOrder(quote,"S");
				}
			}
		}
	}

	@Override
	public void putRequest(Quote quote) {
		// TODO Auto-generated method stub

	}

	@Override
	public void load() {
		// TODO Auto-generated method stub

	}

	
	public void placeBuyOrder(Quote quote) {
		String exchange1 = CacheProcessing.InstrumentMap.get(quote.getSymbol()).getBoard();
		boolean isactive = false;
		//chi dat trong phien lien tuc
		if((exchange1 != null && exchange1.equalsIgnoreCase("HNX")) && //
						HandlerCacheData.hnxSession.equalsIgnoreCase("CNT")){
			isactive = true;
		}else if((exchange1 != null && exchange1.equalsIgnoreCase("UPCOM")) && //
			HandlerCacheData.hnxSession.equalsIgnoreCase("CNT")){
			isactive = true;
		}else if((exchange1 != null && exchange1.equalsIgnoreCase("HSX")) && //
			HandlerCacheData.hsxSession.equalsIgnoreCase("CNT")){
			isactive = true;
		}else if((exchange1 != null && exchange1.equalsIgnoreCase("HSX")) && //
			HandlerCacheData.hsxSession.equalsIgnoreCase("OPN")){
			isactive = true;
		}
		
		if(isactive){
			activeOrder(quote, "B");
		}else{
			quote.setStatus("N");
		}
	}
	
	private void activeOrder(Quote quote, String buysellFlag){//buysellFlag=B kich hoat lenh mua, buysellFlag=S kich hoat lenh ban
		//kich hoat lenh
		SLF4JLoggerProxy.info(this,"Active OTO Order ***** quoteid:" + quote.getQuoteid());
		try {
			TicketQueue queThread = TicketQueue.getTicketQueueThread();
			queue = queThread.getTicketqueue();
			queue.put(quote);
		} catch (InterruptedException e) {
			SLF4JLoggerProxy.error(this, "Error when active OTO Order ***** quoteid:" + quote.getQuoteid() + "," + e);
		}
		
		if(buysellFlag.equalsIgnoreCase("S")){//neu la lenh OTO kich hoat lenh dung (lenh ban)
			//xoa khoi orders list
			Map<String,Quote> tsoOrders = HandlerCacheData.otoMap.get(quote.getSymbol());
			tsoOrders.remove(quote.getQuoteid());
			
			//syn to DB
			DAOCommon obj = new DAOCommon();
			obj.updateStatus(quote.getQuoteid(), CommonConstants.ORDER_STATUS_ACTIVING,"OTO");
		}/*else{
			//syn to DB
			DAOCommon obj = new DAOCommon();
			obj.updateStatus(quote.getQuoteid(), "W","OTO");
		}*/
	}
}
