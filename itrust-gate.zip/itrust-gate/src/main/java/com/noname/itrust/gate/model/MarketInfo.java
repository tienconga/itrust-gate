package com.noname.itrust.gate.model;

import com.fss.fo.mserver.exchange.MarketInforProtos.MarketInfor;

public class MarketInfo implements  ISignal, java.io.Serializable{
	
	private static final long serialVersionUID = 1L;

	private String id;
	private String marketindex;
	private String tradingdate;
	private String sequencemsg;
	private String indextime;
	private String indexcolor;
	private double indexchange;
	private double indexpercentchange;
	private double totaltrade;
	private double totalvolume;
	private double totalvalue;
	private String marketstatus;
	private double advances;
	private double declines;
	private double nochange;
	private double advancesvolumn;
	private double declinesvolumn;
	private double nochangevolumn;
	private String marketid;
	private String marketcode;
	private double prv_prior_market_index;
	private double avr_market_index;
	private double avr_prior_market_index;
	private String avr_chg_index;
	private String avr_pct_index;
	private double pt_total_qtty;
	private double pt_total_value;
	private double pt_total_trade;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMarketindex() {
		return marketindex;
	}
	public void setMarketindex(String marketindex) {
		this.marketindex = marketindex;
	}
	public String getTradingdate() {
		return tradingdate;
	}
	public void setTradingdate(String tradingdate) {
		this.tradingdate = tradingdate;
	}
	public String getSequencemsg() {
		return sequencemsg;
	}
	public void setSequencemsg(String sequencemsg) {
		this.sequencemsg = sequencemsg;
	}
	public String getIndextime() {
		return indextime;
	}
	public void setIndextime(String indextime) {
		this.indextime = indextime;
	}
	public String getIndexcolor() {
		return indexcolor;
	}
	public void setIndexcolor(String indexcolor) {
		this.indexcolor = indexcolor;
	}
	public double getIndexchange() {
		return indexchange;
	}
	public void setIndexchange(double indexchange) {
		this.indexchange = indexchange;
	}
	public double getIndexpercentchange() {
		return indexpercentchange;
	}
	public void setIndexpercentchange(double indexpercentchange) {
		this.indexpercentchange = indexpercentchange;
	}
	public double getTotaltrade() {
		return totaltrade;
	}
	public void setTotaltrade(double totaltrade) {
		this.totaltrade = totaltrade;
	}
	public double getTotalvolume() {
		return totalvolume;
	}
	public void setTotalvolume(double totalvolume) {
		this.totalvolume = totalvolume;
	}
	public double getTotalvalue() {
		return totalvalue;
	}
	public void setTotalvalue(double totalvalue) {
		this.totalvalue = totalvalue;
	}
	public String getMarketstatus() {
		return marketstatus;
	}
	public void setMarketstatus(String marketstatus) {
		this.marketstatus = marketstatus;
	}
	public double getAdvances() {
		return advances;
	}
	public void setAdvances(double advances) {
		this.advances = advances;
	}
	public double getDeclines() {
		return declines;
	}
	public void setDeclines(double declines) {
		this.declines = declines;
	}
	public double getNochange() {
		return nochange;
	}
	public void setNochange(double nochange) {
		this.nochange = nochange;
	}
	public double getAdvancesvolumn() {
		return advancesvolumn;
	}
	public void setAdvancesvolumn(double advancesvolumn) {
		this.advancesvolumn = advancesvolumn;
	}
	public double getDeclinesvolumn() {
		return declinesvolumn;
	}
	public void setDeclinesvolumn(double declinesvolumn) {
		this.declinesvolumn = declinesvolumn;
	}
	public double getNochangevolumn() {
		return nochangevolumn;
	}
	public void setNochangevolumn(double nochangevolumn) {
		this.nochangevolumn = nochangevolumn;
	}
	public String getMarketid() {
		return marketid;
	}
	public void setMarketid(String marketid) {
		this.marketid = marketid;
	}
	public String getMarketcode() {
		return marketcode;
	}
	public void setMarketcode(String marketcode) {
		this.marketcode = marketcode;
	}
	public double getPrv_prior_market_index() {
		return prv_prior_market_index;
	}
	public void setPrv_prior_market_index(double prv_prior_market_index) {
		this.prv_prior_market_index = prv_prior_market_index;
	}
	public double getAvr_market_index() {
		return avr_market_index;
	}
	public void setAvr_market_index(double avr_market_index) {
		this.avr_market_index = avr_market_index;
	}
	public double getAvr_prior_market_index() {
		return avr_prior_market_index;
	}
	public void setAvr_prior_market_index(double avr_prior_market_index) {
		this.avr_prior_market_index = avr_prior_market_index;
	}
	public String getAvr_chg_index() {
		return avr_chg_index;
	}
	public void setAvr_chg_index(String avr_chg_index) {
		this.avr_chg_index = avr_chg_index;
	}
	public String getAvr_pct_index() {
		return avr_pct_index;
	}
	public void setAvr_pct_index(String avr_pct_index) {
		this.avr_pct_index = avr_pct_index;
	}
	public double getPt_total_qtty() {
		return pt_total_qtty;
	}
	public void setPt_total_qtty(double pt_total_qtty) {
		this.pt_total_qtty = pt_total_qtty;
	}
	public double getPt_total_value() {
		return pt_total_value;
	}
	public void setPt_total_value(double pt_total_value) {
		this.pt_total_value = pt_total_value;
	}
	public double getPt_total_trade() {
		return pt_total_trade;
	}
	public void setPt_total_trade(double pt_total_trade) {
		this.pt_total_trade = pt_total_trade;
	}

	public MarketInfo copyFromMarketInfor(MarketInfor mkt){
		this.id = mkt.getId();
		this.marketindex = mkt.getMarketIndex();
		this.tradingdate = mkt.getTradingdate();
		//this.sequencemsg = mkt.getSequenceMsg();
		this.indextime = mkt.getIndexTime();
		this.indexcolor = mkt.getIndexColor();
		if(null != mkt.getIndexChange() && !("").equalsIgnoreCase(mkt.getIndexChange())){
			this.indexchange = Double.parseDouble(mkt.getIndexChange());
		}
		
		if(null != mkt.getIndexPercentChange() && !("").equalsIgnoreCase(mkt.getIndexPercentChange())){
			this.indexpercentchange = Double.parseDouble(mkt.getIndexPercentChange());
		}
		
		if(null != mkt.getTotalTrade() && !("").equalsIgnoreCase(mkt.getTotalTrade())){
			this.totaltrade = Double.parseDouble(mkt.getTotalTrade());
		}
				
		if(null != mkt.getTotalVolume() && !("").equalsIgnoreCase(mkt.getTotalVolume())){
			this.totalvolume = Double.parseDouble(mkt.getTotalVolume());
		}
		
		if(null != mkt.getTotalValue() && !("").equalsIgnoreCase(mkt.getTotalValue())){
			this.totalvalue = Double.parseDouble(mkt.getTotalValue());
		}
		this.marketstatus = mkt.getMarketStatus();
		
		if(null != mkt.getAdvances() && !("").equalsIgnoreCase(mkt.getAdvances())){
			this.advances = Double.parseDouble(mkt.getAdvances());
		}
		
		if(null != mkt.getDeclines() && !("").equalsIgnoreCase(mkt.getDeclines())){
			this.declines = Double.parseDouble(mkt.getDeclines());
		}
		
		if(null != mkt.getNoChange() && !("").equalsIgnoreCase(mkt.getNoChange())){
			this.nochange = Double.parseDouble(mkt.getNoChange());
		}
		
		if(null != mkt.getAdvancesVolumn() && !("").equalsIgnoreCase(mkt.getAdvancesVolumn())){
			this.advancesvolumn = Double.parseDouble(mkt.getAdvancesVolumn());
		}
		
		if(null != mkt.getDeclinesVolumn() && !("").equalsIgnoreCase(mkt.getDeclinesVolumn())){
			this.declinesvolumn = Double.parseDouble(mkt.getDeclinesVolumn());
		}
		
		if(null != mkt.getNoChangeVolumn() && !("").equalsIgnoreCase(mkt.getNoChangeVolumn())){
			this.nochangevolumn = Double.parseDouble(mkt.getNoChangeVolumn());
		}
		
		if(null != mkt.getMarketId()){
			if(mkt.getMarketId().equalsIgnoreCase("10")){
				this.marketid = "VN-INDEX";
			}else if(mkt.getMarketId().equalsIgnoreCase("02")){
				this.marketid = "HNX-INDEX";
			}else if(mkt.getMarketId().equalsIgnoreCase("04")){
				this.marketid = "UPCOM-INDEX";
			}else if(mkt.getMarketId().equalsIgnoreCase("VN30")){
				this.marketid = "VN30-INDEX";
			}else if(mkt.getMarketId().equalsIgnoreCase("HNX30")){
				this.marketid = "HNX30-INDEX";
			}else{
				this.marketid = mkt.getMarketId();
			}
		}
		
		this.marketcode = mkt.getMarketCode();
		
		if(null != mkt.getPRVPRIORMARKETINDEX() && !("").equalsIgnoreCase(mkt.getPRVPRIORMARKETINDEX())){
			this.prv_prior_market_index = Double.parseDouble(mkt.getPRVPRIORMARKETINDEX());
		}
		
		if(null != mkt.getAVRMARKETINDEX() && !("").equalsIgnoreCase(mkt.getAVRMARKETINDEX())){
			this.avr_market_index = Double.parseDouble(mkt.getAVRMARKETINDEX());
		}
		
		if(null != mkt.getAVRPRIORMARKETINDEX() && !("").equalsIgnoreCase(mkt.getAVRPRIORMARKETINDEX())){
			this.avr_prior_market_index = Double.parseDouble(mkt.getAVRPRIORMARKETINDEX());
		}
		//this.avr_chg_index = mkt.getAVRCHGINDEX();
		//this.avr_pct_index = mkt.getAVRPCTINDEX();
		
		if(null != mkt.getPTTOTALQTTY() && !("").equalsIgnoreCase(mkt.getPTTOTALQTTY())){
			this.pt_total_qtty = Double.parseDouble(mkt.getPTTOTALQTTY());
		}
		
		if(null != mkt.getPTTOTALVALUE() && !("").equalsIgnoreCase(mkt.getPTTOTALVALUE())){
			this.pt_total_value = Double.parseDouble(mkt.getPTTOTALVALUE());
		}
		
		if(null != mkt.getPTTOTALTRADE() && !("").equalsIgnoreCase(mkt.getPTTOTALTRADE())){
			this.pt_total_trade = Double.parseDouble(mkt.getPTTOTALTRADE());
		}

		return this;
	}
}
