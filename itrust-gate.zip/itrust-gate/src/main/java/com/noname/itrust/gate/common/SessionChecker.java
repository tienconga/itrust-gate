package com.noname.itrust.gate.common;

import com.noname.itrust.gate.caching.CacheProcessing;
import com.noname.itrust.gate.caching.HandlerCacheData;

public class SessionChecker {
	
	public static boolean checkSessionSOOrder_T(String symbol){

		boolean result = false;
		String exchange = CacheProcessing.InstrumentMap.get(symbol).getBoard();
		
		if(exchange != null && exchange.equalsIgnoreCase("HSX")){
			if(HandlerCacheData.hsxSession.equalsIgnoreCase("OPN") || 
					HandlerCacheData.hsxSession.equalsIgnoreCase("CNT") ||
					HandlerCacheData.hsxSession.equalsIgnoreCase("CLS")){
				result = true;
			}
		}else if(exchange != null && exchange.equalsIgnoreCase("HNX")){
			if(HandlerCacheData.hnxSession.equalsIgnoreCase("CNT") ||
					HandlerCacheData.hnxSession.equalsIgnoreCase("CLS") ||
					HandlerCacheData.hnxSession.equalsIgnoreCase("L5M")){
				result = true;
			}
		}else if(exchange != null && exchange.equalsIgnoreCase("UPCOM")){
			if(HandlerCacheData.upcomSession.equalsIgnoreCase("CNT")){
				result = true;
			}
		}
	
		return result;
	}

	
	public static String checkSessionSOOrder(String symbol){

		String result = "D"; //D: divide, W: wait, E: Error 
		String exchange = CacheProcessing.InstrumentMap.get(symbol).getBoard();
		
		if(exchange != null && exchange.equalsIgnoreCase("HSX")){
			if(HandlerCacheData.hsxSession.equalsIgnoreCase("CROSS") || 
					HandlerCacheData.hsxSession.equalsIgnoreCase("END")){
				result = "E";
			}else if(HandlerCacheData.hsxSession.equalsIgnoreCase("BOPN") || 
					HandlerCacheData.hsxSession.equalsIgnoreCase("LB")){
				result = "W";
			}
					
		}else if(exchange != null && exchange.equalsIgnoreCase("HNX")){
			if(HandlerCacheData.hnxSession.equalsIgnoreCase("CROSS") ||
					HandlerCacheData.hnxSession.equalsIgnoreCase("END")){
				result = "E";
			}else if(HandlerCacheData.hnxSession.equalsIgnoreCase("BCNT")){
				result = "W";
			}
		}else if(exchange != null && exchange.equalsIgnoreCase("UPCOM")){
			if(HandlerCacheData.upcomSession.equalsIgnoreCase("END")){
				result = "E";
			}else if(HandlerCacheData.upcomSession.equalsIgnoreCase("BCNT")){
				result = "W";
			}
		}
	
		return result;
	}
}
