package com.noname.itrust.gate.initialization;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.CacheProcessing;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.rules.TSORule;
import com.noname.itrust.gate.sql.SQLStatement;

@Service
public class InitTSO {

	/**
	 * init TSO orders
	 */
	public void initTSO(){
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
	        ps = conn.prepareStatement(ConnectionManager.sqlMap.get(SQLStatement.KEY_SEL_TSO));
	        rs = ps.executeQuery();
		   
	        while(rs.next()){
	        	String quoteid = rs.getString("QUOTEID");
	        	String acctno = rs.getString("ACCTNO");
	        	String symbol = rs.getString("SYMBOL");
	        	String ordertype = rs.getString("ORDERTYPE");
	        	BigDecimal deltavalue = rs.getBigDecimal("DELTAVALUE");
	        	BigDecimal minmaxprice = rs.getBigDecimal("MINMAXPRICE");
	        	String status = rs.getString("STATUS");
	        	Date fromdate = rs.getDate("FROMDATE");
	        	Date todate = rs.getDate("TODATE");
	        	String side = rs.getString("SIDE");
	        	String userid = rs.getString("USERID");
	        	String typecd = rs.getString("TYPECD");
	        	
	        	BigDecimal fx1price = rs.getBigDecimal("FX1PRICE");//f(x-1)
	        	BigDecimal priceStep = rs.getBigDecimal("PRICESTEP");
	        	String deltatype = rs.getString("DELTATYPE");
	        	
	        	
	        	Quote tsoOrder = new Quote();
	        	tsoOrder.setQuoteid(quoteid);
	        	tsoOrder.setAcctno(acctno);
	        	tsoOrder.setSymbol(symbol);
	        	tsoOrder.setOrdertype(ordertype);
	        	tsoOrder.setDeltavalue(deltavalue);
	        	if(minmaxprice != null && minmaxprice.compareTo(new BigDecimal(0)) <= 0){
	        		tsoOrder.setMinmaxprice(null);
	        	}else{
	        		tsoOrder.setMinmaxprice(minmaxprice);
	        	}
	        	
	        	tsoOrder.setStatus(status);
	        	tsoOrder.setCreateddt(fromdate);
	        	tsoOrder.setExpireddt(todate);
	        	tsoOrder.setSide(side);
	        	tsoOrder.setQtty(rs.getLong("QTTY"));
	        	tsoOrder.setUserid(rs.getString("USERID"));
	        	tsoOrder.setPricestep(priceStep);
	        	tsoOrder.setUserid(userid);
	        	tsoOrder.setTypecd(typecd);
	        	tsoOrder.setDeltatype(deltatype);
	        	
	        	tsoOrder.setClasscd("TSO");
	        	
	        	Map<String, Quote> orderInfos = HandlerCacheData.tsoMap.get(symbol);
				if(orderInfos == null){//chua co ma chung khoan nay trong he thong
					orderInfos = new HashMap<String, Quote>();
					orderInfos.put(quoteid, tsoOrder);
					HandlerCacheData.tsoMap.put(symbol, orderInfos);
				}else{//da ton tai ma chung khoan nay
					orderInfos.put(quoteid, tsoOrder);
				}
	
				//init f(0)
				if(fx1price == null){
					TSORule.trailPriceMap.put(quoteid, CacheProcessing.calMarket.get(symbol).getPriceRF().add(deltavalue));
				}else{
					TSORule.trailPriceMap.put(quoteid, fx1price);
				}
				
	        }
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}
	}
}
