package com.noname.itrust.common.rmi;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.HandlerCacheData;

public class ConditionQuoteImpl extends UnicastRemoteObject implements ConditionQuote {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		
	public ConditionQuoteImpl() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<HFTViewInfo> TSOInfo() throws RemoteException {
		
		System.out.println("vvvvvvvvvvvvvvv");
		List<HFTViewInfo> list = new ArrayList<HFTViewInfo>(); 
		Map<String, Quote> orderInfos = new HashMap<String, Quote>();
		for(String key : HandlerCacheData.tsoMap.keySet()) {
			orderInfos = HandlerCacheData.tsoMap.get(key);
			for(String keyQuote : orderInfos.keySet()) {
				Quote quote = orderInfos.get(keyQuote);
				SLF4JLoggerProxy.info(this,"quote=============== : " + quote);
				
				HFTViewInfo hftViewInfo = new HFTViewInfo();
			
				hftViewInfo.setAcctno(quote.getAcctno());
				hftViewInfo.setQuoteid(quote.getQuoteid());
				hftViewInfo.setSymbol(quote.getSymbol());
				hftViewInfo.setOrdertype(quote.getOrdertype());
				hftViewInfo.setDeltatype(quote.getDeltatype());
				hftViewInfo.setDeltavalue(quote.getDeltavalue());
				hftViewInfo.setMinmaxprice(quote.getMinmaxprice());
				hftViewInfo.setPricestep(quote.getPricestep());
				hftViewInfo.setStatus(quote.getStatus());
				hftViewInfo.setCreateddt(quote.getCreateddt());
				hftViewInfo.setExpireddt(quote.getExpireddt());
				hftViewInfo.setClasscd(quote.getClasscd());
				hftViewInfo.setVia(quote.getVia());
				
				list.add(hftViewInfo);
			}
		}
		return list;
	}

	@Override
	public List<HFTViewInfo> STOInfo() throws RemoteException {
		
		List<HFTViewInfo> list = new ArrayList<HFTViewInfo>(); 
		Map<String, Quote> orderInfos = new HashMap<String, Quote>();
		for(String key : HandlerCacheData.stoMap.keySet()) {
			orderInfos = HandlerCacheData.stoMap.get(key);
			for(String keyQuote : orderInfos.keySet()) {
				Quote quote = orderInfos.get(keyQuote);
				HFTViewInfo hftViewInfo = new HFTViewInfo();
			
				hftViewInfo.setAcctno(quote.getAcctno());
				hftViewInfo.setQuoteid(quote.getQuoteid());
				hftViewInfo.setSymbol(quote.getSymbol());
				hftViewInfo.setQtty(quote.getQtty());
				hftViewInfo.setSide(quote.getSide());
				hftViewInfo.setOrderprice(quote.getOrderprice());
				hftViewInfo.setPrice(quote.getPrice());
				hftViewInfo.setStatus(quote.getStatus());
				hftViewInfo.setCreateddt(quote.getCreateddt());
				hftViewInfo.setExpireddt(quote.getExpireddt());
				hftViewInfo.setClasscd(quote.getClasscd());
				hftViewInfo.setVia(quote.getVia());

				
				list.add(hftViewInfo);
			}
		}
		
		return list;
	}

	@Override
	public List<HFTViewInfo> SEOInfo() throws RemoteException {
		
		List<HFTViewInfo> list = new ArrayList<HFTViewInfo>(); 
//		Quote quote = new Quote();
		Map<String, Quote> orderInfos = new HashMap<String, Quote>();
		for(String key : HandlerCacheData.seoMap.keySet()) {
			orderInfos = HandlerCacheData.seoMap.get(key);
			for(String keyQuote : orderInfos.keySet()) {
				Quote quote = orderInfos.get(keyQuote);
				
				HFTViewInfo hftViewInfo = new HFTViewInfo();
				//hftViewInfo.copyQuote(quote);
			
				hftViewInfo.setAcctno(quote.getAcctno());
				hftViewInfo.setQuoteid(quote.getQuoteid());
				hftViewInfo.setSymbol(quote.getSymbol());
				hftViewInfo.setQtty(quote.getQtty());
				hftViewInfo.setPrice(quote.getPrice());
				hftViewInfo.setSide(quote.getSide());
				hftViewInfo.setPricetype(quote.getPricetype());
				hftViewInfo.setOrderprice(quote.getOrderprice());
				hftViewInfo.setPricedelta(quote.getPricedelta());
				hftViewInfo.setStatus(quote.getStatus());
				hftViewInfo.setCreateddt(quote.getCreateddt());
				hftViewInfo.setExpireddt(quote.getExpireddt());
				hftViewInfo.setClasscd(quote.getClasscd());
				hftViewInfo.setVia(quote.getVia());
				
				list.add(hftViewInfo);
			}
		}
		
		return list;
	}

	@Override
	public List<HFTViewInfo> PCOInfo() throws RemoteException {
		List<HFTViewInfo> list = new ArrayList<HFTViewInfo>(); 
		Map<String, Quote> orderInfos = new HashMap<String, Quote>();
		for(String key : HandlerCacheData.pcoMap.keySet()) {
			orderInfos = HandlerCacheData.pcoMap.get(key);
			for(String keyQuote : orderInfos.keySet()) {
				Quote quote = orderInfos.get(keyQuote);
				System.out.println("quote=============== : " + quote);
				
				HFTViewInfo hftViewInfo = new HFTViewInfo();
			
				hftViewInfo.setAcctno(quote.getAcctno());
				hftViewInfo.setQuoteid(quote.getQuoteid());
				hftViewInfo.setSymbol(quote.getSymbol());
				hftViewInfo.setQtty(quote.getQtty());
				hftViewInfo.setSide(quote.getSide());
				hftViewInfo.setPrice(quote.getPrice());
				hftViewInfo.setPricetype(quote.getPricetype());
				hftViewInfo.setStatus(quote.getStatus());
				hftViewInfo.setCreateddt(quote.getCreateddt());
				hftViewInfo.setExpireddt(quote.getExpireddt());
				hftViewInfo.setClasscd(quote.getClasscd());
				hftViewInfo.setVia(quote.getVia());
				
				list.add(hftViewInfo);
			}
		}
		return list;
	}

	@Override
	public List<HFTViewInfo> SOInfo() throws RemoteException {
		List<HFTViewInfo> list = new ArrayList<HFTViewInfo>(); 
		for(String key : HandlerCacheData.soMap.keySet()) {

				Quote quote = HandlerCacheData.soMap.get(key);
				HFTViewInfo hftViewInfo = new HFTViewInfo();
			
				hftViewInfo.setAcctno(quote.getAcctno());
				hftViewInfo.setQuoteid(quote.getQuoteid());
				hftViewInfo.setSymbol(quote.getSymbol());
				hftViewInfo.setQtty(quote.getQtty());
				hftViewInfo.setSide(quote.getSide());
				hftViewInfo.setPrice(quote.getPrice());
				hftViewInfo.setPricedelta(quote.getPricedelta());
				hftViewInfo.setDevide_type(quote.getDevide_type());
				hftViewInfo.setQtty_size(quote.getQtty_size());
				hftViewInfo.setQttyDelta(quote.getQttyDelta());
				hftViewInfo.setTime_period(quote.getTime_period());
				hftViewInfo.setTime_delta(quote.getTime_delta());
				hftViewInfo.setStatus(quote.getStatus());
				hftViewInfo.setClasscd(quote.getClasscd());
				hftViewInfo.setVia(quote.getVia());
				
				list.add(hftViewInfo);
			}
		
		return list;
		
	}

	@Override
	public List<HFTViewInfo> ICOInfo() throws RemoteException {
		List<HFTViewInfo> list = new ArrayList<HFTViewInfo>(); 
		Map<String, Quote> orderInfos = new HashMap<String, Quote>();
		for(String key : HandlerCacheData.icoMap.keySet()) {
			orderInfos = HandlerCacheData.icoMap.get(key);
			for(String keyQuote : orderInfos.keySet()) {
				Quote quote = orderInfos.get(keyQuote);
				
				HFTViewInfo hftViewInfo = new HFTViewInfo();
			
				hftViewInfo.setAcctno(quote.getAcctno());
				hftViewInfo.setQuoteid(quote.getQuoteid());
				hftViewInfo.setSymbol(quote.getSymbol());
				hftViewInfo.setQtty(quote.getQtty());
				hftViewInfo.setSide(quote.getSide());
				hftViewInfo.setPrice(quote.getPrice());
				hftViewInfo.setStatus(quote.getStatus());
				hftViewInfo.setClasscd(quote.getClasscd());
				hftViewInfo.setVia(quote.getVia());
				
				list.add(hftViewInfo);
			}
		}
		return list;
	}

	@Override
	public List<HFTViewInfo> CPOInfo() {
		
		List<HFTViewInfo> list = new ArrayList<HFTViewInfo>(); 
		for(String key : HandlerCacheData.cpoMap.keySet()) {
				Quote quote = HandlerCacheData.cpoMap.get(key);
				HFTViewInfo hftViewInfo = new HFTViewInfo();
			
				hftViewInfo.setAcctno(quote.getAcctno());
				hftViewInfo.setQuoteid(quote.getQuoteid());
				hftViewInfo.setSymbol(quote.getSymbol());
				hftViewInfo.setQtty(quote.getQtty());
				hftViewInfo.setSide(quote.getSide());
				hftViewInfo.setPrice(quote.getPrice());
				hftViewInfo.setStatus(quote.getStatus());
				hftViewInfo.setClasscd(quote.getClasscd());
				hftViewInfo.setVia(quote.getVia());
				hftViewInfo.setReforderid(quote.getReforderid());
				
				list.add(hftViewInfo);
			}
		
		return list;
	}
	
	@Override
	public List<HFTViewInfo> OCOInfo() throws RemoteException {
		List<HFTViewInfo> list = new ArrayList<HFTViewInfo>(); 
		for(String key : HandlerCacheData.ocoMap.keySet()) {
				Quote quote = HandlerCacheData.ocoMap.get(key);
				HFTViewInfo hftViewInfo = new HFTViewInfo();
			
				hftViewInfo.setAcctno(quote.getAcctno());
				hftViewInfo.setQuoteid(quote.getQuoteid());
				hftViewInfo.setSymbol(quote.getSymbol());
				hftViewInfo.setQtty(quote.getQtty());
				hftViewInfo.setSide(quote.getSide());
				hftViewInfo.setPrice(quote.getPrice());
				hftViewInfo.setSymbol2(quote.getSymbol2());
				hftViewInfo.setQtty2(quote.getQtty2());
				hftViewInfo.setSide2(quote.getSide2());
				hftViewInfo.setPrice2(quote.getPrice2());
				hftViewInfo.setStatus(quote.getStatus());
				hftViewInfo.setClasscd(quote.getClasscd());
				hftViewInfo.setVia(quote.getVia());
				
				list.add(hftViewInfo);
			}
		
		return list;
	}

	@Override
	public List<HFTViewInfo> OTOInfo() throws RemoteException {
		List<HFTViewInfo> list = new ArrayList<HFTViewInfo>(); 
		Map<String, Quote> orderInfos = new HashMap<String, Quote>();
		for(String key : HandlerCacheData.otoMap.keySet()) {
			orderInfos = HandlerCacheData.otoMap.get(key);
			for(String keyQuote : orderInfos.keySet()) {
				Quote quote = orderInfos.get(keyQuote);
				
				HFTViewInfo hftViewInfo = new HFTViewInfo();
			
				hftViewInfo.setAcctno(quote.getAcctno());
				hftViewInfo.setQuoteid(quote.getQuoteid());
				hftViewInfo.setSymbol(quote.getSymbol());
				hftViewInfo.setQtty(quote.getQtty());
				hftViewInfo.setPrice(quote.getPrice());
				hftViewInfo.setSide(quote.getSide());
				hftViewInfo.setSide2(quote.getSide2());
				hftViewInfo.setSubtypecd(quote.getSubtypecd());
				hftViewInfo.setOrderprice(quote.getOrderprice());
				hftViewInfo.setStatus(quote.getStatus());
				hftViewInfo.setClasscd(quote.getClasscd());
				hftViewInfo.setVia(quote.getVia());
				
				list.add(hftViewInfo);
			}
		}
		return list;
	}

	@Override
	public List<HFTViewInfo> MCOInfo() throws RemoteException {
		List<HFTViewInfo> list = new ArrayList<HFTViewInfo>(); 
		/*for(String key : HandlerCacheData.mcoMap.keySet()) {
				Quote quote = HandlerCacheData.mcoMap.get(key);
				HFTViewInfo hftViewInfo = new HFTViewInfo();
			
				hftViewInfo.setAcctno(quote.getAcctno());
				hftViewInfo.setQuoteid(quote.getQuoteid());
				hftViewInfo.setSymbol(quote.getSymbol());
				hftViewInfo.setQtty(quote.getQtty());
				hftViewInfo.setSide(quote.getSide());
				hftViewInfo.setPrice(quote.getPrice());
				hftViewInfo.setCondition1(quote.getCondition1());
				hftViewInfo.setCondition2(quote.getCondition2());
				hftViewInfo.setCondition3(quote.getCondition3());
				hftViewInfo.setCondition4(quote.getCondition4());
				hftViewInfo.setOperation1(quote.getOperation1());
				hftViewInfo.setOperation2(quote.getOperation2());
				hftViewInfo.setOperation3(quote.getOperation3());
				hftViewInfo.setOperation4(quote.getOperation4());
				hftViewInfo.setValue1(quote.getValue1());
				hftViewInfo.setValue2(quote.getValue2());
				hftViewInfo.setValue3(quote.getValue3());
				hftViewInfo.setValue4(quote.getValue4());
				hftViewInfo.setCreateddt(quote.getCreateddt());
				hftViewInfo.setExpireddt(quote.getExpireddt());
				hftViewInfo.setStatus(quote.getStatus());
				hftViewInfo.setClasscd(quote.getClasscd());
				hftViewInfo.setVia(quote.getVia());
				
				list.add(hftViewInfo);
			}
		*/
		return list;
	}

	@Override
	public String getSession() throws RemoteException {
		// TODO Auto-generated method stub
		String session = "HSX:" + HandlerCacheData.hsxSession + "; HNX:" + HandlerCacheData.hnxSession + "; UPCOM:"+ HandlerCacheData.upcomSession;
		return session;
	}

	

}
