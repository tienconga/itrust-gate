package com.noname.itrust.gate.rules;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.common.CommonConstants;
import com.noname.itrust.gate.data.dao.DAOCommon;
import com.noname.itrust.gate.model.ISignal;
import com.noname.itrust.gate.model.MarketInfo;
import com.noname.itrust.gate.model.StockInfo;
import com.noname.itrust.gate.model.TradeInfo;
import com.noname.itrust.gate.thread.TicketQueue;

public class MCORule implements IRules {
	
	private LinkedBlockingQueue<Quote> queue;
	
	@Override
	public void process(ISignal market,Quote quote) {/*
		if (market instanceof StockInfo) {
			SLF4JLoggerProxy.info(this, "========================MCO StockInfo");
		}else if (market instanceof MarketInfo) {
			SLF4JLoggerProxy.info(this, "========================MCO MarketInfo");
			
			//Chi so index
			String condition1 = quote.getCondition1();	//MARKETINDEX
														//VN-INDEX, HNX-INDEX, UPCOM-INDEX, VN30-INDEX, HNX30-INDEX
			String operation1 = quote.getOperation1();	//<, <=, =, >, >=
			int targetValue1 = quote.getValue1();
			MarketInfo marketObj = (MarketInfo) market;
			if(condition1 != null && operation1 != null && condition1.equalsIgnoreCase(marketObj.getMarketid())){				
				int marketindex = 0;
				//get index value from market
				if(null != marketObj.getMarketindex()){
					marketindex = Integer.valueOf(marketObj.getMarketindex());
					//process
					procesCondition(quote,"1", marketindex, targetValue1);
				}
			}
			
			//Tong khop lenh toan thi truong
			String condition3 = quote.getCondition3();	//TOTALVOLUME
														//VN-INDEX, HNX-INDEX, UPCOM-INDEX, VN30-INDEX, HNX30-INDEX
			String operation3 = quote.getOperation3(); 	//<, <=, =, >, >=
			int targetValue3 = quote.getValue3();
			if(condition3 != null && operation3 != null && condition3.equalsIgnoreCase(marketObj.getMarketid())){				
				//get totalvolume value from market
				double totalvolume =  marketObj.getTotalvolume();				
				if(totalvolume > 0){
					//process
					procesCondition(quote,"3", totalvolume, targetValue3);
				}
			}
			
		}else if (market instanceof TradeInfo) {
			SLF4JLoggerProxy.info(this, "========================MCO TradeInfo");
			
			//Tong khoi luong khop lenh cua 1 ma chung khoan
			String condition2 = quote.getCondition2();	//FORMATTEDACCVOL
			String operation2 = quote.getOperation2();	//<, <=, =, >, >=		
			int targetValue2 = quote.getValue2();
			TradeInfo tradeInfo = (TradeInfo) market;
			if(condition2 != null && operation2 != null && condition2.equalsIgnoreCase(tradeInfo.getSymbol())){										
				//get formattedaccvol value from market
				long formattedaccvol = tradeInfo.getFormattedaccvol();	//tong khoi luong khop cua ma chung khoan
				if(formattedaccvol > 0){
					//process
					procesCondition(quote,"2", formattedaccvol, targetValue2);
				}
			}
			
			//Gia khop lenh cua mot ma
			String condition4 = quote.getCondition4();	//FORMATTEDMATCHPRICE
			String operation4 = quote.getOperation4();	//<, <=, =, >, >=
			int targetValue4 = quote.getValue4();
			if(condition4 != null && operation4 != null && condition4.equalsIgnoreCase(tradeInfo.getSymbol())){											
				//get formattedmatchprice value from market
				BigDecimal formattedmatchprice = tradeInfo.getFormattedmatchprice();	//Gia khop lenh cua mot ma chung khoan	
				
				if(formattedmatchprice != null){
					//process
					double volTemp = formattedmatchprice.doubleValue();
					procesCondition(quote,"4", volTemp, targetValue4);
				}
			}
		}
		
	*/}

	@Override
	public void putRequest(Quote quote) {
		//TODO Auto-generated method stub

	}

	@Override
	public void load() {
		//TODO Auto-generated method stub

	}
	
	/**
	 * 
	 * @param quote
	 * @param conditionNo
	 * @param sourceValue: gia tri lay tu market
	 * @param targetValue: gia tri ma nha dau tu dat ra
	 */
	private void procesCondition(Quote quote, String conditionNo, double sourceValue, double targetValue){
		
		String operation = "";
		if(conditionNo.equalsIgnoreCase("1")){
			//condition = quote.getCondition1();
			operation = quote.getOperation1();
		}else if(conditionNo.equalsIgnoreCase("2")){
			//condition = quote.getCondition2();
			operation = quote.getOperation2();
		}else if(conditionNo.equalsIgnoreCase("3")){
			//condition = quote.getCondition3();
			operation = quote.getOperation3();
		}else if(conditionNo.equalsIgnoreCase("4")){
			//condition = quote.getCondition4();
			operation = quote.getOperation4();
		} 
		
		//compare
		if(operation.equalsIgnoreCase("=")){								
			if(sourceValue == targetValue ){
				changeStatus(quote, conditionNo, true);
				//check active order
				if(isActive(HandlerCacheData.mcoMap.get(quote.getQuoteid()))){
					activeOrder(quote);
				}
			}else{
				changeStatus(quote, conditionNo, false);
			}
		}else if(operation.equalsIgnoreCase(">=")){
			if(sourceValue >= targetValue ){
				changeStatus(quote, conditionNo, true);
				//check active order
				if(isActive(HandlerCacheData.mcoMap.get(quote.getQuoteid()))){
					activeOrder(quote);
				}
			}else{
				changeStatus(quote, conditionNo, false);
			}
		}else if(operation.equalsIgnoreCase("<=")){
			if(sourceValue <= targetValue ){
				changeStatus(quote, conditionNo, true);
				
				//check active order
				if(isActive(HandlerCacheData.mcoMap.get(quote.getQuoteid()))){
					activeOrder(quote);
				}
			}else{
				changeStatus(quote, conditionNo, false);
			}
		}else if(operation.equalsIgnoreCase("<")){
			if(sourceValue < targetValue ){
				changeStatus(quote, conditionNo, true);
				
				//check active order
				if(isActive(HandlerCacheData.mcoMap.get(quote.getQuoteid()))){
					activeOrder(quote);
				}
			}else{
				changeStatus(quote, conditionNo, false);
			}
		}else if(operation.equalsIgnoreCase(">")){
			if(sourceValue > targetValue ){
				changeStatus(quote, conditionNo, true);
				
				//check active order
				if(isActive(HandlerCacheData.mcoMap.get(quote.getQuoteid()))){
					activeOrder(quote);
				}
			}else{
				changeStatus(quote, conditionNo, false);
			}
		}
		
	}
	
	private void changeStatus(Quote quote, String conditionNo, boolean status){
		DAOCommon obj = new DAOCommon();
		Quote oriQuote = HandlerCacheData.mcoMap.get(quote.getQuoteid());
		if(conditionNo.equalsIgnoreCase("1")){
			oriQuote.setConditionStatus1(status);
			if(status){
				obj.updateStatusMCO(quote, "STATUS1", "T");
			}else{
				obj.updateStatusMCO(quote, "STATUS1", "F");
			}
			
		}else if(conditionNo.equalsIgnoreCase("2")){
			oriQuote.setConditionStatus2(status);
			if(status){
				obj.updateStatusMCO(quote, "STATUS2", "T");
			}else{
				obj.updateStatusMCO(quote, "STATUS2", "F");
			}
		}else if(conditionNo.equalsIgnoreCase("3")){
			oriQuote.setConditionStatus3(status);
			if(status){
				obj.updateStatusMCO(quote, "STATUS3", "T");
			}else {
				obj.updateStatusMCO(quote, "STATUS3", "F");
			}
		}else if(conditionNo.equalsIgnoreCase("4")){
			oriQuote.setConditionStatus4(status);
			if(status){
				obj.updateStatusMCO(quote, "STATUS4", "T");
			}else {
				obj.updateStatusMCO(quote, "STATUS4", "F");
			}
		} 
	}
	
	private boolean isActive(Quote quote){
		boolean status1 = quote.isConditionStatus1();
		boolean status2 = quote.isConditionStatus2();
		boolean status3 = quote.isConditionStatus3();
		boolean status4 = quote.isConditionStatus4();
		if(status1 && status2 && status3 && status4){
			return true;
		}else{
			return false;
		}
		
	}
	
	private synchronized void activeOrder(Quote quote){
		//kich hoat lenh
		SLF4JLoggerProxy.info(this,"Active MCO Order========quoteid:" + quote.getQuoteid());
		Quote oldQuote = HandlerCacheData.mcoMap.get(quote.getQuoteid());
		if(oldQuote == null){
			SLF4JLoggerProxy.info(this,"Active MCO Order========quoteid:" + quote.getQuoteid() + " da duoc active truoc do.");
			return;
		}
		
		//xoa khoi orders list		
		HandlerCacheData.mcoMap.remove(quote.getQuoteid());
		try {
			TicketQueue queThread = TicketQueue.getTicketQueueThread();
			queue = queThread.getTicketqueue();
			queue.put(quote);
			
		} catch (InterruptedException e) {
			SLF4JLoggerProxy.error(this, "Error when active MCO Order========quoteid:" + quote.getQuoteid() + "," + e);
		}
		
		//syn to DB
		DAOCommon obj = new DAOCommon();
		obj.updateStatus(quote.getQuoteid(), CommonConstants.ORDER_STATUS_ACTIVING,"MCO");		
	}

}
