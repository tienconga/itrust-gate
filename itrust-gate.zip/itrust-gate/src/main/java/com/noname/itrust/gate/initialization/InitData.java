package com.noname.itrust.gate.initialization;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.noname.itrust.gate.caching.CacheProcessing;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.common.Properties;
import com.noname.itrust.gate.filter.MarketFilter;
import com.noname.itrust.gate.thread.TicketQueue;


@Component
public class InitData implements InitializingBean {

	public static boolean flag = false;
	
	@Override
	public void afterPropertiesSet() throws Exception {
		this.process();
	}
	
	@Autowired
	Properties properties;
	
	public static Properties prop;
	
	@Autowired
	MarketFilter marketFilter;

	@Autowired
	InitTSO initTSO;
	
	@Autowired
	InitSTO initSTO;
	
	@Autowired
	InitSEO initSEO;
	
	@Autowired
	InitPCO initPCO;
	
	@Autowired
	InitSO initSO;
	
	@Autowired
	InitICO initICO;
	
	@Autowired
	InitCPO initCPO;
	
	@Autowired
	InitOCO initOCO;
	
	@Autowired
	InitOTO initOTO;
	
	@Autowired
	InitMCO initMCO;
	
	@Autowired
	InitCommon initCommon;
	
	@Autowired
	InitRmiServer initRmiServer;
	
	public void process() throws Exception {
		/*TicketQueue.init();
		
		prop = properties;
		
		marketFilter.initFilter();
		
		//HandlerCacheData.initCache();
		
		CacheProcessing.initCache();
		
		flag = true;
		
		initCommon.init();
		
		initTSO.initTSO();
		initSTO.initSTO();
		initSEO.initSEO();
		initPCO.initPCO();
		initSO.initSO();
		initICO.initICO();
		initCPO.initCPO();
		initOCO.initOCO();
		initOTO.initOTO();
		initMCO.initMCO();
		
		initRmiServer.initRmiServer();*/

		
	}
}
