package com.noname.itrust.gate.initialization;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.sql.SQLStatement;

@Service
public class InitPCO {

	/**
	 * init PCO orders
	 */
	public void initPCO(){
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
	        ps = conn.prepareStatement(ConnectionManager.sqlMap.get(SQLStatement.KEY_SEL_PCO));
	        rs = ps.executeQuery();
		   
	        while(rs.next()){
	        	String quoteid = rs.getString("QUOTEID");
	        	String acctno = rs.getString("ACCTNO");
	        	String symbol = rs.getString("SYMBOL");
	        	Long qtty = rs.getLong("QTTY");
	        	String side = rs.getString("SIDE");
	        	String status = rs.getString("STATUS");
	        	Date fromdate = rs.getDate("FROMDATE");
	        	Date todate = rs.getDate("TODATE");
	        	String active_price = rs.getString("ACTIVE_PRICE");
	        	String userid = rs.getString("USERID");
	        	String typecd = rs.getString("TYPECD");
	        	
	        	
	        	Quote pcoOrder = new Quote();
	        	pcoOrder.setQuoteid(quoteid);
	        	pcoOrder.setAcctno(acctno);
	        	pcoOrder.setSymbol(symbol);
	        	pcoOrder.setQtty(qtty);
	        	pcoOrder.setSide(side);
	        	pcoOrder.setStatus(status);
	        	pcoOrder.setCreateddt(fromdate);
	        	pcoOrder.setExpireddt(todate);
	        	pcoOrder.setPricetype(active_price);
	        	pcoOrder.setUserid(userid);
	        	pcoOrder.setTypecd(typecd);
	        	
	        	pcoOrder.setClasscd("PCO");
	        	
	        	Map<String, Quote> orderInfos = HandlerCacheData.pcoMap.get(symbol);
				if(orderInfos == null){//chua co ma chung khoan nay trong he thong
					orderInfos = new HashMap<String, Quote>();
					orderInfos.put(quoteid, pcoOrder);
					HandlerCacheData.pcoMap.put(symbol, orderInfos);
				}else{//da ton tai ma chung khoan nay
					orderInfos.put(quoteid, pcoOrder);
				}
	
				//TODO: init f(0)
				
	        }
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}
	}
}
