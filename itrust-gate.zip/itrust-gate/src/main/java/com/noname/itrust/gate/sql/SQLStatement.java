package com.noname.itrust.gate.sql;

public class SQLStatement {

	//SQL SELECT
	public static final String KEY_SEL_MARKETFILTER = "SQL_SEL_MARKETFILTER";
	public static final String KEY_SEL_INSTRUMENTS = "SQL_SEL_INSTRUMENTS";
	public static final String KEY_SEL_TICKSIZE = "SQL_SEL_TICKSIZE";
	public static final String KEY_SEL_ACTIVE_ORDER = "SQL_SEL_ACTIVE_ORDER";
	
	public static final String KEY_SEL_TSO = "SQL_SEL_TSO";
	public static final String KEY_SEL_STO = "SQL_SEL_STO";
	public static final String KEY_SEL_SEO = "SQL_SEL_SEO";
	public static final String KEY_SEL_PCO = "SQL_SEL_PCO";
	public static final String KEY_SEL_SO = "SQL_SEL_SO";
	public static final String KEY_SEL_ICO = "SQL_SEL_ICO";
	public static final String KEY_SEL_CPO = "SQL_SEL_CPO";
	public static final String KEY_SEL_OCO = "SQL_SEL_OCO";
	public static final String KEY_SEL_OTO = "SQL_SEL_OTO";
	public static final String KEY_SEL_MCO = "SQL_SEL_MCO";
	public static final String KEY_SEL_MARKETINFO = "SQL_SEL_MARKETINFO";
	public static final String KEY_SEL_SYSCONFIG = "SQL_SEL_SYSCONFIG";
	public static final String KEY_SEL_DEFRULES_MAXQTTY = "SQL_SEL_DEFRULES_MAXQTTY";

	
	//SQL INSERT
	public static final String KEY_INSERT_TSO = "SQL_INSERT_TSO";
	public static final String KEY_INSERT_STO = "SQL_INSERT_STO";
	public static final String KEY_INSERT_SEO = "SQL_INSERT_SEO";
	public static final String KEY_INSERT_PCO = "SQL_INSERT_PCO";
	public static final String KEY_INSERT_SO = "SQL_INSERT_SO";
	public static final String KEY_INSERT_ICO = "SQL_INSERT_ICO";
	public static final String KEY_INSERT_CPO = "SQL_INSERT_CPO";
	public static final String KEY_INSERT_OCO = "SQL_INSERT_OCO";
	public static final String KEY_INSERT_OTO = "SQL_INSERT_OTO";
	public static final String KEY_INSERT_MCO = "SQL_INSERT_MCO";
	
	public static final String KEY_CANCEL_ORDER = "SQL_CANCEL_ORDER";
	public static final String KEY_CONFIRM_CANCEL_ORDER = "SQL_CONFIRM_CANCEL_ORDER";
	public static final String KEY_CONFIRM_DEAL_ORDER = "SQL_CONFIRM_DEAL_ORDER";
	public static final String KEY_CONFIRM_DEAL_ORDER_OCO = "SQL_CONFIRM_DEAL_ORDER_OCO";
	public static final String KEY_CONFIRM_RESPONE_ORDER = "SQL_CONFIRM_RESPONE_ORDER";
	
	public static final String KEY_GET_ORDER_LIST = "SQL_GET_ORDER_LIST";
	
	
	//Timesten SQL
	public static final String KEY_TT_GET_ORDER_LIST = "SQL_SEL_ORDERS";
	public static final String KEY_TT_GET_ORDER_INFO = "SQL_SEL_ORDER_INFO";
	
	

}
