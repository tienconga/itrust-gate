package com.noname.itrust.gate.rules;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.CacheProcessing;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.data.dao.DAOCommon;
import com.noname.itrust.gate.model.ISignal;
import com.noname.itrust.gate.sending.CancelOrderSending;
import com.noname.itrust.gate.thread.TicketQueue;

public class OCORule implements IRules {

	private LinkedBlockingQueue<Quote> queue;
	
	@Override
	public void process(ISignal market,Quote quote) {
		// TODO Auto-generated method stub
	}

	@Override
	public void putRequest(Quote quote) {
		// TODO Auto-generated method stub

	}

	@Override
	public void load() {
		// TODO Auto-generated method stub

	}

	public synchronized String placeOrder(Quote quote) throws CloneNotSupportedException{
		String exchange1 = CacheProcessing.InstrumentMap.get(quote.getSymbol()).getBoard();
		String exchange2 = CacheProcessing.InstrumentMap.get(quote.getSymbol2()).getBoard();
		boolean isactive = false;
		//chi dat trong phien lien tuc
		if((exchange1 != null && exchange1.equalsIgnoreCase("HNX")) && //ca 2 ma thuoc HNX
				(exchange2 != null && exchange2.equalsIgnoreCase("HNX") && 
						HandlerCacheData.hnxSession.equalsIgnoreCase("CNT"))){
			isactive = true;
		}else if((exchange1 != null && exchange1.equalsIgnoreCase("HSX")) && //ca 2 ma thuoc HSX
				(exchange2 != null && exchange2.equalsIgnoreCase("HSX") && 
				HandlerCacheData.hsxSession.equalsIgnoreCase("CNT"))){
			isactive = true;
		}else if((exchange1 != null && exchange1.equalsIgnoreCase("HSX")) && //Ma 1 thuoc HSX, ma 2 thuoc HNX
				(exchange2 != null && exchange2.equalsIgnoreCase("HNX") && 
				HandlerCacheData.hsxSession.equalsIgnoreCase("CNT") &&
				HandlerCacheData.hnxSession.equalsIgnoreCase("CNT"))){
			isactive = true;
		}else if((exchange1 != null && exchange1.equalsIgnoreCase("HNX")) && //Ma 1 thuoc HNX, ma 2 thuoc HSX
				(exchange2 != null && exchange2.equalsIgnoreCase("HSX") && 
				HandlerCacheData.hsxSession.equalsIgnoreCase("CNT") &&
				HandlerCacheData.hnxSession.equalsIgnoreCase("CNT"))){
			isactive = true;
		}
		
		
		if(isactive){
			activeOrder(quote);
			return quote.getQuoteid();
		}else{
			quote.setStatus("N");
			return null;
		}
		
	}
	
	private void activeOrder(Quote quote) throws CloneNotSupportedException{
		//active lenh 1
		Quote quote1 = new Quote();
		quote1 = (Quote) quote.clone();
		quote1.setTraderid("1");
		activeOrder(quote1,"1");
		
		//active lenh 2
		Quote quote2 = new Quote();
		quote2 = (Quote) quote.clone();
		quote2.setSymbol(quote.getSymbol2());
		quote2.setQtty(quote.getQtty2());
		quote2.setPrice(quote.getPrice2());
		quote2.setSide(quote.getSide2());
		quote2.setTraderid("2");
		activeOrder(quote2,"2");
	}
	
	public void cancelOrder(String orderid, String oriQuoteid) {
		
		Quote quote = HandlerCacheData.ocoMap.get(oriQuoteid);
		
		Quote newQuote = DAOCommon.getOrderInfo(orderid);
		if(newQuote != null && newQuote.getQtty2() > 0 && quote != null){
			CancelOrderSending cancelObj = new CancelOrderSending();
			
			
			Quote newquote = new Quote();
			newquote.setQuoteid(quote.getQuoteid());
			newquote.setMsgtype(quote.getMsgtype());
			newquote.setRequestid(quote.getRequestid());
			newquote.setAcctno(quote.getAcctno());
			newquote.setOrderid(orderid);
			newquote.setUserid(quote.getUserid());
			newquote.setVia(quote.getVia());
			newquote.setClasscd(quote.getClasscd());
			
			cancelObj.cancelOrder(newquote, "OCO");
		}else{
			SLF4JLoggerProxy.info(this,"Lenh con cua lenh OCO da khop het khong the huy, orderid:" + orderid);
		}
		
		
	}
	
	private void activeOrder(Quote quote, String noFlag){
		//kich hoat lenh
		SLF4JLoggerProxy.info(this,"Active OCO Order ***** quoteid:" + quote.getQuoteid());
		try {
			TicketQueue queThread = TicketQueue.getTicketQueueThread();
			queue = queThread.getTicketqueue();
			queue.put(quote);
		} catch (InterruptedException e) {
			SLF4JLoggerProxy.error(this, "Error when active OCO Order ***** quoteid:" + quote.getQuoteid() + "," + e);
		}
		
		if(noFlag.equals("2")){
			//xoa khoi orders list
			//HandlerCacheData.ocoMap.remove(quote.getQuoteid());
					
			//syn to DB
			//DAOCommon obj = new DAOCommon();
			//obj.updateStatus(quote, "F","OCO");
		}
	}
	
	public void orderSession(String session) throws CloneNotSupportedException{
		Set<Entry<String, Quote>> set1 =  HandlerCacheData.ocoMap.entrySet();
		Iterator<Entry<String, Quote>> it1 = set1.iterator();
		//List<String> removeList = new ArrayList<String>();
		while (it1.hasNext()) {		
			Entry<String, Quote> entry1 = it1.next();
			Quote quoteObj = entry1.getValue();
			if(quoteObj.getStatus() != null && quoteObj.getStatus().equalsIgnoreCase("N")){
				String quoteid = placeOrder(quoteObj);
				if(quoteid != null){
					//removeList.add(quoteid);
					quoteObj.setStatus("P");
					//TODO: persitent
				}
			}
			
		}
		
		/*//remove
		for(int i = 0; i < removeList.size(); i++){
			 HandlerCacheData.ocoMap.remove(removeList.get(i));
			
		}*/
	}
}
