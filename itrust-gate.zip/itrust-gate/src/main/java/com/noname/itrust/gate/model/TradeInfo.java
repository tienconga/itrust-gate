package com.noname.itrust.gate.model;

import java.math.BigDecimal;

import com.fss.fo.mserver.exchange.TransLogProtos.TransLog;

public class TradeInfo  implements ISignal, java.io.Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String id;
	private String sequencemsg;
	private String tradingdate;
	private String symbol;
	private String formattedtime;
	private String lastcolor;
	private BigDecimal formattedmatchprice;
	private String changecolor;
	private BigDecimal formattedchangevalue;
	private long formattedvol;
	private long formattedaccvol;
	private BigDecimal formattedaccval;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSequencemsg() {
		return sequencemsg;
	}
	public void setSequencemsg(String sequencemsg) {
		this.sequencemsg = sequencemsg;
	}
	public String getTradingdate() {
		return tradingdate;
	}
	public void setTradingdate(String tradingdate) {
		this.tradingdate = tradingdate;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getFormattedtime() {
		return formattedtime;
	}
	public void setFormattedtime(String formattedtime) {
		this.formattedtime = formattedtime;
	}
	public String getLastcolor() {
		return lastcolor;
	}
	public void setLastcolor(String lastcolor) {
		this.lastcolor = lastcolor;
	}
	public BigDecimal getFormattedmatchprice() {
		return formattedmatchprice;
	}
	public void setFormattedmatchprice(BigDecimal formattedmatchprice) {
		this.formattedmatchprice = formattedmatchprice;
	}
	public String getChangecolor() {
		return changecolor;
	}
	public void setChangecolor(String changecolor) {
		this.changecolor = changecolor;
	}
	public BigDecimal getFormattedchangevalue() {
		return formattedchangevalue;
	}
	public void setFormattedchangevalue(BigDecimal formattedchangevalue) {
		this.formattedchangevalue = formattedchangevalue;
	}
	public double getFormattedvol() {
		return formattedvol;
	}
	public void setFormattedvol(long formattedvol) {
		this.formattedvol = formattedvol;
	}
	public long getFormattedaccvol() {
		return formattedaccvol;
	}
	public void setFormattedaccvol(long formattedaccvol) {
		this.formattedaccvol = formattedaccvol;
	}
	public BigDecimal getFormattedaccval() {
		return formattedaccval;
	}
	public void setFormattedaccval(BigDecimal formattedaccval) {
		this.formattedaccval = formattedaccval;
	}
	
	
	public TradeInfo copyFromTransLog(TransLog tran){
		this.id = tran.getId();
		//this.sequencemsg = (String) tran.getSequenceMsg();
		this.tradingdate = tran.getTradingdate();
		this.symbol = tran.getSymbol();
		this.formattedtime = tran.getFormattedTime();
		this.lastcolor = tran.getLastColor();
		if(null != tran.getFormattedMatchPrice() && !("").equalsIgnoreCase(tran.getFormattedMatchPrice())){
			this.formattedmatchprice = new BigDecimal(tran.getFormattedMatchPrice());
		}
		this.changecolor = tran.getChangeColor();
		if(null != tran.getFormattedChangeValue() && !("").equalsIgnoreCase(tran.getFormattedChangeValue())){
			this.formattedchangevalue = new BigDecimal(tran.getFormattedChangeValue());
		}
		if(null != tran.getFormattedVol() && !("").equalsIgnoreCase(tran.getFormattedVol())){
			this.formattedvol = Long.parseLong(tran.getFormattedVol());
		}
		
		if(null != tran.getFormattedAccVol() && !("").equalsIgnoreCase(tran.getFormattedAccVol())){
			this.formattedaccvol = Long.parseLong(tran.getFormattedAccVol());
		}
		
		if(null != tran.getFormattedAccVal() && !("").equalsIgnoreCase(tran.getFormattedAccVal())){
			this.formattedaccval = new BigDecimal(tran.getFormattedAccVal());
		}
		
		return this;
	}

}
