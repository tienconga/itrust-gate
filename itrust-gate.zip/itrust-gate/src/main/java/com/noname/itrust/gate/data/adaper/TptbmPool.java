package com.noname.itrust.gate.data.adaper;
/*

 * $Id: TptbmPool.java,v 1.23 2006/03/08 02:03:53 mardhana Exp $
 * Copyright (C) 1999, 2006, Oracle. All rights reserved.
 */

//-----------------------------------------------------------
// 
// TptbmPool.java
// 
// Java version of Tptbm benchmark demonstrating use of the
// TimesTen JDBC Connection Pool.
// 
//----------------------------------------------------------
import java.sql.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.io.*;
import java.lang.*;
import java.util.*; 
import com.timesten.jdbc.*;


class TptbmPool
{

    // class constants
    static int TPTBM_TIMESTEN = 1;

    //---------------------------------------------------
    // class variables
    // All set to a default value, the default values
    // can be overwritten using command line options
    //---------------------------------------------------

    // Counters
    static public int totalTestAddRemove = 0;
    static public int totalTestResizePool = 0;

    // Number of threads to be run
    static public int numThreads = 4;

    // Number of connections in pool
    static public int poolSize = 0;

    // Number of connections in pool after resize (-testPoolResize)
    static public int poolResize = 0;

    // Seed for the random number generator
    static public int seed = 1;

    // Number of transactions each thread runs
    static public int  numXacts = 10000;

    // Percentage of read transactions
    static public int  reads = 80;

    // Percentage of insert transactions
    static public int  inserts = 0;

    // Percentage of delete transactions
    static public int deletes = 0;

    // key is used to determine how many 
    // records to populate in the database.
    // key**2 records are initially inserted.
    static public int  key = 100;

    // Min. SQL ops per transaction 
    static public int  min_xact = 1;

    // Max. SQL ops per transaction
    static public int  max_xact = 1;

    // 1 insert 3 selects 1 update / xact 
    static public int multiop = 0;

    // Used to turn the Jdbc tracing ON
    static public boolean trace = false;

    // Used to turn the thread tracing in 
    // this application ON
    static public boolean threadtrace= false;

    // Used to specify if database does 
    // not have to be populated
    static public boolean nobuild = false;
    static public boolean buildonly = false;

    // Are we testing stmtAddremove?
    static public boolean testAddRemove = false;

    // When do we test special stuff?
    static public int testAfterNumXacts = 1000;

    // Used to turn on PrefetchClose ON with client/server
    static public boolean prefetchClose = false;

    // JDBC URL string
    static public String url = null;

    // Client/server flag
    static boolean CSmode = false;

    // DBMS type
    static public int dbms = TPTBM_TIMESTEN;

    // TTree Index
    public static boolean ttree = false;

    //--------------------------------------------------
    // class constants
    //--------------------------------------------------

    public static final String insertStmt = 
	"insert into vpn_users values (?,?,?,'0000000000',?)";

    public static final String deleteStmt = 
	"delete from vpn_users where vpn_id = ? and vpn_nb = ?";

    public static final String selectStmt = 
	"select directory_nb, last_calling_party," +
	"descr from vpn_users where vpn_id = ? and vpn_nb= ?";
    public static final String[] selectHints =
        {
	    "call ttOptSetFlag('FirstRow',1)",
	    "call ttOptSetFlag('Scan',0)"
        };
    public static final String updateStmt = 
	"update vpn_users set last_calling_party" +
	"= ? where vpn_id = ? and vpn_nb = ?";

    //--------------------------------------------------
    // member constants
    //--------------------------------------------------

    //remember to give pages parameter for this statement, 
    // its calculated based on key */
    private static final String createStmtHash = 
	"CREATE TABLE vpn_users(" +
	"vpn_id             INT   NOT NULL," + 
	"vpn_nb             INT   NOT NULL," +
	"directory_nb       CHAR(10)  NOT NULL," +
	"last_calling_party CHAR(10)  NOT NULL," +
	"descr              CHAR(100) NOT NULL," +
	"PRIMARY KEY (vpn_id,vpn_nb)) unique hash on (vpn_id,vpn_nb) pages = ";

    private static final String createStmtTtree = 
	"CREATE TABLE vpn_users(" +
	"vpn_id             INT   NOT NULL," + 
	"vpn_nb             INT   NOT NULL," +
	"directory_nb       CHAR(10)  NOT NULL," +
	"last_calling_party CHAR(10)  NOT NULL," +
	"descr              CHAR(100) NOT NULL)";

    private static final String createAltDB = 
	"CREATE TABLE vpn_users(" +
	"vpn_id             number(10)   NOT NULL," + 
	"vpn_nb             number(10)   NOT NULL," +
	"directory_nb       CHAR(10)  NOT NULL," +
	"last_calling_party CHAR(10)  NOT NULL," +
	"descr              CHAR(100) NOT NULL," +
	"PRIMARY KEY (vpn_id,vpn_nb)) ";

    //-----------------------------
    // member variables
    //-----------------------------
    static private TptbmThread[] threads;
  

    //--------------------------------------------------
    // Function: main
    // Populates the database and instantiate a 
    // TptbmThreadController object
    //--------------------------------------------------
    
    public static void main(String arg[]) 
    {

    	/*TimesTenConnectionPool connPool;

    	NumberFormat formatter = new DecimalFormat("#0.00000");
       
        
    	
        // create connection pool
        connPool = new TimesTenConnectionPool(10);
    	try {
    	    connPool.initialise("jdbc:timesten:client:ttc_server=192.168.1.20;tcp_port=53397;ttc_server_dsn=FT_1122",false);
    	    connPool.addPreparedStatement("SEL",TptbmPool.selectStmt,TptbmPool.selectHints);
    	    connPool.addPreparedStatement("UPD",TptbmPool.updateStmt);
    	    connPool.addPreparedStatement("INS",TptbmPool.insertStmt);
    	    connPool.addPreparedStatement("DEL",TptbmPool.deleteStmt);
    	    connPool.enable();
    	    long start = System.currentTimeMillis();
    	    connPool.getConnection();
    	    long end = System.currentTimeMillis();
		     System.out.println("get connection time is " + formatter.format((end - start) / 1000d) + " seconds");
		     long start5 = System.currentTimeMillis();
    	    for(int i = 0; i < 10;i ++){
    	    	long start1 = System.currentTimeMillis();
        		Connection conn = connPool.getConnection();
        		long end1 = System.currentTimeMillis();
    		    System.out.println("get connection time is " + formatter.format((end1 - start1) / 1000d) + " seconds");
        	}
    	    
    	    long end5 = System.currentTimeMillis();
		    System.out.println("get connection time is " + formatter.format((end5 - start5) / 1000d) + " seconds");
    	} catch (  SQLException e  ) {
            System.err.println(e.getMessage());
    	    System.exit(1);
        }
    	*/
    	
    	
	TptbmThreadController controller;
	Connection conn = null;
	long elapsedTime;
	long tps;
	
	// New version w/ wait()/notify() calls.

	// parse arguments
	parseArgs(arg);

	// Turn the JDBC tracing on
	if(TptbmPool.trace)
	    DriverManager.setLogWriter(new PrintWriter(System.out, true));
	
	// Load the JDBC driver
	try {
		Class.forName("com.timesten.jdbc.TimesTenDriver");
		Class.forName("com.timesten.jdbc.TimesTenClientDriver");

	} catch (java.lang.ClassNotFoundException e) {
	    System.err.println(e.getMessage());
	}

	// Connect here to prevent disconnect/unload by populate 
	try {

	    if (!nobuild) {
		   // conn = DriverManager.getConnection(url+";OverWrite=1");
	    	conn = DriverManager.getConnection("jdbc:timesten:client:ttc_server=192.168.1.20;tcp_port=53397;ttc_server_dsn=FT_1122","fouser","fouser");
	    	

		// Disable auto-commit mode
		conn.setAutoCommit(false);

		// populate the database if nobuild option is not specified
		populate (conn);

		if (buildonly) {
		    conn.close();
		    System.exit(0);
		}
	    }

	    controller = new TptbmThreadController(numThreads);
	    
	    System.out.println("Executing " + numThreads + " thread(s)...");
	    System.out.println("Connection pool size: " + poolSize);
	    controller.start();
	    elapsedTime = controller.getElapsedTime();
	    tps = (long)(numThreads * ((double)numXacts/elapsedTime) * 1000);

	    if (!nobuild)
		conn.close();

	    // Print the output
	    System.out.println("Threads: \t" + numThreads);
	    System.out.println("Xact Per Thread: \t" + numXacts);
	    System.out.println("Read Only Xacts: \t" + reads);
	    System.out.println("Insert Xacts: \t" + inserts);
	    System.out.println("Delete Xacts: \t" + deletes);
	    System.out.println("Elapsed Time: \t" + elapsedTime);
	    System.out.println("Transactions Per Min: \t" + tps*60);
	    System.out.println("Transactions Per Sec: \t" + tps);
	    if (  testAddRemove  )
		System.out.println("Total add/remove tests: \t" + 
				   totalTestAddRemove);
	    if (  poolResize > 0  )
		System.out.println("Total add/remove tests: \t" + 
				   totalTestResizePool);

	} catch ( SQLException e ) {
	    printSQLException(e);
	}
    }


    //--------------------------------------------------
    // usage()
    //--------------------------------------------------
    static private void usage() {
	
	System.err.print
	    (
	     "\n" +
	     "Usage: Tptbm <-url url_string> [-v <level>] " + 
	     "[-threads <num_threads>] [-reads <read_%>] " +
	     "[-insert <insert_%>] [-delete <delete_%>] [-xucts <num_xacts>] " +
	     "[-min <min_xacts>] [-max <max_xacts>] [-seed <seed>] " +
             "[-CSCommit] [-pool <pool_size>] [-multiop]" +
	     "[-key <keys>] [-trace] [-nobuild | -build] [-h] [-help] [?]\n\n" +
	     "  -h                     Prints this message and exits.\n" + 
	     "  -help                  Same as -h.\n" +
	     "  -url <url_string>      Specifies JDBC url  string of the data store\n" +
	     "                         to connect to\n" +
	     "  -threads <num_threads> Specifies the number of concurrent \n" +
	     "                         threads. The default is 4.\n" +
	     "  -pool <pool_size>      Specifies the number of connections \n" +
	     "                         in the connection pool. The default is 1.\n" +
	     "  -reads   <read_%>      Specifies the percentage of read-only\n" +
	     "                         transactions. The default is 80.\n" +
	     "  -inserts <insert_%>    Specifies the percentage of insert\n" +
	     "                         transactions. The default is 0.\n" +
	     "  -deletes <delete_%>    Specifies the percentage of delete\n" +
	     "                         transactions. The default is 0.\n" +
	     "  -key     <keys>        Specifies the number of records (squared)\n" +
	     "                         to initially populate in the data store.\n" +
	     "                         The default value for keys is 100.\n" +
	     "  -xacts   <xacts>       Specifies the number of transactions\n" +
	     "                         that each thread should run.\n" + 
	     "                         The default is 10000.\n" +
             "  -seed    <seed>        Specifies the seed for the random \n" +
             "                         number generator.\n" +
             "  -min   <min_xacts>     Minimum operations per transaction.\n" +
             "                         Default is 1.\n" +
             "  -max   <max_xacts>     Maximum operations per transaction.\n" +
             "                         Default is 1.\n" +
             "                         Operations in a transaction randomly chosen\n" +
             "                         between min and max.\n" +
	     "  -multiop               1 insert, 3 selects, 1 update / transaction.\n" +
	     "  -CSCommit              Turn on prefetchClose for client/server\n" +
	     "  -ttree                 TTree rather than hash index\n" +
	     "  -trace                 Turns the JDBC tracing on\n" +
	     "  -nobuild               Do not build the database\n" +
	     "  -build                 Builds database and exits\n" +
	     "Special test options:\n" +
	     "  -testPoolAddRemove     Tests connection pool dynamic statement\n" +
	     "                         addition and removal.\n" +
	     "  -testPoolResize <n>    Tests resizing the connection pool\n" +
	     "                         so that it contains 'n' connections.\n" +
	     "  -testPoolNumXacts <n>  Tests resizing/add-remove every <n>\n" +
	     "                         transactions.\n"
	     );
	System.exit(1);
    }


    //--------------------------------------------------
    //
    // Function: populate
    //
    // Description: Connects to the datastore, 
    // inserts key**2 records, and disconnects
    //
    //--------------------------------------------------

    static private void populate (Connection conn) {

	Statement stmt;
	PreparedStatement pstmt;
	int outerIndex, innerIndex;
	int cc = 0;
	Timer clock = new Timer();
	int pages = (key*key)/256;

	System.out.println("Populating benchmark datastore...");
	try {

	    if (pages < 40) pages = 40;
	    if (multiop == 1) {
	        /* size for expected number of inserts, 20% of -xact option */
		int moppgs = (numXacts * numThreads * 2)/(256*10);
		if (moppgs > pages)
		    pages = moppgs;
	    }

	    // Create a Statement object
	    stmt = conn.createStatement();

	    // Execute the create table statement
             if (ttree) {
		stmt.executeUpdate(createStmtTtree);
		stmt.executeUpdate("create unique index vpn_idx " +
				   "on vpn_users(vpn_id,vpn_nb)");
	     } 
	     else
		stmt.executeUpdate(createStmtHash + pages);

	    // Prepare the insert statement
	    pstmt = conn.prepareStatement(insertStmt);

	    // commit 
	    conn.commit();

	    clock.start();

	    // Insert key**2 records
	    for(outerIndex = 0; outerIndex < key; outerIndex++) 
	    {
		// commit every 30 rows to reduce temp space reqs
		cc++;
		if ( (cc % 30) == 0) 
		{
		    cc = 0;
		    conn.commit();
		}
		for ( innerIndex = 0; innerIndex < key; innerIndex++)
		{
		    pstmt.setInt(1, outerIndex);
		    pstmt.setInt(2, innerIndex);
		    pstmt.setString(3, "55"+innerIndex+outerIndex);
		    pstmt.setString(4, "<place holder for description of VPN " +
				    outerIndex + " extension " + innerIndex);

		    pstmt.executeUpdate();
		}
	    }

	    // commit 
	    conn.commit();

	    clock.stop();

	    stmt.close();
	    pstmt.close();
	   
	    long ms = clock.getTimeInMs();

	    if (ms > 0) {
		long tps = (long) ((double)(TptbmPool.key*TptbmPool.key)/ms * 1000);
		System.out.println ("Datastore populated with " + 
				    TptbmPool.key*TptbmPool.key + 
				    " rows in " +
				    ms + " ms" + " (" +
				    tps + " TPS)");
	    }
	    //try {
	    //java.lang.Thread.sleep(5000);
	    //}
	    //	    catch (java.lang.InterruptedException e) {
	    //		;
	    //	    }

	} catch ( SQLException e ) {
	    printSQLException(e);
	}
    }


    //--------------------------------------------------
    //
    // Function: parseArgs
    // 
    // Parses command line arguments
    //
    //--------------------------------------------------
    private static void parseArgs( String[] args) {
	int i=0;
	//	System.out.println("args.length: " + args.length);	
	while(i<args.length) {

	    // Command line help
	    if(args[i].equalsIgnoreCase("-h") || 
	       args[i].equalsIgnoreCase("-help")) {
		usage();
	    }

	    // JDBC url string
	    else if(args[i].equalsIgnoreCase("-url")) {
		if(i > args.length) {
		    usage();
		}
		
		url = args[i+1];
		i += 2;
	    }

	    // number of threads
	    else if(args[i].equalsIgnoreCase("-threads")) {
		if(i > args.length) {
		    usage();
		}
		numThreads = Integer.parseInt(args[i+1]);
		i+=2;
	    }

	    // pool size
	    else if(args[i].equalsIgnoreCase("-pool")) {
		if(i > args.length) {
		    usage();
		}
		poolSize = Integer.parseInt(args[i+1]);
		i+=2;
	    }

	    // test pool resize
	    else if(args[i].equalsIgnoreCase("-testPoolResize")) {
		if(i > args.length) {
		    usage();
		}
		poolResize = Integer.parseInt(args[i+1]);
		i+=2;
	    }

	    // test pool transactions
	    else if(args[i].equalsIgnoreCase("-testPoolNumXacts")) {
		if(i > args.length) {
		    usage();
		}
		testAfterNumXacts = Integer.parseInt(args[i+1]);
		i+=2;
	    }

	    // number of transactions for each thread
	    else if(args[i].equalsIgnoreCase("-xacts")) {
		if(i > args.length) {
		    usage();
		}
		numXacts = Integer.parseInt(args[i+1]);
			i+=2;
	    }
	    
            // seed for random number generator
            else if(args[i].equalsIgnoreCase("-seed")) {
                if(i > args.length) {
                    usage();
                }
                seed = Integer.parseInt(args[i+1]);
                i+=2;
            }

	    // Percentage of read transactions
	    else if(args[i].equalsIgnoreCase("-reads")) {
		if(i > args.length) {
		    usage();
		}
		reads = Integer.parseInt(args[i+1]);
		i+=2;
	    }

	    // percentage of insert transactions
	    else if(args[i].equalsIgnoreCase("-inserts")) {
		if(i > args.length) {
		    usage();
		}
		inserts = Integer.parseInt(args[i+1]);
		i+=2;
	    }

	    // percentage of delete transactions
	    else if(args[i].equalsIgnoreCase("-deletes")) {
		if(i > args.length) {
		    usage();
		}
		deletes = Integer.parseInt(args[i+1]);
		i+=2;
	    }

	    // key to determine number of records to 
	    // insert initially
	    else if(args[i].equalsIgnoreCase("-key")) {
		if(i > args.length) {
		    usage();
		}
		key = Integer.parseInt(args[i+1]);
		i+=2;
		if(key < 0)
		    System.err.println(
			  "key flag requires a positive integer argument");
	    }

	    // minimum number of statements/transaction
	    else if(args[i].equalsIgnoreCase("-min")) {
		if(i > args.length) {
		    usage();
		}
		min_xact = Integer.parseInt(args[i+1]);
		i+=2;
		if(key < 0)
		    System.err.println(
			  "-min flag requires a positive integer argument");
	    }

	    // maximum number of statements/transaction
	    else if(args[i].equalsIgnoreCase("-max")) {
		if(i > args.length) {
		    usage();
		}
		max_xact = Integer.parseInt(args[i+1]);
		i+=2;
		if(key < 0)
		    System.err.println(
                          "-max flag requires a positive integer argument");
	    }

	    // prefetchClose ON
	    else if(args[i].equalsIgnoreCase("-CSCommit")) {
		if(i > args.length) {
		    usage();
		}
		prefetchClose = true;
		i += 1;
	    }

	    // multiop
	    else if(args[i].equalsIgnoreCase("-multiop")) {
		if(i > args.length) {
		    usage();
		}
		multiop = 1;
		min_xact = 5;
		max_xact = 5;
		reads = 60;
		inserts = 20;
		i += 1;
	    }

	    // ttree
	    else if(args[i].equalsIgnoreCase("-ttree")) {
		if(i > args.length) {
		    usage();
		}
		ttree = true;
		i += 1;
	    }

	    // JDBC tracing
	    else if(args[i].equalsIgnoreCase("-trace")) {
		if(i > args.length) {
		    usage();
		}
		trace = true;
		i += 1;
	    }

	    // Thread tracing: to complement JDBC tracing
	    else if(args[i].equalsIgnoreCase("-threadtrace")) {
		if(i > args.length) {
		    usage();
		}
		threadtrace= true;
		i += 1;
	    }

	    // Do not build the database
	    else if(args[i].equalsIgnoreCase("-nobuild")) {
		if(i > args.length) {
		    usage();
		}
		nobuild = true;
		i += 1;
	    }

	    // test statement add / remove?
	    else if(args[i].equalsIgnoreCase("-testPoolAddRemove")) {
		if(i > args.length) {
		    usage();
		}
		testAddRemove = true;
		i += 1;
	    }

	    // Build and exit
	    else if(args[i].equalsIgnoreCase("-build")) {
		if(i > args.length) {
		    usage();
		}
		buildonly = true;
		i += 1;
	    }
	    else {
		usage();
	    }
	}

	if ((reads + inserts + deletes) > 100){
	    System.err.println("Transaction mix should not exceed 100");
	    usage();
	}

	if (multiop == 0) {
	  if(numThreads * ( numXacts/100 * (float)inserts) > (key * key)) {
	    System.err.println("Inserts as part of transaction mix exceed\n" +
			       "number initially populated into data store." );
	    usage();
	  }

	  if(numThreads * ( numXacts/100 * (float)deletes) > (key * key)) {
	    System.err.println("Deletes as part of transaction mix exceed\n" +
			       "number initially populated into data store." );
	    usage();
	  }
	}

	if (nobuild && buildonly) {
	    System.err.println("Please specify either -nobuild OR -build");
	    usage();
	}

	if(url == null) {
	    System.err.println("\nURL is required program argument\n");
	    usage();
	}

	// check pool size and adjust if required
	if (  poolSize < 1  )
	    poolSize = numThreads;

	if (  testAfterNumXacts < 0  )
	    testAfterNumXacts = 0;

    }


    public static void printSQLException ( SQLException ex )
    {
	for ( ; ex != null; ex = ex.getNextException() )
	{
	    System.out.println(ex.getMessage()); 
	    System.out.println("Vendor Error Code: " + ex.getErrorCode());
	    System.out.println("SQL State: " + ex.getSQLState());
	    ex.printStackTrace();
	}
    }

    
}

//--------------------------------------------------
// Class: TptbmThread
//--------------------------------------------------

class TptbmThread extends Thread
{
    //--------------------------------------------------
    // Member variables
    //--------------------------------------------------

    // connection pool
    private TimesTenConnectionPool connPool = null;
    // connection
    private TimesTenPooledConnection connection = null;

    // Prepared select statement for read xacts
    private TimesTenPreparedStatement prepSelStmt = null;

    // Prepared Insert statement for insert xacts
    private TimesTenPreparedStatement prepInsStmt = null;

    // Prepared Delete statement for delete xacts
    private TimesTenPreparedStatement prepDelStmt = null;

    // Prepared Update statement for update xacts
    private TimesTenPreparedStatement prepUpdStmt = null;

    // Threads id used for thread tracing
    private int id;
    
    // Each thread insert in a perticular area of the table
    // so they do not run into each other
    private int insert_start;
    private int delete_start;

    // Pointer in the table for the current thread
    private int insert_present = 0;
    private int delete_present = 0;
    
    // Flags to control the thread execution 
    private boolean go = false; 
    private boolean ready = false;
    private boolean done = false;

    // Stuff for special tests (in thread 0)
    private int  testAfterNumXacts = 1000;
    
    

    //--------------------------------------------------
    // Constructor
    //--------------------------------------------------
    public TptbmThread(int id) {
	if(TptbmPool.threadtrace)
	    System.out.println("constructing thread: " + id);
	this.id = id;
    }

    public void setConnPool(TimesTenConnectionPool ttpool) {
	this.connPool = ttpool;
    }

    //--------------------------------------------------
    // Method: run
    // Overwrites the run method in the Thread class
    // Called when start is called on the thread
    //--------------------------------------------------
    public void run()
    {
	if(TptbmPool.threadtrace)
	    System.out.println("started running thread: " + id);
	

	// Timer clock = new Timer();

	try {

	    // Do all the initialization work here(e.g. connect)
	    initialize();
	
	    setReady();

	
	    // Wait here until parent indicates that threads can start execution
	    if(TptbmPool.threadtrace)
		System.out.println(
                      "thread " + id + " is waiting for the parent's signal");
	    // Block and wait for go.
        goYet();
	    // start execution
	    execute();
	    
	} catch( SQLException e) {
	    TptbmPool.printSQLException(e);
	}
	finally {
	    // does not harm to set the ready again in case we get an exception 
	    // in the intialization and parent is still wating for ready flag.
	    setReady();
	    setDone(); 
	}
    }
    
    // Called by the controller class
    // to indicate that thread can start
    // executing
    public synchronized void setGo() {
	go = true;
    notify();
    }
    
    // Called by TptbmThread class
    // to check if the thread can start executing
    public synchronized boolean goYet() {
    try {
      while(!go) {
        wait();
      }      
    }
    catch (InterruptedException iex) {
      iex.printStackTrace();
    }
    return go;
    }   
    
    public synchronized void setReady() {
    ready = true;
    notify();
    }
    // Called by the controller class
    // to check if the thread is ready
    // to execute yet i.e. thread is 
    // finished initialization
    public synchronized boolean readyYet() {
      try {
        while(!ready) {
          wait();
        }      
      }
      catch (InterruptedException iex) {
        iex.printStackTrace();
      }
	return ready;
    }
    
    public synchronized void setDone() {
      done = true;
      notify();
    }    
    //--------------------------------------------------
    // To check if the thread is done executing
    //--------------------------------------------------    
    public synchronized boolean doneYet() {
      try {
        while(!done) {
          wait();
        }      
      }
      catch (InterruptedException iex) {
        iex.printStackTrace();
      }
	return done;
    }

    //--------------------------------------------------
    // testAddRemoveStmt - test statement addition and 
    // removal
    //--------------------------------------------------
    private void testAddRemoveStmt()
	    throws SQLException
    {
	// System.out.println("Thread " + this.id + ": About to remove 2 statements\n");
	if (  !connPool.suspend()  )
	    connPool.waitforQuiescent();
	connPool.removePreparedStmt("SEL");
	connPool.removePreparedStmt("UPD");
	// System.out.println("Thread " + this.id + ": About to add 2 statements\n");
	connPool.addPreparedStatement("SEL",TptbmPool.selectStmt,TptbmPool.selectHints);
	connPool.addPreparedStatement("UPD",TptbmPool.updateStmt);
	TptbmPool.totalTestAddRemove++;
	connPool.enable();
	// System.out.println("Thread " + this.id + ": Statement add/remove test completed\n");
    }

    //--------------------------------------------------
    // testResizePool - test resizing the connection
    // pool
    //--------------------------------------------------
    private void testResizePool(int newSize)
	    throws SQLException
    {
	int currSize = connPool.getPoolSize();

	// System.out.println("Thread " + this.id + ": About to resize pool from " + currSize + " connections to " + newSize + " connections\n");
	if (  !connPool.suspend()  )
	    connPool.waitforQuiescent();
	currSize = connPool.resizePool(newSize);
	TptbmPool.totalTestResizePool++;
	connPool.enable();
	// System.out.println("DEBUG: Thread " + this.id + ": Pool resize completed - new size = " + currSize + "\n");
    }

    //--------------------------------------------------
    // Method : execute 
    // It executes specified number of transaction for 
    // the thread. Based on the transaction mix specified
    // it executes a read/insert/update
    //--------------------------------------------------
    private void execute() 
	    throws SQLException
    {

        Random rand = new Random(TptbmPool.seed);
	int id_int;
	int nb_int;
	int path = 0;
        int ops_in_xact = 1;
        int jj;
	boolean qq = true;

	if(TptbmPool.threadtrace)
	    System.out.println("Executing thread " + id );

	if (TptbmPool.min_xact == TptbmPool.max_xact)
	    ops_in_xact = TptbmPool.min_xact;
	else
	    ops_in_xact = TptbmPool.max_xact - TptbmPool.min_xact + 1;

	if (TptbmPool.multiop == 1)
	    ops_in_xact = 5;

	System.out.println("Thread " + id + " started at " + System.currentTimeMillis());
	for(int i=0; i < TptbmPool.numXacts; i++)	{

	    if (  (this.id == 0)  &&
		  ( (i%testAfterNumXacts) == 0 ) )
	    {
		if (  qq && TptbmPool.testAddRemove  )
		    testAddRemoveStmt();
		if (  !qq && (TptbmPool.poolResize != 0)  )
		{
		    testResizePool(TptbmPool.poolSize+TptbmPool.poolResize);
		    TptbmPool.poolResize *= -1;
		    // TptbmPool.poolResize += 1;
		}
		qq = !qq;
	    }
	
	    connection = connPool.getConnectionWait();

	    jj = ops_in_xact;

	    while( jj > 0){
		jj--;

		// Determine what type of transaction to execute
		if (TptbmPool.multiop == 1) {
		    switch (jj) {
		    case 4: path = 2; break; //insert
		    case 3: 
		    case 2: 
		    case 1: path = 1; break; //read
		    case 0: path = 0; break; //update
		    }
		}
		else {
		  if(TptbmPool.reads != 100) 
		  {
		    // pick a number between 0 & 99
		    int randnum = (int)(rand.nextFloat() * 100);

		    if(randnum < TptbmPool.reads+TptbmPool.inserts+TptbmPool.deletes) {
		      if(randnum < TptbmPool.reads+TptbmPool.inserts) {
			if(randnum < TptbmPool.reads) {
			      path = 1; // reads
			}
			else {
			  path = 2; // insert
			}
		      }
		      else {
			path = 3; // delete
		      }
		    }
		    else {
			path = 0; // update
		    }
		  }
		  else 
		    path = 1;  // all transactions are read
		} // not multiop


		// Execute read transaction
		if( path == 1 ) {
		    ResultSet rs = null;

	            if (  prepSelStmt == null  )
			prepSelStmt = connection.getPreparedStmt("SEL");
		    // pick random values for select from the range 0 -> key-1
		    id_int = (int)((TptbmPool.key-1)*rand.nextFloat());
		    nb_int = (int)((TptbmPool.key-1)*rand.nextFloat());

		    prepSelStmt.setInt(1, id_int);
		    prepSelStmt.setInt(2, nb_int);

		    if(TptbmPool.threadtrace)
			System.out.println("Thread " + id + 
					   " is excuting select"  );
	            rs = prepSelStmt.executeQuery();
		
		    int rows=0;
		    while (rs.next())
		    {
			// System.out.println( rs.getString(1) + "\n"  );
			rs.getString(1);
			rs.getString(2);
			rs.getString(3);
		    }
		    rs.close(); 
		
		    if (jj == 0) {
		    	connection.commit();
		    }
		}
		
		// Execute update transaction
		else if ( path == 0 ) {

	            if (  prepUpdStmt == null  )
	                prepUpdStmt = connection.getPreparedStmt("UPD");
		    // pick random values for select from the range 0 -> key-1
		    id_int = (int)((TptbmPool.key-1)*rand.nextFloat());
		    nb_int = (int)((TptbmPool.key-1)*rand.nextFloat());
		    prepUpdStmt.setString(1, id_int + "x" + nb_int);
		    prepUpdStmt.setInt(2, id_int);
		    prepUpdStmt.setInt(3, nb_int);
		    if(TptbmPool.threadtrace)
			System.out.println("Thread " + id + 
					   " is excuting update"  );
		    prepUpdStmt.executeUpdate();
		    if (jj == 0) {
			connection.commit();
		    }
		}

		// Execute delete transaction
		else if (path == 3) {
	            if (  prepDelStmt == null  )
	                prepDelStmt = connection.getPreparedStmt("DEL");
		    id_int = delete_start;
		    nb_int = delete_present++;
		    prepDelStmt.setInt(1, id_int);
		    prepDelStmt.setInt(2, nb_int);
		    if(TptbmPool.threadtrace)
			System.out.println("Thread " + id + 
					   " is excuting delete"  );
		    if (delete_present == TptbmPool.key) {
			delete_present = 0;
			delete_start += TptbmPool.numThreads;
		    }
		
		    prepDelStmt.executeUpdate();
		    if (jj == 0) {
			connection.commit();
		    }
		}

		// Execute insert transaction
		else {
	            if (  prepInsStmt == null  )
	                prepInsStmt = connection.getPreparedStmt("INS");
		    id_int = insert_start;
		    nb_int = insert_present++;
		    prepInsStmt.setInt(1, id_int);
		    prepInsStmt.setInt(2, nb_int);
		    prepInsStmt.setString(3, "55"+id_int+nb_int);
		    prepInsStmt.setString(4, "<place holder for description " +
					  "of VPN " + id_int + " extension " + 
					  nb_int + ">");
		    if(TptbmPool.threadtrace)
			System.out.println("Thread " + id + 
					   " is excuting insert"  );
		    if (insert_present == TptbmPool.key) {
			insert_present = 0;
			insert_start += TptbmPool.numThreads;
		    }
		
		    prepInsStmt.executeUpdate();
		    if (jj == 0) {
			connection.commit();
		    }
		}
	    }
	    connPool.releaseConnection(connection);
	    prepSelStmt = null;
	    prepUpdStmt = null;
	    prepInsStmt = null;
	    prepDelStmt = null;
	}
	System.out.println("Thread " + id + " finished at " + System.currentTimeMillis());
    }

    //--------------------------------------------------
    // Method: initialize
    // Not much to do here since we are using a connection
    // pool created in the ThreadController
    //--------------------------------------------------
    private void initialize() throws SQLException {
	
	if(TptbmPool.threadtrace)
	    System.out.println("Initializing thread " + id );

	insert_start = TptbmPool.key + id;
	delete_start = id;
    }

    //--------------------------------------------------
    // method: cleanup
    // Again, no longer much to do here...
    //--------------------------------------------------

    public void cleanup() {
        if(TptbmPool.threadtrace)
	    System.out.println("Thread " + id + " is closing statements"  );
    }
    
} // class TptbmThread


//--------------------------------------------------
// Class TptbmThreadController
// This module is responsible for - 
// 1. creating the threads 
// 2. makeing sure that all the threads are 
//    ready to execute before they start to execute 
// 3. keeping program from exiting before all the 
//    threads are done
// 4. Timing the execution of threads
//--------------------------------------------------

class TptbmThreadController {

    //--------------------------------------------------
    // Class constants
    //--------------------------------------------------
    

    // List of all the threads
    private TptbmThread[] threads; 

    // number of threads
    private int numThreads;

    // connection pool
    private TimesTenConnectionPool connPool;

    Timer clock = new Timer();

    // Constructor
    public TptbmThreadController(int numThreads) {
	threads = new TptbmThread[numThreads];
	this.numThreads = numThreads;
        // create connection pool
        connPool = new TimesTenConnectionPool(TptbmPool.poolSize);
	try {
	    connPool.initialise(TptbmPool.url,false);
	    connPool.addPreparedStatement("SEL",TptbmPool.selectStmt,TptbmPool.selectHints);
	    connPool.addPreparedStatement("UPD",TptbmPool.updateStmt);
	    connPool.addPreparedStatement("INS",TptbmPool.insertStmt);
	    connPool.addPreparedStatement("DEL",TptbmPool.deleteStmt);
	    connPool.enable();
	    
	    //connPool.getConnection();
	} catch (  SQLException e  ) {
            System.err.println(e.getMessage());
	    System.exit(1);
        }
    }

    //--------------------------------------------------
    // Method: start
    //--------------------------------------------------
    public synchronized void start() {

	if(TptbmPool.threadtrace)
	    System.out.println("Create threads");

	// Instantiate the threads
	for(int i=0; i <numThreads; i++) {
	    threads[i] = new TptbmThread(i);
	    threads[i].setConnPool(connPool);
	}

	if(TptbmPool.threadtrace)
	    System.out.println("Start all the threads");

	// Start all the threads
	for ( int i=0; i < numThreads; i++ )
	    threads[i].start();	


	if(TptbmPool.threadtrace)
	    System.out.println("Check if all the threads are ready");

	// Let all the threads initialize before
	// they start executing
	for( int i=0; i < numThreads; i++ ) {     
        // Block and check the readiness
	    while(!threads[i].readyYet() );
	}

	// Start the clock
	clock.start();

	if(TptbmPool.threadtrace)
	    System.out.println(
                  "Signal all the threads to go ahead and start execution");

	// Start all the threads
	for ( int i=0; i < numThreads; i++ )
	    threads[i].setGo();	

	if(TptbmPool.threadtrace)
	    System.out.println(
                  "Wait for all the threads to finish before exit");

	// Wait for all the threads to finish 
	// before you exit
	for( int i=0; i < numThreads; i++ ) {
	    while(!threads[i].doneYet()) {
		try {
		    threads[i].join();
		} catch ( InterruptedException e ) {
		}
	    }
	}

	// Stop the clock
	clock.stop();	

	// Cleanup all the threads
	for( int i=0; i < numThreads; i++ ) {
	    threads[i].cleanup();
	}

	try {
	    if (  !connPool.suspend()  )
	        connPool.waitforQuiescent();
	    connPool.shutdown();
	} catch ( SQLException e ) {
	    System.out.println("SQLException during pool shutdown: " + e.getMessage());
	}
    }
    

    //--------------------------------------------------
    // Method: getElapsedTime
    //--------------------------------------------------
    public long getElapsedTime() {
	return clock.getTimeInMs();
    }

}


//--------------------------------------------------
// Class: Timer
//--------------------------------------------------
class Timer {

    private long startTime = -1;
    private long endTime = -1;
    
    public void start() {
	startTime = System.currentTimeMillis();
    }
    public void stop() {
	endTime = System.currentTimeMillis();
    }
    public long getTimeInMs() {

	if((startTime == -1) || (endTime == -1)) {
	    System.err.println("call start() and stop() before this method");
	    return -1;
	}
	else if((endTime == startTime)) {
	    System.err.println(
                  "the start time and end time are the same...returning 1ms");
	    return 1;
	}
	else
	    return (endTime - startTime);
	
    }
}
