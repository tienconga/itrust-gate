package com.noname.itrust.common.rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface ConditionQuote extends Remote {
	public List<HFTViewInfo> TSOInfo() throws RemoteException;
	public List<HFTViewInfo> STOInfo() throws RemoteException;
	public List<HFTViewInfo> SEOInfo() throws RemoteException;
	public List<HFTViewInfo> PCOInfo() throws RemoteException;
	public List<HFTViewInfo> SOInfo() 	throws RemoteException;
	public List<HFTViewInfo> ICOInfo() throws RemoteException;
	public List<HFTViewInfo> CPOInfo() throws RemoteException;
	public List<HFTViewInfo> OCOInfo() throws RemoteException;
	public List<HFTViewInfo> OTOInfo() throws RemoteException;
	public List<HFTViewInfo> MCOInfo() throws RemoteException;
	public String getSession() throws RemoteException;	
}
