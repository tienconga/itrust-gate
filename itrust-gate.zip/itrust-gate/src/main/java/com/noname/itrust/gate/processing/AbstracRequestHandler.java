package com.noname.itrust.gate.processing;

import com.fss.newfo.common.model.Message;
import com.fss.newfo.common.model.Result;

public abstract class AbstracRequestHandler {
	
	public void process(Message message) throws Exception {
		Result result;
		result = execute(message);
	}

	
	public abstract Result execute(Message message) throws Exception;
}
