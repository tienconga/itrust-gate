package com.noname.itrust.gate.initialization;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Service;

import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.CacheProcessing;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.common.DateTime;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.sql.SQLStatement;

@Service
public class InitCommon {

	
	public void init(){
		initMarketInfo();
		initSysDate();
		initMaxQtty();
	}
	
	
	/**
	 * init MarketInfo
	 */
	private void initMarketInfo(){
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
	        ps = conn.prepareStatement(ConnectionManager.sqlMap.get(SQLStatement.KEY_SEL_MARKETINFO));
	        rs = ps.executeQuery();
		   
	        String exchangeCode = null;
	        String session = null;
	        while(rs.next()){
	        	
	        	exchangeCode = rs.getString("EXCHANGE");
	        	session = rs.getString("SESSIONEX");	
	        	if(exchangeCode != null && exchangeCode.equalsIgnoreCase("HSX")){
	        		HandlerCacheData.hsxSession = session;
	        	}else if(exchangeCode != null && exchangeCode.equalsIgnoreCase("HNX")){
	        		HandlerCacheData.hnxSession = session;
	        	}else if(exchangeCode != null && exchangeCode.equalsIgnoreCase("UPCOM")){
	        		HandlerCacheData.upcomSession = session;
	        	}
	        }
	        
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}
	}
	
	private void initSysDate(){
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
	        ps = conn.prepareStatement(ConnectionManager.sqlMap.get(SQLStatement.KEY_SEL_SYSCONFIG));
	        rs = ps.executeQuery();  
	       
	        while(rs.next()){	
	        	String sysdate = rs.getString("CFGVALUE");
	        	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy"); //yyyy-MM-dd
	    		Date date = formatter.parse(sysdate);
	    		DateTime.setSystemDate(date);
	        }
	        
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}
	
	}
	
	private void initMaxQtty(){
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
	        ps = conn.prepareStatement(ConnectionManager.sqlMap.get(SQLStatement.KEY_SEL_DEFRULES_MAXQTTY));
	        rs = ps.executeQuery();  
	       
	        while(rs.next()){	
	        	String refcode = rs.getString("REFCODE");
	        	Long refnval = rs.getLong("REFNVAL");
	        	if(refcode != null){
	        		refcode = refcode.substring(4);
	        		CacheProcessing.maxQttyMap.put(refcode, refnval);
	        	}
	        	
	        }
	        
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}
	
	}
}
