package com.noname.itrust.gate.aq;



public interface ITradeSender {

	/**
	 * @param order
	 */


}
