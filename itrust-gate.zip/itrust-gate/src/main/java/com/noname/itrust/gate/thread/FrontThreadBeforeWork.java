package com.noname.itrust.gate.thread;

import org.apache.log4j.Logger;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.HandlerCacheData;
import com.noname.itrust.gate.model.ISignal;
import com.noname.itrust.gate.rules.IRules;

/**
 * 
 * @author do.tran.tien
 *
 */
public class FrontThreadBeforeWork implements Runnable {

	final static Logger logger = Logger.getLogger(FrontThreadBeforeWork.class);

	private ISignal signal;
	private String threadName;
	private Quote quote;

	public FrontThreadBeforeWork(ISignal signal, String threadName,Quote quote) {
		//this.id = Thread.currentThread().getId();
		this.signal = signal;
		this.threadName = threadName;
		this.quote= quote;
	}

	private void doMyTask() {
		IRules rule = HandlerCacheData.marketHandlerMap.get(threadName);
		if(rule != null){
			rule.process(signal,quote);
		}else{
			logger.info("No processor to process signal.");
		}
		
	}

	public void run() {
		try {
			doMyTask();
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}
	}

}
