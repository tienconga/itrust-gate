package com.noname.itrust.gate.ws;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.jms.JMSException;

import org.springframework.beans.factory.annotation.Autowired;

import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.ItrustGateProperties;
import com.noname.itrust.gate.dataservice.GetDataService;
import com.noname.itrust.gate.jms.RequestGateway;


public class FrontGateService implements IFrontGateService {

	@Autowired
	private RequestGateway requestGateway;

	//@Autowired
	//private GetService getService;

	@Autowired
	private ItrustGateProperties properties;
	
	@Autowired
	private GetDataService getDataService;

	/**
	 * inputString: json formated message request return: json formated message result
	 */
	@Override
	public String sendMessage(String phonenumber) {
		//return getDataService.proces(phonenumber);
		
		String result = null;
		try {
			SLF4JLoggerProxy.info(this, "Message Request: " + phonenumber);
			result = requestGateway.request(phonenumber, properties.getProcessorQueue(), properties.getTimeout());
		} catch (JMSException e) {
			SLF4JLoggerProxy.error(this, e);
		}
		SLF4JLoggerProxy.info(this, "Message  Result: " + result);
		return result;
	}

	
	public static void main(String[] args) throws FileNotFoundException, SQLException {

	}

}
