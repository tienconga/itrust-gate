package com.noname.itrust.gate.rules;

import com.fss.newfo.common.model.Quote;
import com.noname.itrust.gate.model.ISignal;

public interface IRules {

	public void process(ISignal market,Quote quote);

	public void putRequest(Quote quote);

	public void load();

}
