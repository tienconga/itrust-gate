package com.noname.itrust.gate.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import com.fss.fo.mserver.exchange.StockInforProtos.StockInfor;

public class StockInfo implements ISignal, java.io.Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String symbol;
	private BigDecimal floor;
	private BigDecimal reference;
	private BigDecimal ceiling;
	private String stockType;
	private BigDecimal bidprice3;
	private long bidvol3;
	private BigDecimal bidprice2;
	private long bidvol2;
	private BigDecimal bidprice1;
	private long bidvol1;
	private BigDecimal closeprice;
	private long closevol;
	private double change;
	private BigDecimal offerprice1;
	private long offervol1;
	private BigDecimal offerprice2;
	private long offervol2;
	private BigDecimal offerprice3;
	private long offervol3;
	private long totaltrading;
	private BigDecimal totaltradingvalue;
	private BigDecimal averageprice;
	private BigDecimal open;
	private BigDecimal high;
	private BigDecimal low;
	private long foreignbuy;
	private long foreignsell;
	private long foreignremain;
	private long foreignroom;
	private long total_offer_qtty;
	private long total_bid_qtty;
	private BigDecimal prior_price;
	private long pt_match_qtty;
	private BigDecimal pt_match_price;
	private double pt_total_traded_qtty;
	private double pt_total_traded_value;
	private String status;
	private BigDecimal priceone;
	private BigDecimal pricetwo;
	
	
	private String stockid;
	private String fullname;
	private String tradingdate;
	private String floorcode;
	private String stocktype;
	
	
	private List<BigDecimal> priceStepList = new ArrayList<BigDecimal>();
		
	public List<BigDecimal> getPriceStepList() {
		return priceStepList;
	}
	public void setPriceStepList(List<BigDecimal> priceStepList) {
		this.priceStepList = priceStepList;
	}
	
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public BigDecimal getFloor() {
		return floor;
	}
	public void setFloor(BigDecimal floor) {
		this.floor = floor;
	}
	public BigDecimal getRefer() {
		return reference;
	}
	public void setRefer(BigDecimal refer) {
		this.reference = refer;
	}
	public BigDecimal getCeiling() {
		return ceiling;
	}
	public void setCeiling(BigDecimal ceiling) {
		this.ceiling = ceiling;
	}
	public String getStockType() {
		return stockType;
	}
	public void setStockType(String stockType) {
		this.stockType = stockType;
	}
	public BigDecimal getBidprice3() {
		return bidprice3;
	}
	public void setBidprice3(BigDecimal bidprice3) {
		this.bidprice3 = bidprice3;
	}
	public double getBidvol3() {
		return bidvol3;
	}
	public void setBidvol3(long bidvol3) {
		this.bidvol3 = bidvol3;
	}
	public BigDecimal getBidprice2() {
		return bidprice2;
	}
	public void setBidprice2(BigDecimal bidprice2) {
		this.bidprice2 = bidprice2;
	}
	public double getBidvol2() {
		return bidvol2;
	}
	public void setBidvol2(long bidvol2) {
		this.bidvol2 = bidvol2;
	}
	public BigDecimal getBidprice1() {
		return bidprice1;
	}
	public void setBidprice1(BigDecimal bidprice1) {
		this.bidprice1 = bidprice1;
	}
	public double getBidvol1() {
		return bidvol1;
	}
	public void setBidvol1(long bidvol1) {
		this.bidvol1 = bidvol1;
	}
	public BigDecimal getCloseprice() {
		return closeprice;
	}
	public void setCloseprice(BigDecimal closeprice) {
		this.closeprice = closeprice;
	}
	public double getClosevol() {
		return closevol;
	}
	public void setClosevol(long closevol) {
		this.closevol = closevol;
	}
	public double getChange() {
		return change;
	}
	public void setChange(double change) {
		this.change = change;
	}
	public BigDecimal getOfferprice1() {
		return offerprice1;
	}
	public void setOfferprice1(BigDecimal offerprice1) {
		this.offerprice1 = offerprice1;
	}
	public double getOffervol1() {
		return offervol1;
	}
	public void setOffervol1(long offervol1) {
		this.offervol1 = offervol1;
	}
	public BigDecimal getOfferprice2() {
		return offerprice2;
	}
	public void setOfferprice2(BigDecimal offerprice2) {
		this.offerprice2 = offerprice2;
	}
	public double getOffervol2() {
		return offervol2;
	}
	public void setOffervol2(long offervol2) {
		this.offervol2 = offervol2;
	}
	public BigDecimal getOfferprice3() {
		return offerprice3;
	}
	public void setOfferprice3(BigDecimal offerprice3) {
		this.offerprice3 = offerprice3;
	}
	public double getOffervol3() {
		return offervol3;
	}
	public void setOffervol3(long offervol3) {
		this.offervol3 = offervol3;
	}
	public double getTotaltrading() {
		return totaltrading;
	}
	public void setTotaltrading(long totaltrading) {
		this.totaltrading = totaltrading;
	}
	public BigDecimal getTotaltradingvalue() {
		return totaltradingvalue;
	}
	public void setTotaltradingvalue(BigDecimal totaltradingvalue) {
		this.totaltradingvalue = totaltradingvalue;
	}
	public BigDecimal getAverageprice() {
		return averageprice;
	}
	public void setAverageprice(BigDecimal averageprice) {
		this.averageprice = averageprice;
	}
	public BigDecimal getOpen() {
		return open;
	}
	public void setOpen(BigDecimal open) {
		this.open = open;
	}
	public BigDecimal getHigh() {
		return high;
	}
	public void setHigh(BigDecimal high) {
		this.high = high;
	}
	public BigDecimal getLow() {
		return low;
	}
	public void setLow(BigDecimal low) {
		this.low = low;
	}
	public double getForeignbuy() {
		return foreignbuy;
	}
	public void setForeignbuy(long foreignbuy) {
		this.foreignbuy = foreignbuy;
	}
	public double getForeignsell() {
		return foreignsell;
	}
	public void setForeignsell(long foreignsell) {
		this.foreignsell = foreignsell;
	}
	public double getForeignremain() {
		return foreignremain;
	}
	public void setForeignremain(long foreignremain) {
		this.foreignremain = foreignremain;
	}
	public double getForeignroom() {
		return foreignroom;
	}
	public void setForeignroom(long foreignroom) {
		this.foreignroom = foreignroom;
	}
	public double getTotal_offer_qtty() {
		return total_offer_qtty;
	}
	public void setTotal_offer_qtty(long total_offer_qtty) {
		this.total_offer_qtty = total_offer_qtty;
	}
	public double getTotal_bid_qtty() {
		return total_bid_qtty;
	}
	public void setTotal_bid_qtty(long total_bid_qtty) {
		this.total_bid_qtty = total_bid_qtty;
	}
	public BigDecimal getPrior_price() {
		return prior_price;
	}
	public void setPrior_price(BigDecimal prior_price) {
		this.prior_price = prior_price;
	}
	public double getPt_match_qtty() {
		return pt_match_qtty;
	}
	public void setPt_match_qtty(long pt_match_qtty) {
		this.pt_match_qtty = pt_match_qtty;
	}
	public BigDecimal getPt_match_price() {
		return pt_match_price;
	}
	public void setPt_match_price(BigDecimal pt_match_price) {
		this.pt_match_price = pt_match_price;
	}
	public double getPt_total_traded_qtty() {
		return pt_total_traded_qtty;
	}
	public void setPt_total_traded_qtty(double pt_total_traded_qtty) {
		this.pt_total_traded_qtty = pt_total_traded_qtty;
	}
	public double getPt_total_traded_value() {
		return pt_total_traded_value;
	}
	public void setPt_total_traded_value(double pt_total_traded_value) {
		this.pt_total_traded_value = pt_total_traded_value;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public BigDecimal getPriceone() {
		return priceone;
	}
	public void setPriceone(BigDecimal priceone) {
		this.priceone = priceone;
	}
	public BigDecimal getPricetwo() {
		return pricetwo;
	}
	public void setPricetwo(BigDecimal pricetwo) {
		this.pricetwo = pricetwo;
	}
	
	public BigDecimal getReference() {
		return reference;
	}
	public void setReference(BigDecimal reference) {
		this.reference = reference;
	}
	public String getStockid() {
		return stockid;
	}
	public void setStockid(String stockid) {
		this.stockid = stockid;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getTradingdate() {
		return tradingdate;
	}
	public void setTradingdate(String tradingdate) {
		this.tradingdate = tradingdate;
	}
	public String getFloorcode() {
		return floorcode;
	}
	public void setFloorcode(String floorcode) {
		this.floorcode = floorcode;
	}
	public String getStocktype() {
		return stocktype;
	}
	public void setStocktype(String stocktype) {
		this.stocktype = stocktype;
	}
	public StockInfo copyFromStockInfor(StockInfor stock){
		//this.id = stock.getId();
		this.symbol = stock.getSymbol();
		this.stockid = stock.getStockId();
		this.fullname = stock.getFullName();
		this.tradingdate = stock.getTradingdate();
		this.floorcode = stock.getFloorCode();
		this.stocktype = stock.getStockType();
		
		if(null != stock.getCeiling() && !("").equalsIgnoreCase(stock.getCeiling())){
			this.ceiling = new BigDecimal(stock.getCeiling());
		}
		
		if(null != stock.getFloor() && !("").equalsIgnoreCase(stock.getFloor())){
			this.floor = new BigDecimal(stock.getFloor());
		}
		
		if(null != stock.getReference() && !("").equalsIgnoreCase(stock.getReference())){
			this.reference = new BigDecimal(stock.getReference());
		}
		
		if(null != stock.getBidPrice3() && !("").equalsIgnoreCase(stock.getBidPrice3())){
			this.bidprice3 = new BigDecimal(stock.getBidPrice3());
		}
		
		if(null != stock.getBidVol3() && !("").equalsIgnoreCase(stock.getBidVol3())){
			this.bidvol3 = Long.parseLong(stock.getBidVol3());
		}
		
		if(null != stock.getBidPrice2() && !("").equalsIgnoreCase(stock.getBidPrice2())){
			this.bidprice2 = new BigDecimal(stock.getBidPrice2());
		}
		
		if(null != stock.getBidVol2() && !("").equalsIgnoreCase(stock.getBidVol2())){
			this.bidvol2 = Long.parseLong(stock.getBidVol2());
		}
		
		if(null != stock.getBidPrice1() && !("").equalsIgnoreCase(stock.getBidPrice1())){
			this.bidprice1 = new BigDecimal(stock.getBidPrice1());
		}
		
		if(null != stock.getBidVol1() && !("").equalsIgnoreCase(stock.getBidVol1())){
			this.bidvol1 = Long.parseLong(stock.getBidVol1());
		}
		
		if(null != stock.getClosePrice() && !("").equalsIgnoreCase(stock.getClosePrice())){
			this.closeprice = new BigDecimal(stock.getClosePrice());
		}
		
		if(null != stock.getCloseVol() && !("").equalsIgnoreCase(stock.getCloseVol())){
			this.closevol = Long.parseLong(stock.getCloseVol());
		}
		
		if(null != stock.getChange() && !("").equalsIgnoreCase(stock.getChange())){
			this.change = Double.parseDouble(stock.getChange());
		}
		
		if(null != stock.getOfferPrice1() && !("").equalsIgnoreCase(stock.getOfferPrice1())){
			this.offerprice1 = new BigDecimal(stock.getOfferPrice1());
		}
		
		if(null != stock.getOfferVol1() && !("").equalsIgnoreCase(stock.getOfferVol1())){
			this.offervol1 = Long.parseLong(stock.getOfferVol1());
		}
		
		if(null != stock.getOfferPrice2() && !("").equalsIgnoreCase(stock.getOfferPrice2())){
			this.offerprice2 = new BigDecimal(stock.getOfferPrice2());
		}
		
		if(null != stock.getOfferVol2() && !("").equalsIgnoreCase(stock.getOfferVol2())){
			this.offervol2 = Long.parseLong(stock.getOfferVol2());
		}
		
		if(null != stock.getOfferPrice3() && !("").equalsIgnoreCase(stock.getOfferPrice3())){
			this.offerprice3 = new BigDecimal(stock.getOfferPrice3());
		}
		
		if(null != stock.getOfferVol3() && !("").equalsIgnoreCase(stock.getOfferVol3())){
			this.offervol3 = Long.parseLong(stock.getOfferVol3());
		}
		
		if(null != stock.getTotalTrading() && !("").equalsIgnoreCase(stock.getTotalTrading())){
			this.totaltrading = Long.parseLong(stock.getTotalTrading());
		}
		
		if(null != stock.getTotalTradingValue() && !("").equalsIgnoreCase(stock.getTotalTradingValue())){
			this.totaltradingvalue = new BigDecimal(stock.getTotalTradingValue());
		}
		
		if(null != stock.getAveragePrice() && !("").equalsIgnoreCase(stock.getAveragePrice())){
			this.averageprice = new BigDecimal(stock.getAveragePrice());
		}
		
		if(null != stock.getOpen() && !("").equalsIgnoreCase(stock.getOpen())){
			this.open = new BigDecimal(stock.getOpen());
		}
		
		if(null != stock.getHigh() && !("").equalsIgnoreCase(stock.getHigh())){
			this.high = new BigDecimal(stock.getHigh());
		}
		
		if(null != stock.getLow() && !("").equalsIgnoreCase(stock.getLow())){
			this.low = new BigDecimal(stock.getLow());
		}
		
		if(null != stock.getForeignBuy() && !("").equalsIgnoreCase(stock.getForeignBuy())){
			this.foreignbuy = Long.parseLong(stock.getForeignBuy());
		}
		
		if(null != stock.getForeignSell() && !("").equalsIgnoreCase(stock.getForeignSell())){
			this.foreignsell = Long.parseLong(stock.getForeignSell());
		}
		
		if(null != stock.getForeignRemain() && !("").equalsIgnoreCase(stock.getForeignRemain())){
			this.foreignremain = Long.parseLong(stock.getForeignRemain());
		}
		
		if(null != stock.getForeignRoom() && !("").equalsIgnoreCase(stock.getForeignRoom())){
			this.foreignroom = Long.parseLong(stock.getForeignRoom());
		}
		
		if(null != stock.getTOTALOFFERQTTY() && !("").equalsIgnoreCase(stock.getTOTALOFFERQTTY())){
			this.total_offer_qtty = Long.parseLong(stock.getTOTALOFFERQTTY());
		}
		
		if(null != stock.getTOTALBIDQTTY() && !("").equalsIgnoreCase(stock.getTOTALBIDQTTY())){
			this.total_bid_qtty = Long.parseLong(stock.getTOTALBIDQTTY());
		}
		
		if(null != stock.getPRIORPRICE() && !("").equalsIgnoreCase(stock.getPRIORPRICE())){
			this.prior_price = new BigDecimal(stock.getPRIORPRICE());
		}
		
		if(null != stock.getPTMATCHQTTY() && !("").equalsIgnoreCase(stock.getPTMATCHQTTY())){
			this.pt_match_qtty = Long.parseLong(stock.getPTMATCHQTTY());
		}
		
		if(null != stock.getPTMATCHPRICE() && !("").equalsIgnoreCase(stock.getPTMATCHPRICE())){
			this.pt_match_price = new BigDecimal(stock.getPTMATCHPRICE());
		}
		
		if(null != stock.getPTTOTALTRADEDQTTY() && !("").equalsIgnoreCase(stock.getPTTOTALTRADEDQTTY())){
			this.pt_total_traded_qtty = Double.parseDouble(stock.getPTTOTALTRADEDQTTY());
		}
		
		if(null != stock.getPTTOTALTRADEDVALUE() && !("").equalsIgnoreCase(stock.getPTTOTALTRADEDVALUE())){
			this.pt_total_traded_value = Double.parseDouble(stock.getPTTOTALTRADEDVALUE());
		}
		this.status = stock.getStatus();
		
		if(null != stock.getPriceOne() && !("").equalsIgnoreCase(stock.getPriceOne())){
			this.priceone = new BigDecimal(stock.getPriceOne());
		}
		
		if(null != stock.getPriceTwo() && !("").equalsIgnoreCase(stock.getPriceTwo())){
			this.pricetwo = new BigDecimal(stock.getPriceTwo());
		}

		return this;
		
	}
	

}
