package com.noname.itrust.gate.common;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Properties {
	
	@Value("${hft.engine.file.mode}")
	private String writingFileMode;
	
	@Value("${hft.engine.file.marketinfor}")
	private String marketInforFileName;
	
	@Value("${hft.engine.file.marketinfor.filtered}")
	private String marketInfoFileName_filterd;
	
	@Value("${hft.engine.file.stockinfor}")
	private String stockinforFileName;
	
	@Value("${hft.engine.file.stockinfor.filtered}")
	private String stockinforFileName_filterd;
	
	@Value("${hft.engine.file.translog}")
	private String translogFileName;
	
	@Value("${hft.engine.file.translog.filtered}")
	private String translogFileName_filterd;
	
	@Value("${hft.engine.url.wsdlLocation}")
	private String wsdlLocation;
	
	@Value("${hft.engine.rmi.nameRemote}")
	private String nameRemote;
	
	@Value("${hft.engine.rmi.port}")
	private String port;
	
	
	public String getWritingFileMode() {
		return writingFileMode;
	}

	public void setWritingFileMode(String writingFileMode) {
		this.writingFileMode = writingFileMode;
	}

	public String getMarketInforFileName() {
		return marketInforFileName;
	}

	public void setMarketInforFileName(String marketInforFileName) {
		this.marketInforFileName = marketInforFileName;
	}

	public String getMarketInfoFileName_filterd() {
		return marketInfoFileName_filterd;
	}

	public void setMarketInfoFileName_filterd(String marketInfoFileName_filterd) {
		this.marketInfoFileName_filterd = marketInfoFileName_filterd;
	}

	public String getStockinforFileName() {
		return stockinforFileName;
	}

	public void setStockinforFileName(String stockinforFileName) {
		this.stockinforFileName = stockinforFileName;
	}

	public String getStockinforFileName_filterd() {
		return stockinforFileName_filterd;
	}

	public void setStockinforFileName_filterd(String stockinforFileName_filterd) {
		this.stockinforFileName_filterd = stockinforFileName_filterd;
	}

	public String getTranslogFileName() {
		return translogFileName;
	}

	public void setTranslogFileName(String translogFileName) {
		this.translogFileName = translogFileName;
	}

	public String getTranslogFileName_filterd() {
		return translogFileName_filterd;
	}

	public void setTranslogFileName_filterd(String translogFileName_filterd) {
		this.translogFileName_filterd = translogFileName_filterd;
	}

	public String getWsdlLocation() {
		return wsdlLocation;
	}

	public void setWsdlLocation(String wsdlLocation) {
		this.wsdlLocation = wsdlLocation;
	}

	public String getNameRemote() {
		return nameRemote;
	}

	public void setNameRemote(String nameRemote) {
		this.nameRemote = nameRemote;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}
	
}
