package com.noname.itrust.gate.sending;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import org.apache.log4j.Logger;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.github.fge.jackson.JsonLoader;
import com.noname.itrust.gate.data.dao.DAOCommon;
import com.noname.itrust.gate.initialization.InitData;
import com.noname.itrust.gate.thread.TicketQueue;

public class CancelOrderSending {

	final static Logger logger = Logger.getLogger(TicketQueue.class);

	//public static Map<String, String> cancelOrderMap = new HashMap<String, String>();
	
	/**
	 * 
	 * @param quote
	 * @param cancelFlag: OCO or else
	 * @return
	 */
	public String cancelOrder(Quote quote, String cancelFlag) {	
		try {
			return sendOrder(quote, cancelFlag);
		} catch (MalformedURLException e) {
			SLF4JLoggerProxy.error(this, "Error connect webservice, " +e);
			return null;
		}
	}
	
	public String sendOrder(Quote quote, String cancelFlag) throws MalformedURLException {/*
		String result = "";
		
		//FrontGateServiceService service = new FrontGateServiceService();
		URL url = new URL(InitData.prop.getWsdlLocation());
		FrontGateServiceService service = new FrontGateServiceService(url);
		IFrontGateService obj = service.getFrontGateServicePort();
		
		long time = System.currentTimeMillis();
		String requestid = String.valueOf(time); //TODO: get sequence
		requestid = quote.getClasscd() + requestid;
		
		String classcd = quote.getClasscd();
		
		if(classcd != null && classcd.equalsIgnoreCase("CPO")){
			DAOCommon persistentObj = new DAOCommon();
			persistentObj.saveExecuteOrder(quote,requestid, null,"CANCELING", quote.getOrderid(),"C");
		}
		
		
		
		String str = buildCancelOrderString(quote, requestid);
		result = obj.sendMessage(str);
		
		SLF4JLoggerProxy.info(this, "Send cancel message to ORS: " + str + "; RESPONE FROM ORS:" + result);

		String errorCode = "";
		//process result
		ObjectNode node;
		try {
			node = (ObjectNode) JsonLoader.fromString(result);

			JsonNode errorNode = node.get("ERRORCODE");
			JsonNode subquoteid = node.get("QUOTEID");
			JsonNode orderid = node.get("ORDERID");
			String subquoteidStr = "";
			String orderidStr = "";
			
			if (errorNode != null) {
				errorCode = errorNode.toString();

				errorCode = errorCode.replaceAll("\"", "");
								
				if(subquoteid != null){
					subquoteidStr = subquoteid.toString();
					subquoteidStr = subquoteidStr.replaceAll("\"", "");
				}
				
				if(orderid != null){
					orderidStr = orderid.toString();
					orderidStr = orderidStr.replaceAll("\"", "");
				}
								
				if(classcd != null){					
					DAOCommon persistentObj = new DAOCommon();
					persistentObj.updateResult(classcd, quote.getQuoteid(), errorCode, subquoteidStr,orderidStr);
				}
				
			} else {
				SLF4JLoggerProxy.error(this, "Error connect webservice");
			}
			
			//(String requestid, String quoteid, String subQuoteid, String errorcode, String orderid, String ordertype ) 
			DAOCommon persistentObj = new DAOCommon();
			
			if(classcd != null && classcd.equalsIgnoreCase("CPO")){
				orderidStr = quote.getOrderid();
				persistentObj.updateExecuteOrder(requestid, quote.getQuoteid(), subquoteidStr,errorCode, orderidStr,quote.getClasscd());
			}else{
				if(cancelFlag.equalsIgnoreCase("OCO")){
					quote.setReftype("M"); //phuc vu cho viec phan biet lenh huy OCO do may huy or con nguoi huy
				}
				persistentObj.saveExecuteOrder(quote, requestid, subquoteidStr,errorCode, orderidStr, quote.getReftype());
			}	

		} catch (IOException e) {
			SLF4JLoggerProxy.error(this, "Error connect webservice, " +e);
		}
		
		return errorCode;
	*/return "";}
	
	private String buildCancelOrderString(Quote quote,String requestid ){	
		String str = "{\"msgtype\":\"MSGTYPE_VALUE\",\"requestid\":\"REQUESTID_VALUE\",\"acctno\":\"ACCTNO_VALUE\"," +
				"\"orderid\":\"ORDERID_VALUE\",\"userid\":\"USERID_VALUE\",\"via\":\"E\"}";
		
		str = str.replaceAll("MSGTYPE_VALUE", "tx0100");
		
		str = str.replaceAll("REQUESTID_VALUE", requestid);
		
		str = str.replaceAll("ORDERID_VALUE", quote.getOrderid());
		
		if(quote.getUserid() != null){
			str = str.replaceAll("USERID_VALUE", quote.getUserid());
			//str = str.replaceAll("USERID_VALUE", quote.getClasscd());
		}
	
		if(quote.getAcctno() != null){
			str = str.replaceAll("ACCTNO_VALUE", quote.getAcctno());
		}
		
		return str;
	}	
}
