package com.noname.itrust.gate.model;

import java.math.BigDecimal;
import java.util.Date;

public class Trade implements ISignal, java.io.Serializable {

	static final long serialVersionUID = 1L; //assign a long value

	private String symbol;
	private long qtty;
	private BigDecimal price;
	private Date date;

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public long getQtty() {
		return qtty;
	}

	public void setQtty(long qtty) {
		this.qtty = qtty;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
