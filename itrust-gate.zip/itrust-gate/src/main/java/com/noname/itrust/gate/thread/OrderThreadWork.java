package com.noname.itrust.gate.thread;

import org.apache.log4j.Logger;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.sending.NewOrderSending;

/**
 * 
 * @author do.tran.tien
 *
 */
public class OrderThreadWork implements Runnable {

	final static Logger logger = Logger.getLogger(OrderThreadWork.class);

	private long id = 0;
	private Quote ticket;
	private String threadName;

	public OrderThreadWork(long id, Quote ticket, String threadName) {
		//this.id = Thread.currentThread().getId();
		this.id = id;
		this.ticket = ticket;
		this.threadName = threadName;

	}

	private void doMyTask() {
		NewOrderSending sender = new NewOrderSending();
		sender.placeOrder(ticket);
	}

	public void run() {
		try {
			doMyTask();
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}

	}

}
