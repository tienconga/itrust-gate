/*
 * Copyright(C) 2014 FSS Software Company
 *
 * $Id: BackendDBMgr.java,v 1.0 2014/06/26 11:08:05 tien.do Exp $
 *
 */

package com.noname.itrust.gate.data.adaper;

import java.sql.SQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fss.newfo.common.sql.SQLStatement;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;

/**
 * This Class contain Methods for connection to Database.
 * @author 	tien.do<tien.do@fssc.com.vn> $Author: tien.do$
 * @version 	$Revision: 1.0 $
 */
public class BackendDBMgr {
	
	protected final Logger log = LoggerFactory.getLogger(getClass());
	
	private static TimesTenConnectionPool connPool;
	private TimesTenPooledConnection connection = null;
	
	public TimesTenPooledConnection getConnection() {
		try {
			connection = connPool.getConnectionWait();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this , e);
		}
		return connection;
	}

	public void setConnection(TimesTenPooledConnection connection) {
		this.connection = connection;
	}

	public TimesTenConnectionPool getConnPool() {
		return connPool;
	}

	public void setConnPool(TimesTenConnectionPool connPool) {
		BackendDBMgr.connPool = connPool;
	}

	public static BackendDBMgr getInstance(){
		return new BackendDBMgr();
	}
	
	public void initConnectionPool(String url,int numConnections){
        connPool = new TimesTenConnectionPool(numConnections);
    	
        try {
    	    connPool.initialise(url,false);

    	    connPool.addCallableStatement("CALL", "call CSPKS_FO.sp_validate_buy_order(?,?,?,?,?,?)");
    	    connPool.addPreparedStatement("SEL_POOL", "SELECT GRANTED,INUSED FROM POOLROOM WHERE POLICYTYPE = 'P'");
    	    connPool.addPreparedStatement("SEL_ROOM", "SELECT GRANTED,INUSED FROM POOLROOM WHERE POLICYTYPE='R' AND REFSYMBOL=? ");
    	    
    	    connPool.addPreparedStatement("UPD_ROOM", "UPDATE POOLROOM SET INUSED=?  WHERE REFSYMBOL=? ");
    	    connPool.addPreparedStatement("INS_ALLOCATION","INSERT INTO ALLOCATION(" +
    	    							"AUTOID,ORDERID,SIDE,SYMBOL,ACCTNO,PRICE,QTTY,DOC,POOLVAL,ROOMVAL,STATUS)" +
    	    							" values(?,?,?,?,?,?,?,?,?,?,?)");
    	    connPool.addCallableStatement("CALL_SP_DEPOSIT", "call CSPKS_FO_BO.sp_process_deposit(?,?,?,?,?,?,?,?)");
    	   
    	    connPool.addPreparedStatement(SQLStatement.KEY_SEL_PORTFOLIOS,SQLStatement.SQL_SEL_PORTFOLIOS);
    	    connPool.addPreparedStatement(SQLStatement.KEY_SEL_ORDERS, SQLStatement.SQL_SEL_ORDERS);
    	    
    	    //
    	    connPool.addPreparedStatement(SQLStatement.KEY_UDP_POOLROOM_POLICYTYPE, SQLStatement.SQL_UDP_POOLROOM_POLICYTYPE);
    	    connPool.addPreparedStatement(SQLStatement.KEY_UDP_ACCOUNTS_MONEY, SQLStatement.SQL_UDP_ACCOUNTS_MONEY);
    	    connPool.addPreparedStatement(SQLStatement.KEY_SEL_ACCOUNTS_ACCTNO, SQLStatement.SQL_SEL_ACCOUNTS_ACCTNO);   	    
    	    connPool.addPreparedStatement(SQLStatement.KEY_SEL_PORTFOLIOS_UNMARK, SQLStatement.SQL_SEL_PORTFOLIOS_UNMARK);
    	    connPool.addPreparedStatement(SQLStatement.KEY_SEL_HIKI_SYMBOL, SQLStatement.SQL_SEL_HIKI_SYMBOL);
    	    connPool.addPreparedStatement(SQLStatement.KEY_SEL_POOLROOM_REFSYMBOL, SQLStatement.SQL_SEL_POOLROOM_REFSYMBOL);
    	    connPool.addPreparedStatement(SQLStatement.KEY_UDP_PORTFOLIOS_RECEIVING, SQLStatement.SQL_UDP_PORTFOLIOS_RECEIVING);
    	    connPool.addPreparedStatement(SQLStatement.KEY_UDP_POOLROOM_INUSED, SQLStatement.SQL_UDP_POOLROOM_INUSED);
    	    connPool.addPreparedStatement(SQLStatement.KEY_SEL_POOL_INUSED, SQLStatement.SQL_SEL_POOL_INUSED);
    	    connPool.addPreparedStatement(SQLStatement.KEY_UDP_PORTFOLIOS_TRADE, SQLStatement.SQL_UDP_PORTFOLIOS_TRADE);
    	    connPool.addPreparedStatement(SQLStatement.KEY_INS_ALLOCATION, SQLStatement.SQL_INS_ALLOCATION);
    	    connPool.addPreparedStatement(SQLStatement.KEY_SEL_BASKETS_ACCOUNTS, SQLStatement.SQL_SEL_BASKETS_ACCOUNTS);
    	    connPool.addPreparedStatement(SQLStatement.KEY_SEL_ACCOUNTS_ALL, SQLStatement.SQL_SEL_ACCOUNTS_ALL);
    	    connPool.addPreparedStatement(SQLStatement.KEY_SEL_ROOM_INUSED, SQLStatement.SQL_SEL_ROOM_INUSED);
    	    connPool.addPreparedStatement(SQLStatement.KEY_SEL_PORTFOLIOS_ALL, SQLStatement.SQL_SEL_PORTFOLIOS_ALL);
    	    connPool.addPreparedStatement(SQLStatement.KEY_SEL_ORDERS_BUY, SQLStatement.SQL_SEL_ORDERS_BUY);
    	    connPool.addPreparedStatement(SQLStatement.KEY_SEL_ORDERS_SELL, SQLStatement.SQL_SEL_ORDERS_SELL);
    	    
    	    connPool.addPreparedStatement(SQLStatement.Order.KEY_SQL_UPDATE_QUOTE_STATUS, SQLStatement.Order.SQL_UPDATE_QUOTE_STATUS);
    	    
    	    //store procedure
    	    connPool.addCallableStatement(SQLStatement.KEY_SP_CAL_AVAILABLE_BALANCE, SQLStatement.SP_CAL_AVAILABLE_BALANCE);
    	    
    	    connPool.addCallableStatement(SQLStatement.Order.KEY_SP_CAL_CREATE_QUOTE, SQLStatement.Order.SP_CAL_CREATE_QUOTE);
    	    connPool.addCallableStatement(SQLStatement.Order.KEY_SP_CAL_PROCESS_ORDER_BUY, SQLStatement.Order.SP_CAL_PROCESS_ORDER_BUY);
    	    connPool.enable();
    	   
    	} catch (SQLException e) {
            System.err.println("Error:" + e.getMessage());
    	    System.exit(1);
        }
	}
	
	public void closeConnection(TimesTenPooledConnection connection) {
		try {
			connPool.releaseConnection(connection);
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this , e);
		}
	}

}
