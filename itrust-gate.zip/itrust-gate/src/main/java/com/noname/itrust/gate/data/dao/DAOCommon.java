package com.noname.itrust.gate.data.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import oracle.jdbc.OracleTypes;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;
import com.noname.itrust.gate.caching.CacheProcessing;
import com.noname.itrust.gate.converter.Converter;
import com.noname.itrust.gate.data.adaper.ConnectionManager;
import com.noname.itrust.gate.sending.CancelOrderSending;
import com.noname.itrust.gate.sql.SQLStatement;

public class DAOCommon {
	
	public void updateResult(String tablename, String quoteid, String errorcode, String subquoteid, String orderid ) {
		Connection conn = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
        	String sql = "UPDATE " + tablename + " SET ERRORCODE = ?, SUBQUOTEID=?, ORDERID =? WHERE QUOTEID=?"; 
        	ps = conn.prepareStatement(sql);
        	ps.setString(1, errorcode);
        	ps.setString(2, subquoteid);
        	ps.setString(3, orderid);
        	ps.setString(4, quoteid);
        	
        	SLF4JLoggerProxy.info(this, "UPDATE " + tablename + " SET ERRORCODE = " + errorcode + 
					" SUBQUOTEID=" +subquoteid + ", ORDERID ="+orderid+" WHERE QUOTEID="+quoteid+"");
        	
        	ps.executeUpdate();
			
			conn.commit();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
				
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}
	}
	
	/**
	 * 
	 * @param quote
	 * @param status
	 * @param tablename
	 */
	public void updateStatus(String quoteid, String status,String tablename) {
		Connection conn = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
        	String sql = "UPDATE " + tablename + " SET STATUS = '" + status + "' WHERE QUOTEID=?"; 
        	ps = conn.prepareStatement(sql);
        	ps.setString(1, quoteid);
        	
        	SLF4JLoggerProxy.info(this, "UPDATE " + tablename + " SET STATUS = '" + status + "' WHERE QUOTEID=" + quoteid + "");
        	ps.executeUpdate();
			
        	if(status != null && status.equalsIgnoreCase("F")){
        		String sqlQuote = "UPDATE QUOTES SET STATUS = '" + status + "', SUBSTATUS = '" + status + "' WHERE QUOTEID=?";
        		ps = conn.prepareStatement(sqlQuote);
            	ps.setString(1, quoteid);
            	ps.executeUpdate();
        	}

			conn.commit();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
				
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}

	}
	
	public void updateResponeStatus(String quoteid, String status,String tablename) {		
		Connection conn = null; 
        ConnectionManager mgr = new ConnectionManager();
        CallableStatement callableStatement = null;
        
        String log = "";
        String p_err_code = "";
        try {
        	conn = mgr.getConnection();
        	
			callableStatement = conn.prepareCall(ConnectionManager.sqlMap.get(SQLStatement.KEY_CONFIRM_RESPONE_ORDER));
			callableStatement.registerOutParameter(1, Types.VARCHAR);// p_err_code
			callableStatement.registerOutParameter(2, Types.VARCHAR);// p_out_message
			callableStatement.registerOutParameter(3, Types.VARCHAR);// p_out_result

			callableStatement.setString(4, quoteid); // p_quoteid
			callableStatement.setString(5, status);// p_status
			callableStatement.setString(6, tablename);// p_tablename
							
			log = "store parametter -|  CSPKS_HFT_RESPONSE_ORS.sp_confirm_respone_order |  p_quoteid: " + quoteid
			+ "|  p_status: " + status + "|  p_tablename: " + tablename;
			
			SLF4JLoggerProxy.info(this, log);
			callableStatement.execute();
			p_err_code = callableStatement.getString(1);
			if(!p_err_code.equalsIgnoreCase("0") ){
				conn.rollback();
			}else{
				conn.commit();
			}
			
			//String p_out_message = callableStatement.getString(2);
			//String p_out_result = callableStatement.getString(3);		
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {				
				if (callableStatement != null) {
					callableStatement.clearParameters();
					callableStatement.close();
					callableStatement = null;
				}
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
			
			SLF4JLoggerProxy.info(this, p_err_code);
		}
	}
	
	public void updateStatusMCO(Quote quote,String columnName,String status) {
		Connection conn = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
        	String sql = "UPDATE MCO " + "SET " + columnName + " = '" + status + "' WHERE QUOTEID=?";
        	
        	ps = conn.prepareStatement(sql);
        	ps.setString(1, quote.getQuoteid());
        	
        	SLF4JLoggerProxy.info(this, "UPDATE MCO " + "SET " + columnName + " = '"  + status + "' WHERE QUOTEID="+quote.getQuoteid()+"");
        	ps.executeUpdate();
			
			conn.commit();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
				
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}

	}
	
	public void saveExecuteOrder(Quote quote, String requestid, String subQuoteid, String errorcode, String orderid, String activeType ) {
		Connection conn = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
        	String sql = "INSERT INTO ACTIVE_ORDERS(REQUESTID, QUOTEID,SUBQUOTEID, ORDERID, ORDERTYPE,ERRORCODE, ACTIVETYPE, PARENTNO) VALUES(?,?,?,?,?,?,?,?)"; 
        	ps = conn.prepareStatement(sql);
        	ps.setString(1, requestid);
        	ps.setString(2, quote.getQuoteid());
        	ps.setString(3, subQuoteid);
        	ps.setString(4, orderid);
        	ps.setString(5, quote.getClasscd());
        	ps.setString(6, errorcode);
        	ps.setString(7, activeType);
        	ps.setString(8, quote.getTraderid());//cho lenh OCO
        	
        	SLF4JLoggerProxy.info(this, "INSERT INTO ACTIVE_ORDERS(REQUESTID, QUOTEID,SUBQUOTEID, ORDERID, ORDERTYPE,ERRORCODE) " +
        			"VALUES("+requestid+","+quote.getQuoteid()+","+subQuoteid+","+orderid+","+quote.getClasscd()+","+errorcode+")");
        	
        	ps.execute();
			
        	if(quote.getClasscd() != null && quote.getClasscd().equalsIgnoreCase("OTO") && orderid != null && !orderid.equalsIgnoreCase("")){
        		String sqlUpdate = "UPDATE OTO SET BUYORDERID = ? WHERE QUOTEID = ?";
        		ps = conn.prepareStatement(sqlUpdate);
        		ps.setString(1, orderid);
            	ps.setString(2, quote.getQuoteid());
            	ps.execute();
        	}
        	
			conn.commit();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
				
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}
	}

	public void updateExecuteOrder(String requestid, String quoteid, String subQuoteid, String errorcode, String orderid, String ordertype ) {
		Connection conn = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
         
        try {
        	conn = mgr.getConnection();
        	String sql = "UPDATE ACTIVE_ORDERS SET ERRORCODE = ? WHERE QUOTEID= ?"; 
        	ps = conn.prepareStatement(sql);
        	ps.setString(1, errorcode);
        	ps.setString(2, quoteid);
        	
        	SLF4JLoggerProxy.info(this, "UPDATE ACTIVE_ORDERS SET ERRORCODE = " + errorcode + " WHERE QUOTEID= " + quoteid + "");
        	
        	ps.execute();
			conn.commit();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(this, e);
		} catch (Exception e) {
			SLF4JLoggerProxy.error(this, e);
		}finally{
			try {
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
				
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(this, e);
			}
		}
	}
	
	public static String getSequence() {
		Connection conn = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
        ResultSet rs = null; 
        String sequence = null;
        try {
        	conn = mgr.getConnection();
        	String sql = "SELECT SEQ_ACTIVE_ORDER.NEXTVAL seq FROM DUAL"; 
        	
        	ps = conn.prepareStatement(sql);
        	rs = ps.executeQuery();
			
        	 while(rs.next()){
 	        	sequence = rs.getString("seq");
        	 }
        	 
			return sequence;
			
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(DAOCommon.class, e);
			return null;
		} catch (Exception e) {
			SLF4JLoggerProxy.error(DAOCommon.class, e);
			return null;
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(DAOCommon.class, e);
			}
		}
	}
	
	
	public static Quote getOrderInfo(String orderid) {
		
		Connection conn = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
        ResultSet rs = null; 
        Quote quote = null;
        try {
        	conn = mgr.getConnection();
        	String sql = "SELECT O.ACCTNO, O.SYMBOL, O.SIDE, O.SUBSIDE, O.USERID, O.CANCEL_QTTY, O.REMAIN_QTTY, A.QUOTEID " +
        			"FROM ORDERS O, ACTIVE_ORDERS A WHERE O.ORDERID=? AND O.ORDERID = A.ORDERID AND REMAIN_QTTY > 0 "; 
        	
        	ps = conn.prepareStatement(sql);
        	ps.setString(1, orderid);
        	rs = ps.executeQuery();
			
        	 while(rs.next()){
        		quote = new Quote();
        		quote.setQuoteid(rs.getString("QUOTEID"));
        		quote.setAcctno(rs.getString("ACCTNO"));
        		quote.setSymbol(rs.getString("SYMBOL"));
        		quote.setSide(rs.getString("SIDE"));
        		quote.setSubside(rs.getString("SUBSIDE"));
        		quote.setUserid(rs.getString("USERID"));
        		quote.setQtty(rs.getLong("CANCEL_QTTY"));
        		quote.setQtty2(rs.getLong("REMAIN_QTTY"));//for OCO
        		SLF4JLoggerProxy.info(DAOCommon.class, "getOrderInfo orderid:" + orderid);
        	 }
        	 
			return quote;
			
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(DAOCommon.class, e);
			return null;
		} catch (Exception e) {
			SLF4JLoggerProxy.error(DAOCommon.class, e);
			return null;
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(DAOCommon.class, e);
			}
		}
	}
	
	
	public static List<Quote> getOrderList() {
				
		//checking status && type of order in DB
		Connection conn = null; 
        ConnectionManager mgr = new ConnectionManager();
        CallableStatement callableStatement = null;
        ResultSet rs = null;
        
        List<Quote> list = new ArrayList<Quote>();
        String log = "";
        String p_err_code = "After execute:";
        try {
        	conn = mgr.getConnection();
        	
			callableStatement = conn.prepareCall(ConnectionManager.sqlMap.get(SQLStatement.KEY_GET_ORDER_LIST));
			callableStatement.registerOutParameter(1, Types.VARCHAR);// p_err_code
			callableStatement.registerOutParameter(2, Types.VARCHAR);// p_out_message
			callableStatement.registerOutParameter(3, Types.VARCHAR);// p_out_result
			callableStatement.registerOutParameter(4, OracleTypes.CURSOR); // p_out_recordset
									
			callableStatement.execute();
			p_err_code = callableStatement.getString(1);
			if(!p_err_code.equalsIgnoreCase("0") ){
				SLF4JLoggerProxy.error(DAOCommon.class, "CSPKS_HFT_ENGINE_GET_INFO.sp_get_order_list ,p_err_code:" + p_err_code);
			}
			
			if(p_err_code.equalsIgnoreCase("0")){//lenh da active va da sinh lenh con
				rs = (ResultSet) callableStatement.getObject(4); //list suborder that will cancel
				while (rs.next()) {
					Quote quote = new Quote();
					quote.setQuoteid(rs.getString("QUOTEID"));
					quote.setOrderid(rs.getString("ORDERID"));
					quote.setAcctno(rs.getString("ACCTNO"));
					quote.setSymbol(rs.getString("SYMBOL"));
					quote.setSide(rs.getString("SIDE"));
					quote.setSubside(rs.getString("SUBSIDE"));
					quote.setQtty(rs.getLong("CANCEL_QTTY"));
					quote.setUserid(rs.getString("USERID"));
					quote.setVia(rs.getString("VIA"));
					quote.setReftype("C");//D: con nguoi huy, C: engine huy
					list.add(quote);
				}
			}

			conn.commit();
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(DAOCommon.class, e);
			return null;
		} catch (Exception e) {
			SLF4JLoggerProxy.error(DAOCommon.class, e);
			return null;
		}finally{
			try {				
				if (rs != null) {
					rs.close();
				}
				if (callableStatement != null) {
					callableStatement.clearParameters();
					callableStatement.close();
					callableStatement = null;
				}
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(DAOCommon.class, e);
			}
			
			SLF4JLoggerProxy.info(DAOCommon.class, p_err_code);
		}
		return list;
	}
	
	public static List<String> getCancelOrder(String quoteid, String orderid) {
		Connection conn = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
        ResultSet rs = null; 
        
        List<String> cancelList = new ArrayList<String>();
        try {
        	conn = mgr.getConnection();
        	String sql = "SELECT ORDERID FROM ACTIVE_ORDERS WHERE QUOTEID = ? AND ORDERID <> ? "; 
        	
        	ps = conn.prepareStatement(sql);
        	ps.setString(1, quoteid);
        	ps.setString(2, orderid);
        	rs = ps.executeQuery();
        	
        	 while(rs.next()){        		
        		cancelList.add(rs.getString("ORDERID"));
        		//break;
        	 }
        	 
			return cancelList;
			
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(DAOCommon.class, e);
			return null;
		} catch (Exception e) {
			SLF4JLoggerProxy.error(DAOCommon.class, e);
			return null;
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(DAOCommon.class, e);
			}
		}
	}
	
	public static List<String> getListActiveOrder(String quoteid) {
		Connection conn = null;
		PreparedStatement ps = null;   
        ConnectionManager mgr = new ConnectionManager();
        ResultSet rs = null; 
        List<String> list = null;
        try {
        	conn = mgr.getConnection();
        	String sql = "SELECT ORDERID FROM ACTIVE_ORDERS WHERE QUOTEID = ? "; 
        	
        	ps = conn.prepareStatement(sql);
        	ps.setString(1, quoteid);
        	rs = ps.executeQuery();
			
        	list = new ArrayList<String>();
        	 while(rs.next()){        		
        		String orderid = rs.getString("ORDERID");
        		list.add(orderid);
        	 }
        	 
			return list;
			
		} catch (SQLException e) {
			SLF4JLoggerProxy.error(DAOCommon.class, e);
			return null;
		} catch (Exception e) {
			SLF4JLoggerProxy.error(DAOCommon.class, e);
			return null;
		}finally{
			try {
				if(rs != null){
					rs.close();
				}
				
				if(ps != null){
					ps.close();
				}
				
				mgr.closeConnection(conn);
			} catch (SQLException e) {				
				SLF4JLoggerProxy.error(DAOCommon.class, e);
			}
		}
	}
}
