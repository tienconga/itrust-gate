package com.noname.itrust.gate.aq;

import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import org.apache.log4j.Logger;

import com.noname.itrust.gate.common.CommonConstants;
import com.noname.itrust.gate.common.ConfigLoader;

public class MessageSender {

	final static Logger logger = Logger.getLogger(MessageSender.class);
	
	private Context context = null;
	private QueueConnectionFactory queueConnectionFactory = null;
	private QueueConnection queueConnection = null;
	private QueueSession queueSession = null;
	private Queue queue = null;;
	private MessageProducer producer = null;
	private String queueName = "";

	public MessageSender() {}
	
	public MessageSender(String jmsProperties) {
		try {
			if (ConfigLoader.senderProps == null) {
				ConfigLoader.loadProperties(jmsProperties,"LocalSender");
			}
			
			connect();
		} catch (Exception e) {
			logger.error(e.getStackTrace());
		}
	}
	
	public void connect() {
		try {
			queueName = ConfigLoader.senderProps.getProperty(CommonConstants.JMS_MESSAGE_RESPONSE_NAME);
			context = new InitialContext(ConfigLoader.senderProps);
			queueConnectionFactory = (QueueConnectionFactory) context.lookup("QueueConnectionFactory");
			queueConnection = queueConnectionFactory.createQueueConnection();
			queueSession = queueConnection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			queue = queueSession.createQueue(queueName);
			producer = queueSession.createProducer(queue);
			producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
		} catch (Exception e) {
			logger.error(e.getStackTrace());
		}
	}

	public void send(String message) {
		TextMessage msgObj = null;
		try {
			msgObj = queueSession.createTextMessage();
			msgObj.setText(message);
			producer.send(msgObj);
		} catch (JMSException e) {
			logger.error(e.getStackTrace());
		}
	}

	public void disconnect() {
		try {
			if (queueConnection != null) {
				queueConnection.stop();
				queueSession.close();
			}
			System.exit(0);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			queueConnection = null;
			queueSession = null;
		}
	}

}
