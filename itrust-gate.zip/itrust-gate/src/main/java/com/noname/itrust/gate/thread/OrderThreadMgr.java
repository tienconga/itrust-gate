package com.noname.itrust.gate.thread;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.fss.newfo.common.model.Quote;
import com.fss.newfo.common.utility.log.SLF4JLoggerProxy;

public class OrderThreadMgr {

	final static Logger logger = Logger.getLogger(OrderThreadMgr.class);

	private static volatile OrderThreadMgr threadMgr;

	private ThreadPoolExecutor executor;

	public static final int DEFAULT_QUEUE_SIZE = 100000;

	public static void initThreadMgr(int size, long timeout, int queueSize) {
		threadMgr = new OrderThreadMgr(size, timeout, queueSize);
	}

	public static OrderThreadMgr getThreadMgr() {

		if (threadMgr == null) {
			threadMgr = new OrderThreadMgr(10, 100, DEFAULT_QUEUE_SIZE);
		} else {
		}

		return threadMgr;
	}

	public OrderThreadMgr(int size, long timeout, int queueSize) {
		BlockingQueue<Runnable> queue = (BlockingQueue<Runnable>) new ArrayBlockingQueue<Runnable>(queueSize);
		this.executor = new ThreadPoolExecutor(size, size, timeout, TimeUnit.MILLISECONDS, queue);
	}

	public int fireEmptyThread(long id, Quote ticket, String threadName) {

		try {
			OrderThreadWork bWork = new OrderThreadWork(id, ticket, threadName);
			this.executor.execute(bWork);
			return -1;
		} catch (RejectedExecutionException e) {
			SLF4JLoggerProxy.error(this, e);
			return 0;
		}
	}

}
